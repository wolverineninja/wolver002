// ourmenu.ts — Custom dual-panel VR mod menu for Animal Company (PC)
// Visual target: dark blue/purple translucent panels, horizontal stripe rows,
// white text, tab bar across top, left scrollable foldout list + right info panel.
//
// Load order:
//   frida -l frida-il2cpp-bridge.js -l sy.ts -l ourmenu.ts "AnimalCompany.exe"
//
// All labels/data are "test" placeholders per request — functional wiring comes later.

declare const Il2Cpp: any;
declare const console: any;

// Debug sink: buffers lines and flushes once via two independent sinks so the
// file appears regardless of which API works in this build:
//   Sink 1 — Frida's native `File` (new File(path, mode))
//   Sink 2 — the game's own .NET System.IO.File.WriteAllText (always present)
// dbg() also mirrors to console. dbgFlush() must be called from an attached
// context (inside the Interceptor onEnter / Il2Cpp.perform), e.g. end of buildMenu.
const DBG_PATH = ".\\WMM_debug.txt";
const MEASURE_PATH = ".\\WMM_measure.txt";
let __dbgBuf = "";
function dbg(line: string): void {
    __dbgBuf += line + "\n";
    try { console.log("[dbg] " + line); } catch (_) {}
}
// Dual-sink file writer (Frida File + .NET System.IO.File). Must run attached.
function writeFileDual(path: string, content: string): void {
    let sink1ok = false;
    try {
        const FileCtor = (globalThis as any).File;
        const f = new FileCtor(path, "w");
        f.write(content);
        f.flush();
        f.close();
        sink1ok = true;
    } catch (_) {}
    try {
        let corlib: any = null;
        for (const n of ["mscorlib", "System.Private.CoreLib"]) {
            try { const a = Il2Cpp.domain.assembly(n); if (a) { corlib = a.image; break; } } catch (_) {}
        }
        if (corlib) {
            const FileCls = corlib.class("System.IO.File");
            const path2 = sink1ok ? path.replace(".txt", "_net.txt") : path;
            FileCls.method("WriteAllText", 2).invoke(Il2Cpp.string(path2), Il2Cpp.string(content));
        }
    } catch (_) {}
}
function dbgFlush(): void { writeFileDual(DBG_PATH, __dbgBuf); }

Il2Cpp.perform(() => {
    // ============================================================
    // Unity class refs
    // ============================================================
    const UnityCore   = Il2Cpp.domain.assembly("UnityEngine.CoreModule").image;
    const UnityPhys   = Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image;
    const GameObject  = UnityCore.class("UnityEngine.GameObject");
    const Quaternion  = UnityCore.class("UnityEngine.Quaternion");
    const Renderer    = UnityCore.class("UnityEngine.Renderer");
    const Shader      = UnityCore.class("UnityEngine.Shader");
    const Camera      = UnityCore.class("UnityEngine.Camera");
    const Object_     = UnityCore.class("UnityEngine.Object");
    const Resources_  = UnityCore.class("UnityEngine.Resources");
    const BoxCollider = UnityPhys.class("UnityEngine.BoxCollider");
    const TimeClass   = UnityCore.class("UnityEngine.Time");

    // Legacy TextMesh + Font live in UnityEngine.TextRenderingModule. Use these as
    // a fallback when TMP_Settings.defaultFontAsset is null (which is the case in
    // some game builds). Arial.ttf is always a Unity builtin resource.
    let TextMeshLegacy: any = null;
    let FontClass: any = null;
    try {
        const txt = Il2Cpp.domain.assembly("UnityEngine.TextRenderingModule").image;
        TextMeshLegacy = txt.class("UnityEngine.TextMesh");
        FontClass = txt.class("UnityEngine.Font");
    } catch (_) {
        console.error("[ourmenu] UnityEngine.TextRenderingModule missing — legacy TextMesh fallback unavailable");
    }

    let arialFont: any = null;
    function getArialFont(): any {
        if (arialFont && !arialFont.isNull?.()) return arialFont;
        if (!FontClass) return null;
        try {
            arialFont = Resources_.method("GetBuiltinResource", 1).inflate(FontClass).invoke(Il2Cpp.string("Arial.ttf"));
            if (arialFont && !arialFont.isNull?.()) return arialFont;
        } catch (_) {}
        return null;
    }

    // Player class is resolved LAZILY — at script load time, Assembly-CSharp
    // may not be loaded yet. We re-try at buildMenu time and cache once found.
    let GTPlayerClass: any = null;
    let playerClassResolved = false;

    const ASSEMBLY_CANDIDATES = [
        "Assembly-CSharp",
        "Assembly-CSharp-firstpass",
        "AnimalCompany",
        "Animal Company",
    ];
    const PLAYER_CLASS_CANDIDATES = [
        "AnimalCompany.GorillaLocomotion",
        "GorillaLocomotion.Player",
        "GorillaLocomotion",
        "AnimalCompany.Player",
        "AnimalCompany.PlayerController",
        "Player",
        "PlayerController",
    ];

    function resolvePlayerClass(): any {
        if (playerClassResolved) return GTPlayerClass;

        // Try each assembly candidate
        let acImage: any = null;
        let foundAssembly: string | null = null;
        for (const asmName of ASSEMBLY_CANDIDATES) {
            try {
                const asm = Il2Cpp.domain.assembly(asmName);
                if (asm) {
                    acImage = asm.image;
                    foundAssembly = asmName;
                    break;
                }
            } catch (_) {}
        }

        if (!acImage) {
            // Enumerate ALL loaded assemblies so we can find the right name
            try {
                const names: string[] = [];
                for (const a of Il2Cpp.domain.assemblies) {
                    try { names.push(a.name); } catch (_) {}
                }
                console.log(`[ourmenu] no game assembly found. Loaded assemblies (${names.length}):\n  - ${names.slice(0, 40).join("\n  - ")}`);
            } catch (e) {
                console.error("[ourmenu] assembly enum failed:", e);
            }
            playerClassResolved = true; // don't try again this run
            return null;
        }
        console.log(`[ourmenu] using assembly: ${foundAssembly}`);

        // Try each player class candidate
        for (const candidate of PLAYER_CLASS_CANDIDATES) {
            try {
                const k = acImage.class(candidate);
                if (k) {
                    GTPlayerClass = k;
                    console.log(`[ourmenu] using player class: ${candidate}`);
                    playerClassResolved = true;
                    return GTPlayerClass;
                }
            } catch (_) {}
        }

        // None matched — dump candidate class names
        try {
            const hits: string[] = [];
            for (const klass of acImage.classes) {
                try {
                    const name = klass.type?.name || "";
                    if (/Player|Gorilla|Hand|Locomotion/i.test(name)) {
                        hits.push(name);
                        if (hits.length >= 40) break;
                    }
                } catch (_) {}
            }
            if (hits.length > 0) {
                console.log(`[ourmenu] candidate classes in ${foundAssembly}:\n  - ${hits.join("\n  - ")}`);
            } else {
                console.log(`[ourmenu] no Player/Gorilla/Hand classes in ${foundAssembly}`);
            }
        } catch (e) {
            console.error("[ourmenu] class enum failed:", e);
        }
        playerClassResolved = true;
        return null;
    }

    function getHandTransform(useRight: boolean): any | null {
        const PlayerKlass = resolvePlayerClass();
        if (!PlayerKlass) return null;
        try {
            // Try a few field name conventions for the static instance
            let player: any = null;
            const instanceFieldCandidates = ["<Instance>k__BackingField", "Instance", "instance", "_instance"];
            for (const f of instanceFieldCandidates) {
                try {
                    const v = GTPlayerClass.field(f).value;
                    if (v && !v.isNull?.()) { player = v; break; }
                } catch (_) {}
            }
            if (!player) return null;

            const handFieldName = useRight ? "rightHandTransform" : "leftHandTransform";
            const handTr = player.field(handFieldName).value;
            if (!handTr || handTr.isNull?.()) return null;
            return handTr;
        } catch (_) { return null; }
    }

    let TextMeshPro3D: any = null;
    let TMPSettingsClass: any = null;
    try {
        const tmpImage = Il2Cpp.domain.assembly("Unity.TextMeshPro").image;
        TextMeshPro3D = tmpImage.class("TMPro.TextMeshPro");
        try { TMPSettingsClass = tmpImage.class("TMPro.TMP_Settings"); } catch (_) {}
    } catch (_) {
        console.error("[ourmenu] TextMeshPro class missing — text won't render");
    }

    // ============================================================
    // Cheat hooks (VPN/anti-cheat bypass + dev mode), ported from M4 (da.ts).
    // - Installed once at script load (top-level Il2Cpp.perform context).
    // - VPN/AntiCheat hooks no-op the detection so the game stops flagging VPN.
    // - Dev Mode is a button-triggered one-shot in the OP list.
    // All wrapped in try/catch — if the class isn't loaded yet, we silently
    // skip and the script keeps working without the hook.
    // ============================================================
    function tryMethodName(klass: any, names: string[], parameterCount: number = -1): any {
        for (const name of names) {
            try { return parameterCount >= 0 ? klass.method(name, parameterCount) : klass.method(name); }
            catch (_) {}
        }
        return null;
    }
    function getAcImage(): any {
        for (const name of ASSEMBLY_CANDIDATES) {
            try { const asm = Il2Cpp.domain.assembly(name); if (asm) return asm.image; } catch (_) {}
        }
        return null;
    }

    function installAntiCheatVpnHooks(): void {
        const acImage = getAcImage();
        if (!acImage) {
            console.error("[ourmenu/cheat] game assembly not loaded — VPN hooks skipped");
            return;
        }
        // 1. Kill AntiCheatSystem's tick. Class name + tick method name vary by
        //    build, so probe a list of each.
        const acClassCandidates = [
            "AnimalCompany.AntiCheatSystem",
            "AnimalCompany.AntiCheat",
            "AnimalCompany.Security.AntiCheatSystem",
            "AntiCheatSystem",
        ];
        const acMethodCandidates = ["Update", "LateUpdate", "FixedUpdate", "Tick", "RunChecks", "Process", "Check"];
        let acHooked = false;
        for (const cls of acClassCandidates) {
            try {
                const klass = acImage.class(cls);
                if (!klass) continue;
                const m = tryMethodName(klass, acMethodCandidates);
                if (m) {
                    m.implementation = function () {};
                    console.log(`[ourmenu/cheat] AntiCheat hooked: ${cls}.<tick>`);
                    acHooked = true;
                    break;
                }
                // Dump all methods so we can see the real tick name.
                const names: string[] = [];
                try {
                    for (const mm of klass.methods) {
                        try { names.push(mm.name); } catch (_) {}
                    }
                } catch (_) {}
                console.log(`[ourmenu/cheat] ${cls} methods (${names.length}): ${names.slice(0, 40).join(", ")}${names.length > 40 ? ", ..." : ""}`);
            } catch (_) {}
        }
        if (!acHooked) {
            console.error("[ourmenu/cheat] AntiCheatSystem: no class+method matched. Send me the class name if you find it.");
        }
        // 2. AppState.get_isVPNActive → force its SubscriberPattern value to false.
        try {
            const AppStateClass = acImage.class("AnimalCompany.AppState");
            const origGetter = AppStateClass.method("get_isVPNActive");
            origGetter.implementation = function (this: any) {
                let sp: any = null;
                try { sp = origGetter.invokeRaw(this); } catch (_) {}
                if (sp && !sp.isNull?.()) {
                    try { sp.method("set_value").invoke(false); } catch (_) {}
                    try { sp.field("_value").value = false; } catch (_) {}
                    try { sp.field("value").value = false; } catch (_) {}
                }
                return sp;
            };
            console.log("[ourmenu/cheat] AppState.get_isVPNActive hooked → always false");
        } catch (e) {
            console.error("[ourmenu/cheat] AppState.get_isVPNActive hook FAILED:", e);
        }
    }

    // Port of M4 da.ts:4024-4045 tryCallNames helper. Tries each name in
    // sequence via TWO paths (obj.class.method then obj.method) and STOPS at
    // first success. The two-path approach is the key — some methods only
    // resolve via the class definition (inherited / interface-implemented),
    // others only via the instance.
    function tryCallNames(obj: any, names: string[], parameterCount: number = -1, ...args: any[]): boolean {
        try {
            if (!obj || obj.isNull?.()) return false;
            for (const name of names) {
                try {
                    const method = parameterCount >= 0
                        ? obj.class.method(name, parameterCount)
                        : obj.class.method(name);
                    if (method) {
                        method.invokeRaw(obj, ...args);
                        return true;
                    }
                } catch (_) {}
                try {
                    const method = parameterCount >= 0
                        ? obj.method(name, parameterCount)
                        : obj.method(name);
                    if (method) {
                        method.invoke(...args);
                        return true;
                    }
                } catch (_) {}
            }
        } catch (_) {}
        return false;
    }

    // ============================================================
    // OP mod toggle flags (M4 pattern, da.ts:628-7989).
    // Each flag is checked inside an installModHooks() method hook below.
    // ============================================================
    let InfAmmo = false;
    let noRecoil = false;
    let noShotgunCooldown = false;
    let rapidFireEnabled = false;
    let rapidFirePulseDelay = 0;
    let infDamage = false;
    let stashDupeEnabled = false;
    let ejectDupeAmount = 2;
    let multiBuyEnabled = false;
    let multiBuyAmount = 5;
    let unlockAllEnabled = false;
    let infHealthEnabled = false;
    let infFlareAmmoEnabled = false;
    let modHooksInstalled = false;
    // Per-frame mods (run in the Update hook while their flag is on).
    let spazExplodeMachineEnabled = false;
    let spazExplodeNextTime = 0;
    // Tooltip panel state — shows last clicked mod's description on the LEFT of
    // the menu (M4 sends the toolTip as a notification; we render it inline).
    let currentTooltipLabel: string | null = null;
    const OP_TOOLTIPS: Record<string, string> = {
        "Multi Buy": "Repeats purchase-machine buys using the current multiplier.",
        "Change Multi Buy": "Cycles the multi buy amount in steps of 5 up to 50, then resets.",
        "Grant All Stash Slots": "Best-effort force unlocks every stash slot it can find on this build.",
        "No Container Restrictions": "Force-applies bag/quiver/back/hip/container flags so items can go anywhere.",
        "RPG Hands All": "Anyone holding a revolver in their right hand gets fast RPG hands from that right-hand anchor.",
        "Buggy Hands": "Hold grip + trigger to keep launching buggies forward from your hand.",
        "Item Launcher": "Hold grip + trigger to keep launching the currently selected Item ID from your hand.",
        "Right Hand Duper": "Rapidly duplicates the item in your right hand and throws the copies forward.",
        "Give Fly All": "Anyone holding a revolver in their right hand gets smooth forward fly.",
        "Item Launcher All": "Any player holding any item in either hand launches copies of that same held item.",
        "All Player Gun Buffs": "Best-effort local patch keeping other players' guns rapid-fire, high-ammo, no-recoil.",
        "Item Rain": "Rains the currently selected Item ID above your head while enabled.",
        "Goop Spammer": "Shoots a temporary stream of goop forward/down from your lower body.",
        "Piss Mod": "Shoots a yellow temporary piss stream from your lower body.",
        "Grab Selling Machine": "While right grip is held, a selling machine stays pushed out in front of your hand.",
        "Mob Orbit": "Spawns the current mob selection into an orbit around you and keeps them active.",
        "Prefab Orbit": "Orbits the currently selected Prefab ID around you and deletes them when off.",
        "Spaz Explode Machine": "Rapidly spams the selling machine explosion path on existing machines.",
        "Item Tornado": "Spawns a much larger spinning tornado of colorful items around you.",
        "Lag All Items": "The old heavy random-all behavior that lags the lobby on purpose.",
        "Cage All Players": "Cages every other player with selling machines and despawns them when off.",
        "Delete All Lobby Items": "One-click deletes or despawns all lobby items after taking authority.",
        "Spawn NetPlayer Trigger": "While on, right trigger spawns a NetPlayer prefab forward from your hand.",
        "Give Masterclient": "Promotes you to master client / host using NetworkRunner.SetMasterClient.",
        "Stash Dupe": "Lets you eject more times using your stash.",
        "Change Eject Dupe Amount": "Cycles through preset dupe amounts.",
        "Rocket Launcher": "hi",
        "flaregun": "tuff",
        "boomspear": "tuff",
        "Robot Dog RPG": "tuff",
        "ChristmasBox Orbit self": "Creates 8 selling machines that orbit you.",
        "egg": "tuff",
        "Christmas Present Tower": "Creates a 7-story tower of Christmas presents around you.",
        "Sellingmachine Orbit self": "Creates 8 selling machines that orbit you.",
        "Sellingmachine Tower Orbit": "Creates a dense 3-story selling machine orbit and leaves it in place when off.",
        "Moon Buggy Orbit self": "Creates 8 buggies that orbit around you.",
        "Tree Forest Orbit": "Creates a normal orbit of forest trees around you.",
        "Infinite Ammo": "Infinite ammo on all guns.",
        "No Recoil": "Removes recoil force and spread on all guns.",
        "No Shotgun Cooldown": "Removes the reload/cooldown delay between shotgun shots.",
        "Rapid Fire": "Rapid fires trigger items and force-cocks revolvers when possible.",
        "Nut Pickup Gun": "Spawns nut pickups where you aim (hold grip + trigger).",
        "Ammo Pickup Gun": "Spawns ammo pickups where you aim (hold grip + trigger).",
        "Dump Net Objects": "Logs every spawnable NetworkObject prefab name from the Fusion PrefabTable.",
        "Unlock All": "Unlocks all gameplay + cosmetic items including hidden/dev items.",
        "Dump Menu TXT": "Dumps the full runtime menu/button/id layout to a txt file beside this script.",
        "Inf Damage": "Pumps damage on Gun.Shoot to 999999/2.1B per bullet field.",
        "Connect Quest Servers": "Overrides AppUtils.CalculatePhotonAppVersion so the client connects to Quest matchmaking.",
        "Fly": "Make a fist (grip + trigger) with either hand to fly where you point. Combines both hands if you make both fists.",
        "Joystick Fly": "Right thumbstick moves you horizontally relative to where you're looking; left thumbstick Y moves you up/down.",
        "Insta Kill All": "One-click — sends RPC_PlayerHit(9999) to every non-local player. Requires master client / authority on the network object.",
        "Server Kick All": "One-click — best-effort kick on every non-local player using the game's network runner Disconnect/RemovePlayer paths. Requires master client / authority.",
        "Kick Gun": "Toggle. Hold the right GRIP to shoot a laser from your hand (aim by pointing where you look down your arm; green = landed on a player, red = on nothing), then click the right TRIGGER to kick whoever the laser is on. One kick per click. Same kick path as Server Kick All — requires master client / authority.",
        "Spawn Mob Hand": "One-click — spawns the currently selected mob ID 1.5m in front of your right hand using AnimalCompany.PrefabGen.SpawnMob and the validator bypass.",
    };

    // Install all single-method-hook mods at script load. M4 does this at startup,
    // not on button click, so the hooks are in place before the user toggles flags.
    function installModHooks(): void {
        if (modHooksInstalled) return;
        const acImage = getAcImage();
        if (!acImage) { console.error("[ourmenu/mods] AC assembly not loaded"); return; }
        let n = 0;
        const failures: string[] = [];
        const tryHook = (cls: string, mname: string, fn: (orig: any) => void) => {
            try {
                let klass: any = null;
                try { klass = acImage.class(cls); } catch (e) { failures.push(`${cls}: class not found`); return; }
                if (!klass) { failures.push(`${cls}: class null`); return; }
                let m: any = null;
                try { m = klass.method(mname); } catch (e) { failures.push(`${cls}.${mname}: method not found`); return; }
                if (!m) { failures.push(`${cls}.${mname}: method null`); return; }
                fn(m);
                n++;
            } catch (e) { failures.push(`${cls}.${mname}: ${e}`); }
        };

        // ===== Infinite Ammo (M4 da.ts:16267-16314) =====
        tryHook("AnimalCompany.FlareGun", "get_hasAmmo", (m) => {
            m.implementation = function (this: any) {
                if (InfAmmo || rapidFireEnabled) return true;
                return m.invokeRaw(this);
            };
        });
        tryHook("AnimalCompany.Revolver", "get_ammoLoaded", (m) => {
            m.implementation = function (this: any) {
                if (InfAmmo || rapidFireEnabled) return 255;
                return m.invokeRaw(this);
            };
        });
        tryHook("AnimalCompany.Revolver", "get_isHammerCocked", (m) => {
            m.implementation = function (this: any) {
                if (InfAmmo || rapidFireEnabled) return true;
                return m.invokeRaw(this);
            };
        });
        tryHook("AnimalCompany.ZiplineGun", "get_isLoaded", (m) => {
            m.implementation = function (this: any) {
                if (InfAmmo || rapidFireEnabled) return true;
                return m.invokeRaw(this);
            };
        });
        tryHook("AnimalCompany.Shotgun", "get__ammoLeft", (m) => {
            m.implementation = function (this: any) {
                if (InfAmmo || rapidFireEnabled) return 255;
                return m.invokeRaw(this);
            };
        });
        tryHook("AnimalCompany.AutoReloadGun", "get__ammoLeft", (m) => {
            m.implementation = function (this: any) {
                if (InfAmmo || rapidFireEnabled) return 255;
                return m.invokeRaw(this);
            };
        });
        tryHook("AnimalCompany.RPG", "get_loadedState", (m) => {
            m.implementation = function (this: any) {
                const state = m.invokeRaw(this);
                if ((InfAmmo || rapidFireEnabled) && state && !state.isNull?.()) {
                    try { state.field("isLoaded").value = true; } catch (_) {}
                    try { this.method("set_loadedState").invoke(state); } catch (_) {}
                }
                return state;
            };
        });
        tryHook("AnimalCompany.JetpackHandy", "RPC_UseJetpack", (m) => {
            m.implementation = function (this: any) {
                if (InfAmmo) {
                    m.invokeRaw(this);
                    try { this.field("_isUsed").value = false; } catch (_) {}
                } else {
                    return m.invokeRaw(this);
                }
            };
        });

        // ===== No Recoil + Inf Damage (Gun.Shoot — M4 da.ts:16327-16370) =====
        tryHook("AnimalCompany.Gun", "Shoot", (m) => {
            m.implementation = function (this: any) {
                if (!noRecoil && !infDamage) return m.invokeRaw(this);
                try {
                    const cfg = this.method("get_config").invoke();
                    if (!cfg || cfg.isNull?.()) return m.invokeRaw(this);
                    const origRecoil = cfg.field("recoilForceMag").value;
                    const origHand = cfg.field("handRecoilForceMag").value;
                    const origSpread = cfg.field("shotSpread").value;
                    let origDmg: any = null;
                    if (noRecoil) {
                        cfg.field("recoilForceMag").value = 0.0;
                        cfg.field("handRecoilForceMag").value = 0.0;
                        cfg.field("shotSpread").value = 0.0;
                    }
                    if (infDamage) {
                        try { origDmg = cfg.field("damage").value; cfg.field("damage").value = 999999.0; } catch (_) {}
                        try { cfg.field("bulletDamage").value = 2147483648.0; } catch (_) {}
                        try { cfg.field("damagePerBullet").value = 2147483648.0; } catch (_) {}
                        try { cfg.field("hitDamage").value = 2147483648.0; } catch (_) {}
                    }
                    const result = m.invokeRaw(this);
                    if (noRecoil) {
                        cfg.field("recoilForceMag").value = origRecoil;
                        cfg.field("handRecoilForceMag").value = origHand;
                        cfg.field("shotSpread").value = origSpread;
                    }
                    if (infDamage) {
                        try { if (origDmg !== null) cfg.field("damage").value = origDmg; } catch (_) {}
                        try { cfg.field("bulletDamage").value = 1.0; } catch (_) {}
                        try { cfg.field("damagePerBullet").value = 1.0; } catch (_) {}
                        try { cfg.field("hitDamage").value = 1.0; } catch (_) {}
                    }
                    return result;
                } catch (_) { return m.invokeRaw(this); }
            };
        });

        // ===== No Shotgun Cooldown (M4 da.ts:16430-16450) =====
        try {
            const ShotgunClass = acImage.class("AnimalCompany.Shotgun");
            if (ShotgunClass) {
                const updateReload = tryMethodName(ShotgunClass, ["UpdateReload", "ReloadUpdate"]);
                if (updateReload) {
                    updateReload.implementation = function (this: any) {
                        if (noShotgunCooldown) {
                            try { this.field("_reloadTimer").value = 0.0; } catch (_) {}
                        }
                        return updateReload.invokeRaw(this);
                    };
                    n++;
                }
                const handleUse = ShotgunClass.method("HandleUse");
                handleUse.implementation = function (this: any) {
                    if (noShotgunCooldown) {
                        try { this.field("_reloadTimer").value = 0.0; } catch (_) {}
                    }
                    return handleUse.invokeRaw(this);
                };
                n++;
            }
        } catch (_) {}

        // ===== Stash Dupe (M4 da.ts:16315-16323) =====
        tryHook("AnimalCompany.StashMachine.StashMachineTrashChuteView", "EjectItem", (m) => {
            m.implementation = function (this: any, item: any) {
                if (stashDupeEnabled) {
                    for (let i = 0; i < ejectDupeAmount; i++) {
                        m.invokeRaw(this, item);
                    }
                } else {
                    return m.invokeRaw(this, item);
                }
            };
        });

        // ===== Unlock All (M4 da.ts:16671-16694) — all items purchasable/researchable =====
        // Same assembly bug as the dev hook: GameplayItemState lives in the
        // AnimalCompany assembly, NOT Assembly-CSharp. acImage.class() against
        // the wrong image returns null and the loop silently never hooks
        // anything. Look up the class via the AnimalCompany assembly directly.
        try {
            let GIS: any = null;
            try {
                const acAsm = Il2Cpp.domain.assembly("AnimalCompany");
                if (acAsm) GIS = acAsm.image.class("AnimalCompany.GameplayItemState");
            } catch (_) {}
            if (!GIS) {
                // Fallback: try the Assembly-CSharp image too in case a future
                // build moves it.
                try { GIS = acImage.class("AnimalCompany.GameplayItemState"); } catch (_) {}
            }
            if (GIS) {
                for (const prop of ["get_allowBlueprintSaving", "get_isPurchasable", "get_isResearchable", "get_canBeSavedToLoadoutTemplate"]) {
                    try {
                        const m = GIS.method(prop);
                        m.implementation = function (this: any) {
                            if (unlockAllEnabled) return true;
                            return m.invokeRaw(this);
                        };
                        n++;
                    } catch (_) {}
                }
                try {
                    const maxBP = GIS.method("get_maxInBlueprint");
                    maxBP.implementation = function (this: any) {
                        if (unlockAllEnabled) return 9999;
                        return maxBP.invokeRaw(this);
                    };
                    n++;
                } catch (_) {}
                // ===== get_isHidden → false (M4 da.ts:8069) =====
                // CRITICAL for dev items to appear in UI. Without this, dev/test
                // items stay invisible even when isDeveloper is forced true,
                // because the game filters the visible item list by isHidden.
                // Returning false unconditionally makes EVERY item visible,
                // including normally-hidden dev/test/cut content.
                try {
                    const isHidden = GIS.method("get_isHidden");
                    isHidden.implementation = function (this: any) {
                        if (unlockAllEnabled) return false;
                        return isHidden.invokeRaw(this);
                    };
                    n++;
                    console.log("[ourmenu/mods]   GIS.get_isHidden → false (dev items now visible)");
                } catch (e) {
                    console.error("[ourmenu/mods]   GIS.get_isHidden hook FAILED:", e);
                }
                console.log("[ourmenu/mods] GameplayItemState hooks installed (via AnimalCompany assembly)");
            } else {
                console.error("[ourmenu/mods] GameplayItemState NOT FOUND in any candidate assembly");
            }
        } catch (e) {
            console.error("[ourmenu/mods] GameplayItemState hook block threw:", e);
        }

        modHooksInstalled = true;
        console.log(`[ourmenu/mods] installed ${n} method hooks`);
        if (failures.length > 0) {
            console.log(`[ourmenu/mods] ${failures.length} hooks FAILED:`);
            for (const f of failures) console.log(`[ourmenu/mods]   ✗ ${f}`);
        }
    }

    // ============================================================
    // M4 HELPER LIBRARY (port of da.ts spawn/orbit/network helpers).
    // These power the OP mods that spawn items/mobs/prefabs around
    // the player or orbit them. Each helper is matched verbatim to
    // M4's pattern (see da.ts line refs).
    // ============================================================
    // Full M4 da.ts:123-468 itemIDs list — ~340 items including dev/quest/
    // non-buyable items (ores, fish, backpacks, snowboards, quest items,
    // ammos, randombox loot, special variants). Previous list only had ~105
    // mostly-buyable items, missing dev/hidden ones.
    const itemIDs: string[] = [
        "item_ac_cola", "item_pelican_case", "item_rpg", "item_alphablade", "item_anti_gravity_grenade",
        "item_arena_pistol", "item_arena_shotgun", "item_arrow", "item_arrow_bomb", "item_arrow_heart",
        "item_arrow_lightbulb", "item_arrow_teleport", "item_axe",
        "item_backpack", "item_backpack_black", "item_backpack_green", "item_backpack_large_base",
        "item_backpack_large_basketball", "item_backpack_large_clover", "item_backpack_pink",
        "item_backpack_realistic", "item_backpack_small_base", "item_backpack_white",
        "item_backpack_with_flashlight",
        "item_bait_beetle", "item_bait_fly", "item_bait_glowworm", "item_bait_magmar_ball",
        "item_bait_mouse_trap", "item_bait_sardine", "item_bait_shell", "item_bait_starfish",
        "item_bait_wallet",
        "item_balloon", "item_balloon_heart", "item_bamboo_fishing_rod", "item_banana",
        "item_banana_chips", "item_baseball_bat", "item_basic_fishing_rod", "item_beans",
        "item_big_cup", "item_bighead_larva", "item_bloodlust_vial",
        "item_boombox", "item_boombox_fishing", "item_boombox_neon", "item_boomerang", "item_box_fan",
        "item_brain_chunk", "item_broccoli_grenade", "item_broccoli_shrink_grenade",
        "item_broom", "item_broom_halloween", "item_bubble_gun", "item_burrito",
        "item_butcherpipe", "item_butcherspear", "item_butchersword",
        "item_calculator", "item_cardboard_box", "item_cardboard_dragon_body", "item_cardboard_dragon_head",
        "item_ceo_plaque", "item_chakra", "item_clapper", "item_cluster_grenade", "item_coconut_shell",
        "item_cola", "item_cola_large", "item_company_ration", "item_company_ration_heal",
        "item_cracker", "item_crate", "item_crossbow", "item_crossbow_heart", "item_crowbar",
        "item_cubetrident", "item_cutie_dead",
        "item_d20", "item_demon_sword", "item_disc", "item_disposable_camera", "item_dragons_claw",
        "item_drill", "item_drill_neon", "item_dynamite", "item_dynamite_cube",
        "item_egg", "item_electrical_tape", "item_eraser",
        "item_film_reel", "item_finger_board",
        "item_fish_boomfish", "item_fish_boot", "item_fish_bottled_message", "item_fish_carp",
        "item_fish_chewna", "item_fish_clam_hookshot", "item_fish_crappie", "item_fish_crispie",
        "item_fish_diamond_jade_koi", "item_fish_dollar_bill", "item_fish_dragonfish",
        "item_fish_fishsword", "item_fish_gold_fish", "item_fish_hydracarp", "item_fish_kissy",
        "item_fish_license_plate", "item_fish_magma_carp", "item_fish_nebula_fish", "item_fish_nutfish",
        "item_fish_rainbow_trout", "item_fish_rotten_fish", "item_fish_salmon", "item_fish_salmonster",
        "item_fish_scaldfish", "item_fish_seamine", "item_fish_shellfish_shield", "item_fish_spicy_salmon",
        "item_fish_tuna", "item_fish_yellowcake", "item_fishing_terminal_bait_button",
        "item_flamethrower", "item_flamethrower_skull", "item_flamethrower_skull_ruby",
        "item_flaregun", "item_flashbang",
        "item_flashlight", "item_flashlight_mega", "item_flashlight_red",
        "item_flipflop_realistic", "item_floppy3", "item_floppy5", "item_football",
        "item_friend_launcher", "item_frying_pan",
        "item_gameboy", "item_glowstick", "item_goldbar", "item_goldcoin", "item_goop", "item_goopfish",
        "item_great_sword", "item_grenade", "item_grenade_gold", "item_grenade_launcher",
        "item_guided_boomerang",
        "item_hammer_candy_cane", "item_harddrive", "item_hatchet", "item_hawaiian_drum",
        "item_heart_chunk", "item_heart_gun", "item_heartchocolatebox", "item_hh_key",
        "item_hookshot", "item_hookshot_sword", "item_hot_cocoa", "item_hoverpad",
        "item_impulse_grenade", "item_jetpack", "item_joystick", "item_joystick_inv_y",
        "item_keycard", "item_lance", "item_landmine", "item_landmine_bee", "item_lantern_cny",
        "item_large_banana", "item_lava_fishing_rod", "item_love_grenade",
        "item_megaphone", "item_metal_ball", "item_metal_ball_xmas", "item_metal_plate",
        "item_metal_plate_xmas", "item_metal_rod", "item_metal_rod_xmas", "item_metal_triangle",
        "item_momboss_box", "item_moneygun", "item_mountain_key", "item_mug",
        "item_needle", "item_nut", "item_nut_drop",
        "item_ogre_hands",
        "item_ore_copper_l", "item_ore_copper_m", "item_ore_copper_s",
        "item_ore_gold_l", "item_ore_gold_m", "item_ore_gold_s",
        "item_ore_hell",
        "item_ore_silver_l", "item_ore_silver_m", "item_ore_silver_s",
        "item_painting_canvas", "item_paperpack", "item_pickaxe", "item_pickaxe_cny",
        "item_pickaxe_cube", "item_pickaxe_realistic", "item_pinata_bat", "item_pineapple",
        "item_pipe", "item_pistol_dragon", "item_plank", "item_plunger", "item_pogostick",
        "item_police_baton", "item_popcorn", "item_portable_teleporter", "item_prop_scanner",
        "item_pumpkin_bomb", "item_pumpkin_pie", "item_pumpkinjack", "item_pumpkinjack_small",
        "item_quest_gy_skull", "item_quest_gy_skull_special",
        "item_quest_hlal_brain", "item_quest_hlal_eyeball", "item_quest_hlal_flesh", "item_quest_hlal_heart",
        "item_quest_key_graveyard", "item_quiver", "item_quiver_heart",
        "item_radiation_gun", "item_radioactive_broccoli", "item_radioactive_fishing_rod",
        "item_randombox_mobloot_big", "item_randombox_mobloot_medium", "item_randombox_mobloot_small",
        "item_randombox_mobloot_weapons", "item_randombox_mobloot_zombie",
        "item_rare_card", "item_remote_controller",
        "item_revolver", "item_revolver_ammo", "item_revolver_gold", "item_ring_buoy",
        "item_robo_monke", "item_robot_arm_left", "item_robot_arm_right", "item_robot_head",
        "item_rope",
        "item_rpg_ammo", "item_rpg_ammo_egg", "item_rpg_ammo_spear", "item_rpg_cny",
        "item_rpg_easter", "item_rpg_smshr", "item_rpg_spear",
        "item_rubberducky", "item_ruby", "item_saddle", "item_salmoncannon",
        "item_sawblade", "item_sawblade_launcher", "item_scanner", "item_scissors", "item_server_pad",
        "item_shield", "item_shield_bones", "item_shield_candy_cane", "item_shield_police",
        "item_shield_viking_1", "item_shield_viking_2", "item_shield_viking_3", "item_shield_viking_4",
        "item_shotgun", "item_shotgun_ammo", "item_shotgun_viper",
        "item_shovel", "item_shredder", "item_shrinking_broccoli",
        "item_skipole", "item_skishoe", "item_skishoe_2", "item_skishoe_3", "item_skishoe_4",
        "item_snail_friend", "item_snowball",
        "item_snowboard", "item_snowboard_2", "item_snowboard_3", "item_snowboard_4", "item_snowboard_auto",
        "item_spear_candy_cane",
        "item_special_fishing_rod", "item_special_fishing_rod_radar_part", "item_special_fishing_rod_with_radar",
        "item_stapler", "item_stash_grenade",
        "item_steel_beam", "item_steel_beam_xmas",
        "item_stellarsword_blue", "item_stellarsword_gold",
        "item_stick_armbones", "item_stick_bone",
        "item_sticker_dispenser", "item_sticky_dynamite", "item_stinky_cheese",
        "item_tablet", "item_tapedispenser",
        "item_tele_grenade", "item_tele_pearl", "item_teleport_gun", "item_theremin",
        "item_timebomb",
        "item_toilet_paper", "item_toilet_paper_mega", "item_toilet_paper_roll_empty",
        "item_token_circus", "item_trampoline", "item_treestick", "item_tripwire_explosive",
        "item_trophy", "item_truss", "item_truss_xmas",
        "item_turkey_leg", "item_turkey_whole",
        "item_ukulele", "item_ukulele_gold",
        "item_umbrella", "item_umbrella_clover", "item_umbrella_squirrel",
        "item_unidentified", "item_upsidedown_loot",
        "item_uranium_chunk_l", "item_uranium_chunk_m", "item_uranium_chunk_s",
        "item_viking_hammer", "item_viking_hammer_twilight",
        "item_war_fan", "item_wheelhandle", "item_wheelhandle_big", "item_whoopie",
        "item_wood_log", "item_wood_pallet", "item_wyrmpiercer",
        "item_zipline_gun", "item_zombie_meat",
    ];
    // Full mob ID table — every mob the game can spawn. Newer entries (23, 25,
    // 33, 40, 44, 45, 46, 47) ported from FCS skid menu (2026-06-07 build).
    const mobIDs: { name: string; id: number }[] = [
        { name: "Angler", id: 1 }, { name: "AnglerMad", id: 2 }, { name: "Armstrong", id: 3 },
        { name: "ArmstrongMad", id: 4 }, { name: "Banshee", id: 5 }, { name: "Bomb", id: 6 },
        { name: "Bomber", id: 7 }, { name: "BomberFlashbang", id: 8 }, { name: "BomberMad", id: 9 },
        { name: "Chicken", id: 10 }, { name: "Cyst", id: 11 }, { name: "FakeGorilla", id: 12 },
        { name: "BigHead", id: 13 }, { name: "RedGreen", id: 14 }, { name: "Phantom", id: 15 },
        { name: "EvilEye", id: 16 }, { name: "GiantThrower", id: 17 }, { name: "RedGreenMad", id: 18 },
        { name: "Spider", id: 19 }, { name: "FlyingSwarm", id: 20 }, { name: "NextBot", id: 21 },
        { name: "Segway", id: 22 }, { name: "NextBotStatic", id: 23 },
        { name: "EvilEyePinata", id: 24 }, { name: "EvilEyePinataLarge", id: 25 },
        { name: "Lanky", id: 26 }, { name: "Blob", id: 27 }, { name: "Cutie", id: 28 },
        { name: "SpiderCave", id: 29 }, { name: "ForestMob", id: 30 }, { name: "Mimic", id: 31 },
        { name: "GraveyardBoss", id: 32 }, { name: "Ringmaster", id: 33 },
        { name: "Puppet", id: 34 }, { name: "PolypMass", id: 35 }, { name: "RobotDog", id: 36 },
        { name: "Shadow", id: 37 }, { name: "Heart", id: 38 }, { name: "Slimey", id: 39 },
        { name: "ShadowBoss", id: 40 },
        { name: "BigShark", id: 41 }, { name: "EdenZombie", id: 42 }, { name: "Skinwalker", id: 43 },
        { name: "YinWorm", id: 44 }, { name: "YangWorm", id: 45 },
        { name: "ArmstrongSpace", id: 46 }, { name: "Smiley", id: 47 },
    ];
    // Curated from M4 da.ts:742-859. Only REAL prefabs — vehicles, projectiles,
    // traps, spawners, doors, mob controllers, special scene objects, etc.
    // Item-shaped grabbables (Basketball, BigBanana, ChristmasBox, Net,
    // InflatedBalloon, etc.) intentionally excluded — those belong in the Items
    // tab, not here.
    const prefabIDs: string[] = [
        // ----- Vehicles & transport -----
        "Vehicle_Buggy",
        "SpawnableZipline",
        "TeleportMachine",
        "CoreTeleporter",
        "SpaceshipTeleporter",

        // ----- Weapons / projectiles / explosives -----
        "RPGRocket",
        "RPGRocketEgg",
        "RPGRocketSpear",
        "RobotDogRPG",
        "FlareGunProjectile",
        "GrenadeProjectile",
        "ExplosiveEgg",
        "ExplosiveEggClustered",
        "Landmine",

        // ----- Barrels (interactive, often explode) -----
        "BarrelExplodingDynamic",
        "BarrelExplodingStatic",
        "BarrelBeansDynamic",
        "BarrelBeansStatic",
        "BarrelOilDynamic",
        "BarrelOilStatic",

        // ----- Game mechanics -----
        "DummyTarget",
        "DummyPlayerTarget",
        "Duplicator",
        "ItemSellingMachineController",
        "ClawMachineNetObject",
        "DiggableGrave",
        "Shipwheel",
        "RiggedPlank",
        "StickyAnchor",
        "ScaffoldTrap",
        "FuelCanisterNetObject",
        "FuelCanisterSpawner",

        // ----- Mob spawners / controllers -----
        "HordeMobController",
        "HordeMobLobbyHandler",
        "NetMobSpawnGroup",
        "NetLootSpawnGroup",
        "MimicSpawner_CemeteryTile1",
        "MimicSpawner_CemeteryTile3",
        "TubeMonster",
        "SpiderController",
        "GiantController_GraveyardBoss_backup",

        // ----- Doors & gates -----
        "HingedDoorNetworked",
        "KeypadDoorNetObject",
        "SimpleKeypadDoor",
        "HatchdoorNetObject",
        "BigHatchdoorNetObject",
        "HatchdoorGrabHandle",
        "HH_LockedDoor",

        // ----- Lasers / puzzles -----
        "LaserSource",
        "LaserSink",
        "LaserMirror",

        // ----- Events / managers -----
        "ChristmasBoxManager",
        "ChoppableTreeManager",
        "TeleportationManager",
        "ThunderController",
        "BonfireController",
        "MazeManager",
        "SkiRaceController",
        "NetGameTimeManager",
        "RamEventNet",

        // ----- Special objects / scenes -----
        "FortuneTellerNet",
        "HellAltar",
        "MovieTheater",
        "Mausoleum_01",
        "GiantRockObject",
        "GiantRockObject_Fire",
        "BrainPowerPlug",
        "LootLantern",
        "Uvula",
        "GreenscreenNET",
        "RuinTower_FloatingPlatform",
        "RuinTower_FloatingSmall",

        // ----- Quest / collectible spawners -----
        "FourLeafQuest_FourLeafSpawner",
        "EasterEgg_QuestSpawner",
        "RadarPartSpawner",
        "Snail_Spawner",
        "LakePineapple_Spawner",
        "MountainKey_Spawner",
        "Spawner_Key",
        "LogQuestItemSpawner",
        "VHSQuests_VHSSpawner",
        "WinterFilm_ReelSpawner",
        "GenericWorldItemSpawner",
        "LockedDoor_KeySpawner",
    ];

    // Indices for cycling spawn lists.
    let itemIndex = 0, mobIndex = 0, prefabIndex = 0;

    // IL2CPP class refs (lazy, populated on first use).
    let PrefabGenCls: any = null;
    let NetPlayerCls: any = null;
    let MachineCtlrCls: any = null;
    let SFXManagerCls: any = null;       // M4's canonical NetworkRunner source
    let NULL_REF: any = null;
    function resolveModRefs(): boolean {
        if (PrefabGenCls && NetPlayerCls) return true;
        const acImage = getAcImage();
        if (!acImage) return false;
        try { PrefabGenCls = acImage.class("AnimalCompany.PrefabGenerator"); } catch (_) {}
        try { NetPlayerCls = acImage.class("AnimalCompany.NetPlayer"); } catch (_) {}
        try { MachineCtlrCls = acImage.class("AnimalCompany.ItemSellingMachineController"); } catch (_) {}
        try { SFXManagerCls = acImage.class("AnimalCompany.SFXManager"); } catch (_) {}
        try { NULL_REF = Il2Cpp.reference(Il2Cpp.domain.assembly("mscorlib").image.class("System.Object").alloc()); } catch (_) {}
        return !!(PrefabGenCls && NetPlayerCls);
    }

    // ===== M4 da.ts:1178 spawnItemAtPos =====
    let __spawnItemErrLogged = false;
    // Plain pass-through — Frida marshals [x,y,z] arrays directly into Vector3
    // when buildNullableFromValueType uses the correct inner type.
    function ensureV3(p: any): any { return p; }
    function spawnItemAtPos(bareID: string, pos: any, rot: any): any {
        try {
            if (!resolveModRefs()) {
                if (!__spawnItemErrLogged) { __spawnItemErrLogged = true; console.error("[spawnItemAtPos] PrefabGenerator class not resolved"); }
                return null;
            }
            const prefab = PrefabGenCls.method("GetItemPrefab", 1).invoke(Il2Cpp.string(bareID));
            if (prefab && !prefab.isNull?.()) {
                try {
                    const r = PrefabGenCls.method("SpawnItem", 4).invoke(prefab, pos, rot, NULL_REF);
                    if (r && !r.isNull?.()) return r;
                } catch (e) {
                    if (!__spawnItemErrLogged) { __spawnItemErrLogged = true; console.error(`[spawnItemAtPos] SpawnItem(prefab, ...) threw: ${e}`); }
                }
            }
            try { return PrefabGenCls.method("SpawnItem", 4).invoke(Il2Cpp.string(bareID), pos, rot, NULL_REF); }
            catch (e) {
                if (!__spawnItemErrLogged) { __spawnItemErrLogged = true; console.error(`[spawnItemAtPos] SpawnItem(string, ...) threw: ${e}`); }
                return null;
            }
        } catch (e) {
            if (!__spawnItemErrLogged) { __spawnItemErrLogged = true; console.error(`[spawnItemAtPos] outer threw: ${e}`); }
            return null;
        }
    }

    // ===== M4 da.ts:1761 spawnNetworkPrefab — VERBATIM port =====
    // Fusion's NetworkRunner.Spawn takes 6 args including Nullable<Vector3>,
    // Nullable<Quaternion>, Nullable<PlayerRef>. M4 introspects each Nullable
    // struct to build the right shape at call time. Simplified versions silently
    // fail because the overload count and arg types don't match.
    let __spawnNetErrLogged = false;
    let __spawnNetReady = false;
    function makeZeroForType(type: any): any {
        try {
            if (type.class.isEnum || type.isPrimitive) return 0;
            if (!type.class.isValueType) return NULL_REF;
            const fields = type.class.fields.filter((f: any) => !f.isStatic);
            if (fields.length === 0) return 0;
            return fields.map((f: any) => makeZeroForType(f.type));
        } catch (_) { return 0; }
    }
    function buildNullableArg(nullableType: any, hasValue: boolean, value: any): any[] {
        try {
            const fields = nullableType.class.fields.filter((f: any) => !f.isStatic);
            return fields.map((f: any) => {
                const lname = f.name.toLowerCase();
                if (lname.includes("hasvalue")) return hasValue ? 1 : 0;
                if (lname === "value") return hasValue ? value : makeZeroForType(f.type);
                return makeZeroForType(f.type);
            });
        } catch (_) { return [0, 0]; }
    }
    function normalizeValue(type: any, value: any): any {
        if (typeof value === "boolean") return value ? 1 : 0;
        try {
            if (value instanceof Il2Cpp.ValueType) {
                const fields = type.class.fields.filter((f: any) => !f.isStatic);
                if (fields.length === 0) return 0;
                return fields.map((f: any) => normalizeValue(f.type, f.bind(value).value));
            }
        } catch (_) {}
        if (Array.isArray(value)) return value.map((v: any) => normalizeValue(type, v));
        return value;
    }
    function buildNullableFromValueType(nullableType: any, valueRaw: any): any[] {
        // Find the inner value type from the Nullable's "value" field.
        // M4 reads it from `valueType.type` on the ValueType instance, but for
        // robustness we get it from the Nullable struct definition.
        let innerType: any = nullableType;
        try {
            for (const f of nullableType.class.fields) {
                if (!f.isStatic && f.name.toLowerCase() === "value") {
                    innerType = f.type;
                    break;
                }
            }
        } catch (_) {}
        return buildNullableArg(nullableType, true, normalizeValue(innerType, valueRaw));
    }

    function spawnNetworkPrefab(prefabName: string, pos: any, rot: any): any {
        pos = ensureV3(pos);
        try {
            if (!resolveModRefs()) {
                if (!__spawnNetErrLogged) { __spawnNetErrLogged = true; console.error("[spawnNetworkPrefab] PrefabGenerator class not resolved"); }
                return null;
            }
            const inst = PrefabGenCls.field("_instance").value;
            if (!inst || inst.isNull?.()) {
                if (!__spawnNetErrLogged) { __spawnNetErrLogged = true; console.error("[spawnNetworkPrefab] PrefabGen._instance null"); }
                return null;
            }
            const runner = inst.method("get_runner").invoke();
            if (!runner || runner.isNull?.()) {
                if (!__spawnNetErrLogged) { __spawnNetErrLogged = true; console.error("[spawnNetworkPrefab] runner null (not in a room?)"); }
                return null;
            }
            const sources = runner.field("_config").value.field("PrefabTable").value.field("_sources").value;
            const count = sources.method("get_Count").invoke() as number;
            const needle = String(prefabName).toLowerCase();
            for (let i = 0; i < count; i++) {
                try {
                    const source = sources.method("get_Item").invoke(i);
                    const desc = source.method("get_Description").invoke().toString();
                    if (!desc.toLowerCase().includes(needle)) continue;
                    const no = source.method("WaitForResult").invoke();
                    if (!no || no.isNull?.()) continue;
                    // Iterate runner.class.methods to find Spawn overloads — this
                    // version of frida-il2cpp-bridge doesn't expose .overloads().
                    const overloads: any[] = [];
                    try {
                        for (const m of runner.class.methods) {
                            try { if (m.name === "Spawn") overloads.push(m); } catch (_) {}
                        }
                    } catch (_) {}
                    if (!__spawnNetReady) {
                        console.log(`[spawnNetworkPrefab] runner.Spawn has ${overloads.length} overloads:`);
                        for (let k = 0; k < overloads.length; k++) {
                            try {
                                const m = overloads[k];
                                let sig = "";
                                try { sig = (m.parameters as any[]).map((p: any) => p.type.name).join(", "); } catch (_) {}
                                console.log(`  [${k}] argc=${m.parameterCount} generic=${m.isGeneric} sig=(${sig})`);
                            } catch (_) {}
                        }
                    }
                    // Find the 1-arg non-generic overload.
                    let simpleSpawn: any = null;
                    for (const m of overloads) {
                        try {
                            if (m.isGeneric || m.parameterCount !== 1) continue;
                            if ((m.parameters as any[])[0].type.name.includes("NetworkObject")) {
                                simpleSpawn = m; break;
                            }
                        } catch (_) {}
                    }
                    if (simpleSpawn) {
                        if (!__spawnNetReady) { __spawnNetReady = true; console.log(`[spawnNetworkPrefab] using simple 1-arg Spawn for '${prefabName}'`); }
                        const spawned = simpleSpawn.bind(runner).invoke(no);
                        if (spawned && !spawned.isNull?.()) {
                            // Move to requested position/rotation.
                            try {
                                const tf = getTransform(spawned);
                                if (tf && !tf.isNull?.()) {
                                    try { tf.method("set_position").invoke(pos); } catch (_) {}
                                    try { tf.method("set_rotation").invoke(rot); } catch (_) {}
                                }
                            } catch (_) {}
                            return spawned;
                        }
                    }
                    // Fallback: try M4's strict 6-arg approach.
                    let spawnMethod: any = null;
                    for (const m of overloads) {
                        if (m.parameterCount !== 6 || m.isGeneric) continue;
                        const p = m.parameters;
                        if (p[0].type.name.includes("Fusion.NetworkObject") &&
                            p[1].type.name.startsWith("System.Nullable") && p[1].type.name.includes("Vector3")) {
                            spawnMethod = m; break;
                        }
                    }
                    if (spawnMethod) {
                        try {
                            const posArg = buildNullableFromValueType(spawnMethod.parameters[1].type, pos);
                            const rotArg = buildNullableFromValueType(spawnMethod.parameters[2].type, rot);
                            const authArg = buildNullableArg(spawnMethod.parameters[3].type, false, makeZeroForType(spawnMethod.parameters[3].type));
                            const onBeforeArg = spawnMethod.parameters[4].type.class.isValueType ? makeZeroForType(spawnMethod.parameters[4].type) : NULL_REF;
                            if (!__spawnNetReady) { __spawnNetReady = true; console.log(`[spawnNetworkPrefab] using 6-arg Spawn (M4 pattern) for '${prefabName}'`); }
                            return spawnMethod.bind(runner).invoke(no, posArg, rotArg, authArg, onBeforeArg, 0);
                        } catch (e) {
                            if (!__spawnNetErrLogged) { __spawnNetErrLogged = true; console.error(`[spawnNetworkPrefab] 6-arg Spawn threw: ${e}`); }
                        }
                    }
                    if (!__spawnNetErrLogged) { __spawnNetErrLogged = true; console.error(`[spawnNetworkPrefab] no usable Spawn overload found`); }
                    return null;
                } catch (e) {
                    if (!__spawnNetErrLogged) { __spawnNetErrLogged = true; console.error(`[spawnNetworkPrefab] threw on prefab match: ${e}`); }
                }
            }
            if (!__spawnNetErrLogged) { __spawnNetErrLogged = true; console.error(`[spawnNetworkPrefab] prefab not found in PrefabTable: "${prefabName}"`); }
            return null;
        } catch (e) {
            if (!__spawnNetErrLogged) { __spawnNetErrLogged = true; console.error(`[spawnNetworkPrefab] outer threw: ${e}`); }
            return null;
        }
    }

    // ===== Local player transform refs (refreshed each frame) =====
    let localPlayer: any = null;
    let headColliderTf: any = null;
    let bodyColliderTf: any = null;
    let __plyRefErrLogged = false;
    let __plyRefReady = false;
    function refreshLocalPlayerRefs(): boolean {
        try {
            if (!resolveModRefs()) return false;
            const lp = NetPlayerCls.method("get_localPlayer").invoke();
            if (!lp || lp.isNull?.()) {
                if (!__plyRefErrLogged) { __plyRefErrLogged = true; console.error("[refreshLocalPlayerRefs] NetPlayer.localPlayer is null (not in room?)"); }
                return false;
            }
            localPlayer = lp;
            // 1.76.0 has these as plain Transform fields named "head"/"body"
            // (M4's da.ts used "headCollider"/"bodyCollider" from an older build).
            // Try the new names first; the old names fall back as Collider lookups.
            try {
                const hTf = lp.field("head").value;
                if (hTf && !hTf.isNull?.()) headColliderTf = hTf;
            } catch (_) {}
            if (!headColliderTf) {
                try {
                    const hc = lp.field("headCollider").value;
                    if (hc && !hc.isNull?.()) headColliderTf = getTransform(hc);
                } catch (_) {}
            }
            try {
                const bTf = lp.field("body").value;
                if (bTf && !bTf.isNull?.()) bodyColliderTf = bTf;
            } catch (_) {}
            if (!bodyColliderTf) {
                try {
                    const bc = lp.field("bodyCollider").value;
                    if (bc && !bc.isNull?.()) bodyColliderTf = getTransform(bc);
                } catch (_) {}
            }
            if (!__plyRefReady) {
                __plyRefReady = true;
                console.log(`[refreshLocalPlayerRefs] READY — headCollider=${!!headColliderTf} bodyCollider=${!!bodyColliderTf}`);
                // Dump NetPlayer fields so we can see what's there if collider names differ
                if (!headColliderTf || !bodyColliderTf) {
                    try {
                        console.log("[refreshLocalPlayerRefs] NetPlayer fields:");
                        const fields = lp.class.fields;
                        for (const f of fields) {
                            try {
                                const fn = f.name;
                                if (/collider|head|body|hand|transform/i.test(fn)) {
                                    console.log(`  field: ${fn} (type: ${f.type.name})`);
                                }
                            } catch (_) {}
                        }
                    } catch (_) {}
                }
            }
            return true;
        } catch (e) {
            if (!__plyRefErrLogged) { __plyRefErrLogged = true; console.error(`[refreshLocalPlayerRefs] threw: ${e}`); }
            return false;
        }
    }

    // Identity quaternion (cached so we don't keep building it).
    let identityQuat: any = null;
    function getIdentityQuat(): any {
        if (identityQuat) return identityQuat;
        try { identityQuat = Quaternion.method("get_identity").invoke(); } catch (_) {}
        return identityQuat;
    }

    // Track delta time between frames (for orbit angular increments).
    let lastTimeForDelta = 0;
    let lastDeltaTime = 1 / 60;
    function tickDeltaTime(): void {
        try {
            const now = TimeClass.method("get_time").invoke() as number;
            if (lastTimeForDelta > 0) lastDeltaTime = Math.max(0.001, Math.min(0.1, now - lastTimeForDelta));
            lastTimeForDelta = now;
        } catch (_) {}
    }

    // ============================================================
    // ===== BIG M4 HELPER LIBRARY PORT (da.ts 1162-4180 subset) =====
    // ============================================================
    let GBIClass_M4: any = null;
    let GBOClass_M4: any = null;
    let NManagerClass_M4: any = null;
    let RigidbodyClass_M4: any = null;
    let Vector3Class_M4: any = null;
    let DamageSourceInfoClass_M4: any = null;
    let m4RefsResolved = false;
    function resolveM4Refs(): boolean {
        if (m4RefsResolved) return true;
        const ac = getAcImage();
        if (!ac) return false;
        try { GBIClass_M4 = ac.class("AnimalCompany.GrabbableItem"); } catch (_) {}
        try { GBOClass_M4 = ac.class("AnimalCompany.GrabbableObject"); } catch (_) {}
        try { NManagerClass_M4 = ac.class("AnimalCompany.NetworkManager"); } catch (_) {}
        try { DamageSourceInfoClass_M4 = ac.class("AnimalCompany.DamageSourceInfo"); } catch (_) {}
        try {
            const phys = Il2Cpp.domain.assembly("UnityEngine.PhysicsModule").image;
            RigidbodyClass_M4 = phys.class("UnityEngine.Rigidbody");
        } catch (_) {}
        try { Vector3Class_M4 = UnityCore.class("UnityEngine.Vector3"); } catch (_) {}
        m4RefsResolved = !!(GBIClass_M4 || GBOClass_M4);
        return m4RefsResolved;
    }

    // === Input state (M4 da.ts:614-617, updateInput logic at 15690) ===
    let m4_leftGrab = false, m4_rightGrab = false, m4_leftTrigger = false, m4_rightTrigger = false;
    let m4_leftPrimary = false, m4_rightPrimary = false;
    // Joystick axes [-1..1] after deadzone. Right hand = primary look stick on
    // Quest; left hand = movement. Y is forward+/backward-.
    let m4_leftStickX = 0, m4_leftStickY = 0;
    let m4_rightStickX = 0, m4_rightStickY = 0;
    let xrInputReady = false;
    let xrInputDevicesCls: any = null;
    let xrCommonUsagesCls: any = null;
    let xrOutBool: any = null;
    let xrOutVec2: any = null;       // 8-byte scratch for Vector2 axis reads
    function resolveXRInput(): boolean {
        if (xrInputReady) return true;
        try {
            const img = Il2Cpp.domain.assembly("UnityEngine.XRModule").image;
            xrInputDevicesCls = img.class("UnityEngine.XR.InputDevices");
            xrCommonUsagesCls = img.class("UnityEngine.XR.CommonUsages");
            xrOutBool = Il2Cpp.alloc(1);
            xrOutVec2 = Il2Cpp.alloc(8);
            xrInputReady = !!(xrInputDevicesCls && xrCommonUsagesCls);
        } catch (_) {}
        return xrInputReady;
    }
    // Axis deadzone — discard noise around 0 so resting sticks don't drift.
    function axisDeadzone(v: number): number {
        return Math.abs(v) < 0.12 ? 0 : v;
    }
    // Read a Vector2 axis off an XR device; tries primary2DAxis, then
    // secondary2DAxis, then thumbstick — and picks the largest-magnitude
    // candidate (some runtimes only populate one of the three).
    function readAxis2D(dev: any): [number, number] {
        if (!xrOutVec2) return [0, 0];
        const readUsage = (usageName: string): [number, number] => {
            try {
                xrOutVec2.writeFloat(0);
                xrOutVec2.add(4).writeFloat(0);
                const usage = xrCommonUsagesCls.field(usageName).value;
                const ok = dev.method("TryGetFeatureValue", 2).invoke(usage, xrOutVec2);
                if (ok) {
                    return [
                        axisDeadzone(xrOutVec2.readFloat()),
                        axisDeadzone(xrOutVec2.add(4).readFloat()),
                    ];
                }
            } catch (_) {}
            return [0, 0];
        };
        const candidates: [number, number][] = [
            readUsage("primary2DAxis"),
            readUsage("secondary2DAxis"),
            readUsage("thumbstick"),
        ];
        let best: [number, number] = [0, 0];
        let bestMag = 0;
        for (const c of candidates) {
            const mag = Math.abs(c[0]) + Math.abs(c[1]);
            if (mag > bestMag) { best = c; bestMag = mag; }
        }
        return best;
    }
    function updateM4Input(): void {
        if (!resolveXRInput()) return;
        try {
            const leftDev = xrInputDevicesCls.method("GetDeviceAtXRNode", 1).invoke(4);
            const rightDev = xrInputDevicesCls.method("GetDeviceAtXRNode", 1).invoke(5);
            const readBool = (dev: any, usageName: string): boolean => {
                try {
                    const usage = xrCommonUsagesCls.field(usageName).value;
                    dev.method("TryGetFeatureValue", 2).invoke(usage, xrOutBool);
                    return xrOutBool.readU8() !== 0;
                } catch (_) { return false; }
            };
            m4_leftGrab = readBool(leftDev, "gripButton");
            m4_leftTrigger = readBool(leftDev, "triggerButton");
            m4_leftPrimary = readBool(leftDev, "primaryButton");
            m4_rightGrab = readBool(rightDev, "gripButton");
            m4_rightTrigger = readBool(rightDev, "triggerButton");
            m4_rightPrimary = readBool(rightDev, "primaryButton");
            const ls = readAxis2D(leftDev);
            const rs = readAxis2D(rightDev);
            m4_leftStickX = ls[0]; m4_leftStickY = ls[1];
            m4_rightStickX = rs[0]; m4_rightStickY = rs[1];
        } catch (_) {}
    }

    // === Smoothing + math helpers (M4 da.ts:2172-2192) ===
    function smoothNumber(current: number, target: number, amount: number = 0.18): number {
        return current + ((target - current) * amount);
    }
    function smoothVec3(
        state: [number, number, number],
        target: [number, number, number],
        amount: number = 0.18,
    ): [number, number, number] {
        state[0] = smoothNumber(state[0], target[0], amount);
        state[1] = smoothNumber(state[1], target[1], amount);
        state[2] = smoothNumber(state[2], target[2], amount);
        return state;
    }
    function normalizeXZ(x: number, z: number): [number, number] {
        const mag = Math.sqrt((x * x) + (z * z));
        if (mag < 0.0001) return [0, 1];
        return [x / mag, z / mag];
    }

    // === Hand transform refs (refreshed each frame) ===
    let rightHandTf: any = null;
    let leftHandTf: any = null;
    function refreshHandTransforms(): void {
        try {
            if (!resolveModRefs()) return;
            const lp = NetPlayerCls.method("get_localPlayer").invoke();
            if (lp && !lp.isNull?.()) {
                // 1.76.0 — NetPlayer.handRight / handLeft directly as Transform.
                try {
                    const r = lp.field("handRight").value;
                    if (r && !r.isNull?.()) rightHandTf = r;
                } catch (_) {}
                try {
                    const l = lp.field("handLeft").value;
                    if (l && !l.isNull?.()) leftHandTf = l;
                } catch (_) {}
            }
            // Fallback: GorillaLocomotion (M4's older path).
            if (!rightHandTf || !leftHandTf) {
                try {
                    const PlayerKlass = resolvePlayerClass();
                    if (PlayerKlass) {
                        let gl: any = null;
                        for (const f of ["<Instance>k__BackingField", "Instance", "instance"]) {
                            try { const v = PlayerKlass.field(f).value; if (v && !v.isNull?.()) { gl = v; break; } } catch (_) {}
                        }
                        if (gl) {
                            try { if (!rightHandTf) rightHandTf = gl.field("rightHandTransform").value; } catch (_) {}
                            try { if (!leftHandTf) leftHandTf = gl.field("leftHandTransform").value; } catch (_) {}
                        }
                    }
                } catch (_) {}
            }
        } catch (_) {}
    }

    // Construct a real UnityEngine.Vector3 ValueType from 3 numbers. Required
    // because Frida's struct marshalling chokes on plain JS arrays when passed
    // through Nullable<Vector3> wrappers — M4 always passes real Vector3
    // instances returned by get_position()/get_forward()/etc.
    function makeV3(x: number, y: number, z: number): any {
        try {
            if (!Vector3Class_M4) {
                try { Vector3Class_M4 = UnityCore.class("UnityEngine.Vector3"); } catch (_) {}
            }
            if (Vector3Class_M4) {
                const v = Vector3Class_M4.alloc();
                try { v.field("x").value = x; } catch (_) {}
                try { v.field("y").value = y; } catch (_) {}
                try { v.field("z").value = z; } catch (_) {}
                return v;
            }
        } catch (_) {}
        return [x, y, z];
    }

    // === readVec3Components (M4 da.ts:2181) ===
    function readVec3Components(vec: any): [number, number, number] {
        try {
            return [vec.field("x").value as number, vec.field("y").value as number, vec.field("z").value as number];
        } catch (_) { return [0, 0, 0]; }
    }

    // === trySetObjectVelocity (M4 da.ts:1836) — simplified ===
    function trySetObjectVelocity(obj: any, velocity: any): boolean {
        try {
            if (!obj || obj.isNull?.() || !RigidbodyClass_M4) return false;
            let rb: any = null;
            try { rb = getComponent(obj, RigidbodyClass_M4); } catch (_) {}
            if ((!rb || rb.isNull?.())) {
                try {
                    const go = obj.method("get_gameObject").invoke();
                    if (go && !go.isNull?.()) rb = getComponent(go, RigidbodyClass_M4);
                } catch (_) {}
            }
            if (rb && !rb.isNull?.()) {
                try { rb.method("set_isKinematic").invoke(false); } catch (_) {}
                try { rb.method("set_velocity").invoke(velocity); return true; } catch (_) {}
            }
        } catch (_) {}
        return false;
    }

    // === getLaunchForward (simplified) — negates transform.forward because the
    // right hand's forward axis in AC points toward the elbow, not the fingertips.
    // Projectiles were launching backward without this flip.
    function getLaunchForward(sourceTransform: any): any {
        try {
            const fwd = sourceTransform.method("get_forward").invoke();
            // Resolve Vector3 class lazily and use op_Multiply to negate (keeps
            // the result as a real Vector3 instance for LookRotation downstream).
            if (!Vector3Class_M4) {
                try { Vector3Class_M4 = UnityCore.class("UnityEngine.Vector3"); } catch (_) {}
            }
            if (Vector3Class_M4) {
                try { return Vector3Class_M4.method("op_Multiply", 2).invoke(fwd, -1); } catch (_) {}
            }
            return fwd;
        } catch (_) { return [0, 0, 1]; }
    }
    function getLaunchUp(sourceTransform: any, _forward: any): any {
        try { return sourceTransform.method("get_up").invoke(); } catch (_) { return [0, 1, 0]; }
    }
    function getLaunchRotation(sourceTransform: any, forward: any, up: any): any {
        try { return Quaternion.method("LookRotation", 2).invoke(forward, up); } catch (_) {}
        try { return sourceTransform.method("get_rotation").invoke(); } catch (_) { return getIdentityQuat(); }
    }

    // === Launch helper — spawns at fingertip. Sets position again AFTER spawn
    // because some Fusion projectiles' init code overrides the Spawn position
    // by re-anchoring to the player. ===
    function spawnAtHandLaunch(prefabName: string): any {
        if (!rightHandTf || rightHandTf.isNull?.()) return null;
        try {
            const fwd = getLaunchForward(rightHandTf);
            const up = getLaunchUp(rightHandTf, fwd);
            const pos = rightHandTf.method("get_position").invoke();
            const fx = (fwd.field?.("x")?.value as number) ?? 0;
            const fy = (fwd.field?.("y")?.value as number) ?? 0;
            const fz = (fwd.field?.("z")?.value as number) ?? 1;
            const FINGER_REACH = 0.35;
            const spawnPos = [
                (pos.field("x").value as number) + fx * FINGER_REACH,
                (pos.field("y").value as number) + fy * FINGER_REACH,
                (pos.field("z").value as number) + fz * FINGER_REACH,
            ];
            const rot = getLaunchRotation(rightHandTf, fwd, up);
            const spawned = spawnNetworkPrefab(prefabName, spawnPos, rot);
            // Force position again — overrides any projectile re-anchor logic.
            if (spawned && !spawned.isNull?.()) {
                try {
                    const tf = getTransform(spawned);
                    if (tf && !tf.isNull?.()) {
                        try { tf.method("set_position").invoke(spawnPos); } catch (_) {}
                        try { tf.method("set_rotation").invoke(rot); } catch (_) {}
                    }
                } catch (_) {}
            }
            return spawned;
        } catch (_) { return null; }
    }

    // === Launcher-style per-frame toggle flags ===
    let rocketLauncherEnabled = false;
    let flaregunEnabled = false;
    let boomspearEnabled = false;
    let robotDogRPGEnabled = false;
    let eggLauncherEnabled = false;
    let launchNextTime = 0;

    // === getPlayerStraightForward (M4 da.ts:3160) ===
    function getPlayerStraightForward(player: any): [number, number, number] {
        try {
            const tf = getTransform(player);
            const fwd = tf.method("get_forward").invoke();
            const x = fwd.field("x").value as number;
            const z = fwd.field("z").value as number;
            const mag = Math.sqrt(x * x + z * z);
            if (mag > 0.0001) return [x / mag, 0, z / mag];
        } catch (_) {}
        return [0, 0, 1];
    }

    // === getAllNetPlayersList (M4 da.ts:3012) ===
    function getAllNetPlayersList(includeLocal: boolean = true): any[] {
        const players: any[] = [];
        try {
            if (!resolveModRefs()) return players;
            const dict = NetPlayerCls.field("playerIDToNetPlayer").value;
            if (!dict || dict.isNull?.()) return players;
            const vals = dict.method("get_Values").invoke();
            const en = vals.method("GetEnumerator").invoke();
            while (en.method("MoveNext").invoke()) {
                const p = en.method("get_Current").invoke();
                if (!p || p.isNull?.()) continue;
                if (!includeLocal) {
                    try {
                        const local = NetPlayerCls.method("get_localPlayer").invoke();
                        if (local && !local.isNull?.() && p.handle.equals(local.handle)) continue;
                    } catch (_) {}
                }
                players.push(p);
            }
        } catch (_) {}
        return players;
    }

    // === Player identity / whitelist helpers (M4 da.ts:6-83 port) ===
    // M4 uses a normalized-string identity so it can match the same player
    // across alias forms (playerId / displayName / etc.). We keep that pattern.
    function normalizePlayerToken(value: any): string {
        try {
            if (value == null) return "";
            if (typeof value === "string") return value.trim();
            if (typeof value === "number" || typeof value === "boolean") return String(value).trim();
            if (value.content != null) return String(value.content).trim();
            return String(value).trim();
        } catch (_) { return ""; }
    }
    // First-time diagnostic so we can see what NetPlayer actually exposes on
    // this build. Dumps the names of every instance field + method to console
    // exactly once. Run it from getPlayerAliases the first time it can't find
    // a name; you'll see the available members and can add the right one here.
    let __netPlayerDumped = false;
    function dumpNetPlayerShape(p: any): void {
        if (__netPlayerDumped) return;
        __netPlayerDumped = true;
        try {
            const cls = p.class;
            console.log(`[ourmenu/players] NetPlayer class = ${cls?.type?.name ?? "?"}`);
            try {
                const fields: string[] = [];
                for (const f of cls.fields) {
                    if (f.isStatic) continue;
                    fields.push(`${f.name}:${f.type?.name ?? "?"}`);
                }
                console.log(`[ourmenu/players] fields (${fields.length}):`);
                for (let i = 0; i < fields.length; i += 6) {
                    console.log("  " + fields.slice(i, i + 6).join("  "));
                }
            } catch (e) { console.error("[ourmenu/players] field dump failed: " + e); }
            try {
                const methods: string[] = [];
                for (const m of cls.methods) {
                    if (m.isStatic) continue;
                    methods.push(m.name);
                }
                methods.sort();
                console.log(`[ourmenu/players] methods (${methods.length}):`);
                for (let i = 0; i < methods.length; i += 8) {
                    console.log("  " + methods.slice(i, i + 8).join("  "));
                }
            } catch (e) { console.error("[ourmenu/players] method dump failed: " + e); }
        } catch (e) {
            console.error("[ourmenu/players] dumpNetPlayerShape threw: " + e);
        }
    }

    // Best-effort identity collector. Tries every plausible name/id field +
    // method the obfuscator might have left intact. If everything fails, we
    // fall back to the player's GameObject name and finally to a "?" sentinel.
    function getPlayerAliases(p: any): string[] {
        const out: string[] = [];
        const push = (v: any) => {
            const t = normalizePlayerToken(v);
            if (!t || t === "?" || out.includes(t)) return;
            out.push(t);
        };
        // Methods — usually preserved through the obfuscator when they match
        // public Photon / Fusion API surfaces.
        const tryMethods = [
            "get_playerId", "get_PlayerId", "get_playerID",
            "get_displayName", "get_DisplayName",
            "get_nickName", "get_NickName", "get_nickname",
            "get_username", "get_Username", "get_userName", "get_UserName",
            "get_name", "get_Name",
            "ToString",
        ];
        for (const mn of tryMethods) {
            try { push(p.method(mn).invoke()); } catch (_) {}
        }
        // Fields — try backing-field variants too.
        const tryFields = [
            "_playerId", "playerId", "_PlayerId", "PlayerId",
            "_displayName", "displayName", "DisplayName",
            "_nickname", "nickname", "_nickName", "nickName",
            "_username", "username", "_userName", "userName", "Username",
            "_name", "name",
            "<playerId>k__BackingField",
            "<displayName>k__BackingField",
            "<nickname>k__BackingField",
            "<name>k__BackingField",
        ];
        for (const fn of tryFields) {
            try { push(p.field(fn).value); } catch (_) {}
        }
        // GameObject.name — almost always works as a last-resort fallback.
        try {
            const go = p.method("get_gameObject").invoke();
            if (go && !go.isNull?.()) {
                try { push(go.method("get_name").invoke()); } catch (_) {}
            }
        } catch (_) {}
        if (out.length === 0) {
            // We couldn't find anything readable — dump the class shape one
            // time so we can add the actual field name to the lists above.
            dumpNetPlayerShape(p);
            // Use the IL2CPP handle pointer as a unique-but-ugly stand-in
            // so each row still has a distinct key.
            try {
                const h = p.handle?.toString?.();
                if (h) out.push(`Player@${h}`);
            } catch (_) {}
        }
        return out.length > 0 ? out : ["?"];
    }
    function getPlayerName(p: any): string {
        const aliases = getPlayerAliases(p);
        return aliases.length > 1 ? aliases[1] : aliases[0];
    }
    function playerKeyOf(p: any): string {
        return getPlayerAliases(p)[0] || "?";
    }
    function playerIsLocal(p: any): boolean {
        try { return !!p.method("get_IsMine").invoke(); } catch (_) { return false; }
    }
    // Re-resolve a NetPlayer from a key string. NetPlayer references aren't
    // guaranteed stable across menu rebuilds, so we store keys and look up.
    function findPlayerByKey(key: string): any {
        if (!key) return null;
        try {
            for (const p of getAllNetPlayersList(true)) {
                if (playerKeyOf(p) === key) return p;
                // Also check aliases for resilience across alias kinds.
                const aliases = getPlayerAliases(p).map(a => a.toLowerCase());
                if (aliases.includes(key.toLowerCase())) return p;
            }
        } catch (_) {}
        return null;
    }
    // Whitelist — a Set of normalized lowercase tokens. Adding a player adds
    // every alias so later matches can find them by any form.
    const playerWhitelist: Set<string> = new Set<string>();
    function whitelistAddPlayer(p: any): void {
        for (const a of getPlayerAliases(p)) {
            const t = a.toLowerCase();
            if (t) playerWhitelist.add(t);
        }
    }
    function whitelistRemovePlayer(p: any): void {
        for (const a of getPlayerAliases(p)) {
            playerWhitelist.delete(a.toLowerCase());
        }
    }
    function whitelistHasPlayer(p: any): boolean {
        for (const a of getPlayerAliases(p)) {
            if (playerWhitelist.has(a.toLowerCase())) return true;
        }
        return false;
    }

    // === getPlayerHeldGrabbable (M4 da.ts:3269) ===
    function getPlayerHeldGrabbable(player: any, handIndex: number): any {
        try {
            const interactor = player.method("GetHandInteractor", 1).invoke(handIndex);
            if (!interactor || interactor.isNull?.()) return null;
            const itemAnchor = interactor.field("_itemAnchor").value;
            if (!itemAnchor || itemAnchor.isNull?.()) return null;
            const grabbable = itemAnchor.method("get_grabbableObject").invoke();
            if (!grabbable || grabbable.isNull?.()) return null;
            return grabbable;
        } catch (_) { return null; }
    }

    // === getGrabbableItemId (M4 da.ts:3675 — simplified) ===
    function getGrabbableItemId(grabbable: any): string {
        try {
            if (!grabbable || grabbable.isNull?.()) return "";
            const gbi = grabbable.method("GetComponent", 1).inflate(GBIClass_M4).invoke();
            if (gbi && !gbi.isNull?.()) {
                try {
                    const data = gbi.method("get_data").invoke();
                    if (data && !data.isNull?.()) {
                        const id = data.method("get_id").invoke();
                        if (id) return id.toString();
                    }
                } catch (_) {}
            }
        } catch (_) {}
        return "";
    }

    // === grabbableLooksLikeRevolver (M4 da.ts:3631) ===
    function grabbableLooksLikeRevolver(grabbable: any): boolean {
        try {
            const id = getGrabbableItemId(grabbable);
            return id.includes("revolver");
        } catch (_) {}
        return false;
    }

    // === spawnForwardLaunchedItem (M4 da.ts:1973) ===
    function spawnForwardLaunchedItem(bareID: string, sourceTransform: any, speed: number = 24.0, forwardOffset: number = 0.82): any {
        try {
            if (!sourceTransform || sourceTransform.isNull?.()) return null;
            const fwd = sourceTransform.method("get_forward").invoke();
            const pos = sourceTransform.method("get_position").invoke();
            const fx = fwd.field("x").value as number;
            const fy = fwd.field("y").value as number;
            const fz = fwd.field("z").value as number;
            const spawnPos = [
                (pos.field("x").value as number) + fx * forwardOffset,
                (pos.field("y").value as number) + fy * forwardOffset,
                (pos.field("z").value as number) + fz * forwardOffset,
            ];
            const idQ = getIdentityQuat();
            const item = spawnItemAtPos(bareID, spawnPos, idQ);
            if (item && !item.isNull?.()) {
                trySetObjectVelocity(item, [fx * speed, fy * speed, fz * speed]);
            }
            return item;
        } catch (_) { return null; }
    }

    // === spawnForwardLaunchedNetworkPrefab (M4 da.ts:1938) ===
    function spawnForwardLaunchedNetworkPrefab(prefabName: string, sourceTransform: any, speed: number = 30.0, forwardOffset: number = 1.0): any {
        try {
            if (!sourceTransform || sourceTransform.isNull?.()) return null;
            const fwd = sourceTransform.method("get_forward").invoke();
            const pos = sourceTransform.method("get_position").invoke();
            const fx = fwd.field("x").value as number;
            const fy = fwd.field("y").value as number;
            const fz = fwd.field("z").value as number;
            const spawnPos = [
                (pos.field("x").value as number) + fx * forwardOffset,
                (pos.field("y").value as number) + fy * forwardOffset,
                (pos.field("z").value as number) + fz * forwardOffset,
            ];
            const idQ = getIdentityQuat();
            const spawned = spawnNetworkPrefab(prefabName, spawnPos, idQ);
            if (spawned && !spawned.isNull?.()) {
                trySetObjectVelocity(spawned, [fx * speed, fy * speed, fz * speed]);
            }
            return spawned;
        } catch (_) { return null; }
    }

    // === collectAllLobbyItemsWithHeld (M4 da.ts:2231 — simplified version) ===
    function collectAllLobbyItemsWithHeld(): any[] {
        const out: any[] = [];
        try {
            if (!GBOClass_M4) return out;
            const all = Object_.method("FindObjectsByType", 1).inflate(GBOClass_M4).invoke(0);
            if (!all || all.isNull?.()) return out;
            const len = (all as any).length;
            for (let i = 0; i < len; i++) {
                try {
                    const o = (all as any).get(i);
                    if (o && !o.isNull?.()) out.push(o);
                } catch (_) {}
            }
        } catch (_) {}
        return out;
    }

    // === destroyNetworkedObjectDeep (M4 da.ts:4113 — simplified) ===
    function destroyNetworkedObjectDeep(obj: any): boolean {
        if (!obj || obj.isNull?.()) return false;
        try {
            // Try get runner.Despawn
            const inst = PrefabGenCls.field("_instance").value;
            const runner = inst.method("get_runner").invoke();
            if (runner && !runner.isNull?.()) {
                try { runner.method("Despawn").invoke(obj); return true; } catch (_) {}
            }
        } catch (_) {}
        try { Object_.method("Destroy", 1).invoke(obj); return true; } catch (_) {}
        return false;
    }

    // Time helper.
    function getNow(): number { try { return TimeClass.method("get_time").invoke() as number; } catch (_) { return 0; } }

    // ============================================================
    // ===== END M4 HELPER LIBRARY PORT =====
    // ============================================================

    // ============================================================
    // Per-frame state for spawn-based mods.
    // ============================================================
    let itemRainEnabled = false;
    let itemRainNext = 0;

    let itemTornadoEnabled = false;
    let itemTornadoEntries: any[] = [];

    let mobOrbitEnabled = false;
    let mobOrbitEntries: any[] = [];

    let prefabOrbitEnabled = false;
    let prefabOrbitEntries: any[] = [];

    let sellingmachineOrbitEnabled = false;
    let sellingmachineOrbitEntries: any[] = [];

    let sellingmachineTowerEnabled = false;
    let sellingmachineTowerEntries: any[] = [];

    let moonBuggyOrbitEnabled = false;
    let moonBuggyOrbitEntries: any[] = [];

    let christmasBoxOrbitEnabled = false;
    let christmasBoxOrbitEntries: any[] = [];

    let christmasPresentTowerEnabled = false;
    let christmasPresentTowerEntries: any[] = [];

    let treeForestEnabled = false;
    let treeForestEntries: any[] = [];

    let cageAllPlayersEnabled = false;
    let cageAllPlayersEntries: any[] = [];

    // === Per-frame mod state (more) ===
    let rpgHandsAllEnabled = false;
    let rpgHandsAllNext = 0;
    let buggyHandsEnabled = false;
    let buggyHandsNext = 0;
    let itemLauncherEnabled = false;
    let itemLauncherNext = 0;
    let rightHandDuperEnabled = false;
    let rightHandDuperNext = 0;
    let giveFlyAllEnabled = false;
    let giveFlyAllNext = 0;
    let itemLauncherAllEnabled = false;
    let itemLauncherAllNext = 0;
    let allPlayerGunBuffsEnabled = false;
    let allPlayerGunBuffsNext = 0;
    let goopSpammerEnabled = false;
    let goopSpammerNext = 0;
    let pissModEnabled = false;
    let pissModNext = 0;
    let spawnedGoopObjects: { object: any; expireAt: number }[] = [];
    let lagAllItemsEnabled = false;
    let lagAllItemsNext = 0;
    let nutPickupGunEnabled = false;
    let ammoPickupGunEnabled = false;
    let spawnNetPlayerTriggerEnabled = false;
    let spawnNetPlayerNext = 0;
    // === Kick Gun ===
    // Point your right hand at a player and pull the right trigger to kick the
    // one you're aiming at. One kick per trigger pull (rising-edge gated) so a
    // single pull can't spam the runner. Master client / authority still
    // required (same as Server Kick All — uses tryKickPlayerSimple).
    let kickGunEnabled = false;
    let kickGunTriggerWasHeld = false;   // edge state: true while the firing pull is held
    let kickGunNext = 0;                  // small cooldown so a held trigger re-fires slowly
    let kickGunDiagNext = 0;              // throttle for the once/sec aim diagnostic
    let kickGunLaser: any = null;         // the beam GameObject (world-space)
    // Aim cone: a target counts as "aimed at" when the angle between the aim ray
    // and the direction to the target is within this many degrees.
    const KICK_GUN_CONE_DEG = 30;
    const KICK_GUN_COOLDOWN = 0.35;       // seconds between kicks while held
    const KICK_GUN_LASER_THICK = 0.012;   // beam thickness (m) — 12 mm (chunky so it's easy to see)
    const KICK_GUN_LASER_MAXLEN = 40;     // beam length (m) when not locked on a player
    const KICK_GUN_LASER_LOCKED: [number, number, number, number] = [0.25, 1.0, 0.35, 1.0]; // green = locked on a player
    const KICK_GUN_LASER_FREE:   [number, number, number, number] = [1.0, 0.25, 0.25, 1.0]; // red = nothing in the cone
    let grantAllStashSlotsEnabled = false;
    let noContainerRestrictionsEnabled = false;
    let grabSellingMachineEnabled = false;
    let heldSellingMachineObj: any = null;
    // Movement / local-player fly state.
    let flyEnabled = false;
    let joystickFlyEnabled = false;
    // Running smoothed velocity that we ramp toward the desired direction so the
    // force application doesn't jolt the player. M4 keeps separate state for
    // fist-fly and joystick-fly so they don't fight each other.
    let fistFlyVelocity: [number, number, number] = [0, 0, 0];
    let joystickFlyVelocity: [number, number, number] = [0, 0, 0];

    // Players-tab state.
    // `selectedPlayerKey` is the key of the player whose detail view is open.
    let selectedPlayerKey: string | null = null;
    // Bulk-orbit toggles. "All" = every non-local player. "WL" = whitelisted only.
    let orbitPlayersAllEnabled = false;
    let orbitPlayersWLEnabled = false;
    let orbitPlayersAllFast = false;          // speed multiplier for All orbit
    // Per-player orbit ring. Keys are player keys (from playerKeyOf). Every
    // player in this set gets teleported around you each frame.
    const playerOrbitKeys: Set<string> = new Set<string>();
    // Master "filter bulk actions by whitelist" toggle (mirrors M4's
    // `whitelistEnabled`). When true, bulk player actions skip non-WL players.
    let whitelistEnabled = true;
    // Player list paging — same shape as the OP list.
    let playerListPage = 0;
    const PLAYERS_PER_PAGE = 7;

    // Per-frame mod runner (called from the Update hook). Handles "isTogglable"
    // mods that need active per-frame work, not just a method hook.
    function runPerFrameMods(): void {
        // Tick delta time + refresh local-player refs once per frame.
        tickDeltaTime();
        if (itemRainEnabled || itemTornadoEnabled || mobOrbitEnabled || prefabOrbitEnabled
            || sellingmachineOrbitEnabled || sellingmachineTowerEnabled || moonBuggyOrbitEnabled
            || christmasBoxOrbitEnabled || christmasPresentTowerEnabled || treeForestEnabled
            || cageAllPlayersEnabled || goopSpammerEnabled || pissModEnabled) {
            refreshLocalPlayerRefs();
        }
        const idQ = getIdentityQuat();

        // ===== Item Rain (M4 da.ts:6728-6745) =====
        if (itemRainEnabled && headColliderTf) {
            try {
                const now = TimeClass.method("get_time").invoke() as number;
                if (now > itemRainNext) {
                    itemRainNext = now + 0.08;
                    const hp = headColliderTf.method("get_position").invoke();
                    const spawnPos = [
                        (hp.field("x").value as number) + (Math.random() * 8 - 4),
                        (hp.field("y").value as number) + 9 + Math.random() * 4,
                        (hp.field("z").value as number) + (Math.random() * 8 - 4),
                    ];
                    spawnItemAtPos(itemIDs[itemIndex % itemIDs.length], spawnPos, idQ);
                }
            } catch (_) {}
        }

        // ===== Item Tornado (M4 da.ts:6965-7029) =====
        if (itemTornadoEnabled && bodyColliderTf) {
            try {
                const ct = TimeClass.method("get_time").invoke() as number;
                const cp = bodyColliderTf.method("get_position").invoke();
                const cx = cp.field("x").value as number, cy = cp.field("y").value as number, cz = cp.field("z").value as number;
                while (itemTornadoEntries.length < 24) {
                    const id = itemIDs[Math.floor(Math.random() * itemIDs.length)];
                    const sp = spawnItemAtPos(id, [cx + (Math.random() * 3 - 1.5), cy + 0.6 + Math.random() * 6, cz + (Math.random() * 3 - 1.5)], idQ);
                    if (!sp || sp.isNull?.()) break;
                    itemTornadoEntries.push({ obj: sp, angle: Math.random() * Math.PI * 2, radius: 2 + Math.random() * 3, height: 0.2 + Math.random() * 9, spin: 1.5 + Math.random() * 2.5 });
                }
                for (let i = itemTornadoEntries.length - 1; i >= 0; i--) {
                    const e = itemTornadoEntries[i];
                    if (!e || !e.obj || e.obj.isNull?.()) { itemTornadoEntries.splice(i, 1); continue; }
                    e.angle += lastDeltaTime * e.spin * 4;
                    const ty = cy + 0.4 + ((e.height + (ct * (1 + e.spin * 0.18))) % 10);
                    const r = 1 + (ty - cy) * 0.4 + Math.sin(ct * 2 + i) * 0.2;
                    const tx = cx + Math.cos(e.angle) * r, tz = cz + Math.sin(e.angle) * r;
                    try { getTransform(e.obj).method("set_position").invoke([tx, ty, tz]); } catch (_) {}
                }
            } catch (_) {}
        }

        // ===== Generic orbit runner (used by Mob/Prefab/Sellingmachine/Buggy/Tree/etc.) =====
        function tickOrbit(entries: any[], targetCount: number, baseRadius: number, spinSpeed: number, spawnFn: (i: number, pos: number[]) => any): void {
            if (!headColliderTf) {
                if (!(globalThis as any).__orbit_nohead_logged) {
                    (globalThis as any).__orbit_nohead_logged = true;
                    console.error("[orbit] headColliderTf is null — refreshLocalPlayerRefs didn't resolve NetPlayer.headCollider. Orbits won't spawn.");
                }
                return;
            }
            try {
                const ct = TimeClass.method("get_time").invoke() as number;
                const cp = headColliderTf.method("get_position").invoke();
                const cx = cp.field("x").value as number, cy = cp.field("y").value as number, cz = cp.field("z").value as number;
                while (entries.length < targetCount) {
                    const angle = (Math.PI * 2 * entries.length) / targetCount;
                    const pos = [cx + Math.cos(angle) * baseRadius, cy + 0.8, cz + Math.sin(angle) * baseRadius];
                    const sp = spawnFn(entries.length, pos);
                    if (!sp || sp.isNull?.()) {
                        if (!(globalThis as any).__orbit_spawn_failed_logged) {
                            (globalThis as any).__orbit_spawn_failed_logged = true;
                            console.error("[orbit] spawnFn returned null/empty — prefab name not in PrefabTable, or spawn failed. See [spawnNetworkPrefab] logs.");
                        }
                        break;
                    }
                    if (!(globalThis as any).__orbit_first_spawn_logged) {
                        (globalThis as any).__orbit_first_spawn_logged = true;
                        console.log(`[orbit] first object spawned successfully — orbit at center (${cx.toFixed(2)}, ${cy.toFixed(2)}, ${cz.toFixed(2)})`);
                    }
                    entries.push({ obj: sp, angle });
                }
                for (const e of entries) {
                    if (!e || !e.obj || e.obj.isNull?.()) continue;
                    e.angle += lastDeltaTime * spinSpeed;
                    const r = baseRadius + 0.2;
                    const px = cx + Math.cos(e.angle) * r;
                    const py = cy + 0.8 + Math.sin((e.angle * 2) + ct) * 0.25;
                    const pz = cz + Math.sin(e.angle) * r;
                    try { getTransform(e.obj).method("set_position").invoke([px, py, pz]); } catch (_) {}
                }
            } catch (e) {
                if (!(globalThis as any).__orbit_threw_logged) {
                    (globalThis as any).__orbit_threw_logged = true;
                    console.error(`[orbit] tickOrbit threw: ${e}`);
                }
            }
        }

        // ===== Mob Orbit (M4 da.ts:6842-6875) — uses prefab name from mob list =====
        if (mobOrbitEnabled) {
            const mob = mobIDs[mobIndex % mobIDs.length];
            tickOrbit(mobOrbitEntries, 6, 3, 1.8, () => spawnNetworkPrefab(mob.name, [0, 0, 0], idQ));
        }
        // ===== Prefab Orbit (M4 da.ts:6878-6925) =====
        if (prefabOrbitEnabled) {
            const pn = prefabIDs[prefabIndex % prefabIDs.length];
            tickOrbit(prefabOrbitEntries, 6, 3.1, 1.6, () => spawnNetworkPrefab(pn, [0, 0, 0], idQ));
        }
        // ===== Sellingmachine Orbit self / ChristmasBox Orbit self =====
        if (sellingmachineOrbitEnabled) {
            tickOrbit(sellingmachineOrbitEntries, 8, 3, 1.5, () => spawnNetworkPrefab("ItemSellingMachineController", [0, 0, 0], idQ));
        }
        if (christmasBoxOrbitEnabled) {
            tickOrbit(christmasBoxOrbitEntries, 8, 3, 1.5, () => spawnNetworkPrefab("ChristmasBox", [0, 0, 0], idQ));
        }
        if (moonBuggyOrbitEnabled) {
            tickOrbit(moonBuggyOrbitEntries, 8, 3.2, 1.4, () => spawnNetworkPrefab("Vehicle_Buggy", [0, 0, 0], idQ));
        }
        if (treeForestEnabled) {
            tickOrbit(treeForestEntries, 8, 3.5, 0.9, () => spawnNetworkPrefab("ChoppableTreeManager", [0, 0, 0], idQ));
        }
        // ===== Sellingmachine Tower Orbit (3-story) =====
        if (sellingmachineTowerEnabled && headColliderTf) {
            try {
                const cp = headColliderTf.method("get_position").invoke();
                const cx = cp.field("x").value as number, cy = cp.field("y").value as number, cz = cp.field("z").value as number;
                while (sellingmachineTowerEntries.length < 24) {
                    const idx = sellingmachineTowerEntries.length;
                    const story = Math.floor(idx / 8);
                    const angle = (Math.PI * 2 * (idx % 8)) / 8;
                    const pos = [cx + Math.cos(angle) * 3, cy + story * 1.6, cz + Math.sin(angle) * 3];
                    const sp = spawnNetworkPrefab("ItemSellingMachineController", pos, idQ);
                    if (!sp || sp.isNull?.()) break;
                    sellingmachineTowerEntries.push({ obj: sp });
                }
            } catch (_) {}
        }
        // ===== Christmas Present Tower (7-story) =====
        if (christmasPresentTowerEnabled && headColliderTf) {
            try {
                const cp = headColliderTf.method("get_position").invoke();
                const cx = cp.field("x").value as number, cy = cp.field("y").value as number, cz = cp.field("z").value as number;
                while (christmasPresentTowerEntries.length < 35) {  // 7 stories * 5 per
                    const idx = christmasPresentTowerEntries.length;
                    const story = Math.floor(idx / 5);
                    const angle = (Math.PI * 2 * (idx % 5)) / 5;
                    const pos = [cx + Math.cos(angle) * 2.2, cy + story * 1.0, cz + Math.sin(angle) * 2.2];
                    const sp = spawnNetworkPrefab("ChristmasBox", pos, idQ);
                    if (!sp || sp.isNull?.()) break;
                    christmasPresentTowerEntries.push({ obj: sp });
                }
            } catch (_) {}
        }

        // === RPG Hands All (M4 da.ts:6542-6580) ===
        if (rpgHandsAllEnabled) {
            try {
                const now = getNow();
                if (now > rpgHandsAllNext) {
                    rpgHandsAllNext = now + 0.035;
                    resolveM4Refs();
                    for (const p of getAllNetPlayersList(false)) {
                        try {
                            const rh = getPlayerHeldGrabbable(p, 1);
                            if (!grabbableLooksLikeRevolver(rh)) continue;
                            const ptf = getTransform(p);
                            const ppos = ptf.method("get_position").invoke();
                            const fwd = getPlayerStraightForward(p);
                            const spawnPos = [
                                (ppos.field("x").value as number) + fwd[0] * 0.72,
                                (ppos.field("y").value as number) - 0.025,
                                (ppos.field("z").value as number) + fwd[2] * 0.72,
                            ];
                            const rocket = spawnNetworkPrefab("RPGRocket", spawnPos, getIdentityQuat());
                            if (rocket && !rocket.isNull?.()) {
                                trySetObjectVelocity(rocket, [fwd[0] * 96, 1, fwd[2] * 96]);
                            }
                        } catch (_) {}
                    }
                }
            } catch (_) {}
        }
        // === Buggy Hands (M4 da.ts:6582-6599) ===
        if (buggyHandsEnabled) {
            try {
                const useRight = m4_rightGrab && m4_rightTrigger;
                const useLeft = m4_leftGrab && m4_leftTrigger;
                const now = getNow();
                if ((useRight || useLeft) && now > buggyHandsNext) {
                    buggyHandsNext = now + 0.05;
                    const ht = useRight ? rightHandTf : leftHandTf;
                    if (ht && !ht.isNull?.()) {
                        spawnForwardLaunchedNetworkPrefab("Vehicle_Buggy", ht, 155, 1.95);
                    }
                }
            } catch (_) {}
        }
        // === Item Launcher (M4 da.ts:6601-6618) ===
        if (itemLauncherEnabled) {
            try {
                const useRight = m4_rightGrab && m4_rightTrigger;
                const useLeft = m4_leftGrab && m4_leftTrigger;
                const now = getNow();
                if ((useRight || useLeft) && now > itemLauncherNext) {
                    itemLauncherNext = now + 0.055;
                    const ht = useRight ? rightHandTf : leftHandTf;
                    if (ht && !ht.isNull?.()) {
                        spawnForwardLaunchedItem(itemIDs[itemIndex % itemIDs.length], ht, 28, 0.92);
                    }
                }
            } catch (_) {}
        }
        // === Right Hand Duper (M4 da.ts:6620-6635, simplified) ===
        if (rightHandDuperEnabled) {
            try {
                const now = getNow();
                if (now > rightHandDuperNext && rightHandTf) {
                    rightHandDuperNext = now + 0.075;
                    if (NetPlayerCls) {
                        const lp = NetPlayerCls.method("get_localPlayer").invoke();
                        if (lp && !lp.isNull?.()) {
                            const held = getPlayerHeldGrabbable(lp, 1) ?? getPlayerHeldGrabbable(lp, 0);
                            if (held && !held.isNull?.()) {
                                const itemId = getGrabbableItemId(held);
                                if (itemId) spawnForwardLaunchedItem(itemId, rightHandTf, 14, 0.92);
                            }
                        }
                    }
                }
            } catch (_) {}
        }
        // === Give Fly All (M4 da.ts:6637-6659) ===
        if (giveFlyAllEnabled) {
            try {
                const now = getNow();
                if (now > giveFlyAllNext) {
                    giveFlyAllNext = now + 0.03;
                    for (const p of getAllNetPlayersList(false)) {
                        try {
                            const rh = getPlayerHeldGrabbable(p, 1);
                            if (!grabbableLooksLikeRevolver(rh)) continue;
                            const fwd = getPlayerStraightForward(p);
                            p.method("RPC_AddForce").invoke([fwd[0] * 0.54, 0.06, fwd[2] * 0.54]);
                        } catch (_) {}
                    }
                }
            } catch (_) {}
        }
        // === Item Launcher All (M4 da.ts:6661-6705) ===
        if (itemLauncherAllEnabled) {
            try {
                const now = getNow();
                if (now > itemLauncherAllNext) {
                    itemLauncherAllNext = now + 0.06;
                    for (const p of getAllNetPlayersList(false)) {
                        for (const handIdx of [0, 1]) {
                            try {
                                const held = getPlayerHeldGrabbable(p, handIdx);
                                if (!held || held.isNull?.()) continue;
                                const heldId = getGrabbableItemId(held);
                                if (!heldId) continue;
                                const ptf = getTransform(p);
                                const ppos = ptf.method("get_position").invoke();
                                const fwd = getPlayerStraightForward(p);
                                for (let i = 0; i < 3; i++) {
                                    const spawnPos = [
                                        (ppos.field("x").value as number) + fwd[0] * (0.55 + i * 0.08),
                                        (ppos.field("y").value as number) - 0.04,
                                        (ppos.field("z").value as number) + fwd[2] * (0.55 + i * 0.08),
                                    ];
                                    const item = spawnItemAtPos(heldId, spawnPos, getIdentityQuat());
                                    if (item && !item.isNull?.()) {
                                        trySetObjectVelocity(item, [fwd[0] * (22 + i * 3), 1, fwd[2] * (22 + i * 3)]);
                                    }
                                }
                            } catch (_) {}
                        }
                    }
                }
            } catch (_) {}
        }
        // === Goop Spammer (M4 da.ts:8129-8160) ===
        if (goopSpammerEnabled && bodyColliderTf) {
            try {
                const now = getNow();
                if (now > goopSpammerNext) {
                    goopSpammerNext = now + 0.032;
                    const bp = bodyColliderTf.method("get_position").invoke();
                    const fwd = readVec3Components(bodyColliderTf.method("get_forward").invoke());
                    const mag = Math.sqrt(fwd[0] * fwd[0] + fwd[2] * fwd[2]) || 1;
                    const fx = fwd[0] / mag, fz = fwd[2] / mag;
                    const spawnPos = [
                        (bp.field("x").value as number) + fx * 0.16 + (Math.random() * 0.03 - 0.015),
                        (bp.field("y").value as number) - 0.32,
                        (bp.field("z").value as number) + fz * 0.16 + (Math.random() * 0.03 - 0.015),
                    ];
                    const goop = spawnItemAtPos("item_goop", spawnPos, getIdentityQuat());
                    if (goop && !goop.isNull?.()) {
                        spawnedGoopObjects.push({ object: goop, expireAt: now + 2.2 });
                        trySetObjectVelocity(goop, [
                            fx * 8 + (Math.random() * 0.9 - 0.45),
                            -1 + Math.random() * 0.35,
                            fz * 8 + (Math.random() * 0.9 - 0.45),
                        ]);
                    }
                }
            } catch (_) {}
        }
        // === Piss Mod (M4 da.ts:8161-8175 + spawnGoopBurstAtTransform) — yellow goop ===
        if (pissModEnabled && bodyColliderTf) {
            try {
                const now = getNow();
                if (now > pissModNext) {
                    pissModNext = now + 0.055;
                    const bp = bodyColliderTf.method("get_position").invoke();
                    const fwdRaw = readVec3Components(bodyColliderTf.method("get_forward").invoke());
                    const mag = Math.sqrt(fwdRaw[0] * fwdRaw[0] + fwdRaw[2] * fwdRaw[2]) || 1;
                    const fx = fwdRaw[0] / mag, fz = fwdRaw[2] / mag;
                    const spawnPos = [
                        (bp.field("x").value as number) + fx * 0.14 + (Math.random() * 0.05 - 0.025),
                        (bp.field("y").value as number) - 0.28 + (Math.random() * 0.02 - 0.01),
                        (bp.field("z").value as number) + fz * 0.14 + (Math.random() * 0.05 - 0.025),
                    ];
                    const goop = spawnItemAtPos("item_goop", spawnPos, getIdentityQuat());
                    if (goop && !goop.isNull?.()) {
                        spawnedGoopObjects.push({ object: goop, expireAt: now + 2.2 });
                        try { goop.method("set_colorHue").invoke(56); } catch (_) {}
                        try { goop.method("set_colorSaturation").invoke(100); } catch (_) {}
                        try {
                            const goopGo = goop.method("get_gameObject").invoke();
                            if (goopGo && !goopGo.isNull?.()) {
                                try {
                                    if (GBOClass_M4) {
                                        const gbo = getComponent(goopGo, GBOClass_M4);
                                        if (gbo && !gbo.isNull?.()) {
                                            try { gbo.method("set_colorHue").invoke(56); } catch (_) {}
                                            try { gbo.method("set_colorSaturation").invoke(100); } catch (_) {}
                                        }
                                    }
                                } catch (_) {}
                                try {
                                    const rend = getComponent(goopGo, Renderer);
                                    if (rend && !rend.isNull?.()) {
                                        const mat = rend.method("get_material").invoke();
                                        if (mat && !mat.isNull?.()) {
                                            mat.method("set_color").invoke([1.0, 0.95, 0.12, 1.0]);
                                        }
                                    }
                                } catch (_) {}
                            }
                        } catch (_) {}
                        trySetObjectVelocity(goop, [
                            fx * 5.2 + (Math.random() * 0.95 - 0.475),
                            -1.0 + Math.random() * 0.35,
                            fz * 5.2 + (Math.random() * 0.95 - 0.475),
                        ]);
                    }
                }
            } catch (_) {}
        }
        // === Rapid Fire per-frame (M4 da.ts:9033-9115) ===
        if (rapidFireEnabled) {
            try {
                const now = getNow();
                if (now > rapidFirePulseDelay) {
                    rapidFirePulseDelay = now + 0.018;
                    if (!resolveModRefs()) { /* skip */ }
                    else {
                        const player = NetPlayerCls.method("get_localPlayer").invoke();
                        if (player && !player.isNull?.()) {
                            const fireHeld = (hand: number) => {
                                try {
                                    const interactor = player.method("GetHandInteractor", 1).invoke(hand);
                                    if (!interactor || interactor.isNull?.()) return;
                                    let held: any = null;
                                    try {
                                        const anchor = interactor.field("_itemAnchor").value;
                                        if (anchor && !anchor.isNull?.()) held = anchor.method("get_grabbableObject").invoke();
                                    } catch (_) {}
                                    if (!held || held.isNull?.()) return;
                                    const pressed = hand === 1 ? m4_rightTrigger : m4_leftTrigger;
                                    if (!pressed) return;
                                    const cn = String(held.class?.type?.name ?? "").toLowerCase();
                                    // Zero all cooldowns and max ammo
                                    try { held.field("_reloadTimer").value = 0.0; } catch (_) {}
                                    try { held.field("_triggerUseCooldown").value = 0.0; } catch (_) {}
                                    try { held.field("_secondaryUseCooldown").value = 0.0; } catch (_) {}
                                    if (cn.indexOf("revolver") >= 0) {
                                        try { held.field("_isHammerCocked").value = true; } catch (_) {}
                                        try { held.field("isHammerCocked").value = true; } catch (_) {}
                                        try { held.field("_ammoLoaded").value = 255; } catch (_) {}
                                        try { held.field("ammoLoaded").value = 255; } catch (_) {}
                                        try { held.field("_hammerPullbackAmount").value = 1.0; } catch (_) {}
                                        try { held.method("set_isHammerCocked").invoke(true); } catch (_) {}
                                        // Pulse secondary to cock hammer
                                        tryCallNames(held, ["HandleSecondaryUse", "HandleGripUse", "CockHammer", "PullBackHammer"], 0);
                                        tryCallNames(held, ["HandleSecondaryButton", "HandleSecondaryUse", "HandleGripUse"], 1, true);
                                        tryCallNames(held, ["HandleSecondaryButton", "HandleSecondaryUse", "HandleGripUse"], 1, false);
                                    }
                                    // Fire
                                    try { held.method("HandleTriggerUse").invoke(); } catch (_) {}
                                    if (cn.indexOf("revolver") >= 0) {
                                        try { held.field("_triggerUseCooldown").value = 0.0; } catch (_) {}
                                        try { held.method("set_isHammerCocked").invoke(true); } catch (_) {}
                                        for (let i = 0; i < 3; i++) {
                                            tryCallNames(held, ["OnBButtonDown", "HandleBButtonDown", "PressBButton"], 0);
                                            tryCallNames(held, ["HandleBButton", "HandleSecondaryButton", "HandleSecondaryUse"], 1, true);
                                            tryCallNames(held, ["HandleBButton", "HandleSecondaryButton", "HandleSecondaryUse"], 1, false);
                                        }
                                    }
                                } catch (_) {}
                            };
                            fireHeld(1); // right hand
                            fireHeld(0); // left hand
                        }
                    }
                }
            } catch (_) {}
        }
        // === Lag All Items (M4 da.ts:7032-7058) ===
        if (lagAllItemsEnabled) {
            try {
                const now = getNow();
                if (now > lagAllItemsNext) {
                    lagAllItemsNext = now + 0.06;
                    let idx = 0;
                    for (const item of collectAllLobbyItemsWithHeld()) {
                        if (!item || item.isNull?.()) continue;
                        const hue = Math.floor(Math.sin((now * 1.8) + (idx * 0.73)) * 127);
                        const sat = Math.floor(45 + (Math.sin((now * 1.3) + (idx * 0.51)) * 82));
                        const scl = Math.floor(Math.sin((now * 1.1) + (idx * 0.67)) * 70);
                        try {
                            item.method("set_colorHue").invoke(hue);
                            item.method("set_colorSaturation").invoke(sat);
                            item.method("set_scaleModifier").invoke(Math.max(-35, Math.min(95, scl)));
                        } catch (_) {}
                        idx++;
                    }
                }
            } catch (_) {}
        }
        // === Cage All Players (M4 da.ts:7063-7127) ===
        if (cageAllPlayersEnabled) {
            try {
                const targets = getAllNetPlayersList(false);
                if (targets.length > 0 && cageAllPlayersEntries.length === 0) {
                    const cageLayout: number[][] = [
                        [-1.8, -0.45, -1.8], [0.0, -0.45, -1.8], [1.8, -0.45, -1.8],
                        [-1.8, -0.45, 1.8], [0.0, -0.45, 1.8], [1.8, -0.45, 1.8],
                        [-1.8, 0.95, -1.8], [0.0, 0.95, -1.8], [1.8, 0.95, -1.8],
                        [-1.8, 0.95, 1.8], [0.0, 0.95, 1.8], [1.8, 0.95, 1.8],
                    ];
                    for (const p of targets) {
                        for (const off of cageLayout) {
                            const sp = spawnNetworkPrefab("ItemSellingMachineController", [0, 0, 0], getIdentityQuat());
                            if (!sp || sp.isNull?.()) continue;
                            cageAllPlayersEntries.push({ player: p, obj: sp, off });
                        }
                    }
                }
                for (const c of cageAllPlayersEntries) {
                    try {
                        const ppos = getTransform(c.player).method("get_position").invoke();
                        getTransform(c.obj).method("set_position").invoke([
                            (ppos.field("x").value as number) + c.off[0],
                            (ppos.field("y").value as number) + c.off[1],
                            (ppos.field("z").value as number) + c.off[2],
                        ]);
                    } catch (_) {}
                }
            } catch (_) {}
        }
        // === Nut Pickup Gun + Ammo Pickup Gun (M4 da.ts:7735-7770) ===
        if (nutPickupGunEnabled && m4_rightGrab && m4_rightTrigger && rightHandTf) {
            spawnForwardLaunchedItem("item_nut", rightHandTf, 18, 0.7);
        }
        if (ammoPickupGunEnabled && m4_rightGrab && m4_rightTrigger && rightHandTf) {
            spawnForwardLaunchedItem("item_revolver_ammo", rightHandTf, 18, 0.7);
        }
        // === Kick Gun ===
        // HOLD right GRIP → a laser shoots from your hand (green when it's
        // landed on a player, red when it's pointing at nothing). CLICK the
        // right TRIGGER while gripping → kick whoever the laser is on. Rising-
        // edge gated + cooldown so one click = one kick. Release grip → laser
        // off, no firing.
        if (kickGunEnabled && rightHandTf && m4_rightGrab) {
            refreshLocalPlayerRefs();          // keep head transform fresh for aiming
            const ray = kickGunAimRay();
            // Who is the laser currently landed on (if anyone)?
            const target = ray ? aimTargetPlayer(KICK_GUN_CONE_DEG) : null;
            // Beam length: stop at the locked player, else shoot out to max.
            let beamLen = KICK_GUN_LASER_MAXLEN;
            if (target && ray) {
                try {
                    const tp = readVec3Components(
                        target.method("get_transform").invoke().method("get_position").invoke()
                    );
                    beamLen = Math.min(
                        KICK_GUN_LASER_MAXLEN,
                        Math.hypot(tp[0] - ray.o[0], (tp[1] + 0.9) - ray.o[1], tp[2] - ray.o[2]),
                    );
                } catch (_) {}
            }
            if (ray) showKickGunLaser(ray.o, ray.d, beamLen, target ? KICK_GUN_LASER_LOCKED : KICK_GUN_LASER_FREE);

            // Throttled diagnostic (once/sec while gripping): how many players
            // we see and the best aim angle, so a miss is debuggable in console.
            try {
                let nowD = 0;
                try { nowD = TimeClass.method("get_time").invoke() as number; } catch (_) {}
                if (nowD >= kickGunDiagNext) {
                    kickGunDiagNext = nowD + 1.0;
                    const all = getAllNetPlayersList(false).filter((p: any) => p && !p.handle.isNull?.() && !playerIsLocal(p));
                    let bestDeg = 999;
                    if (ray) {
                        for (const p of all) {
                            try {
                                const tp = readVec3Components(p.method("get_transform").invoke().method("get_position").invoke());
                                let dx = tp[0] - ray.o[0], dy = (tp[1] + 0.9) - ray.o[1], dz = tp[2] - ray.o[2];
                                const dl = Math.hypot(dx, dy, dz) || 1;
                                const dot = ray.d[0] * dx / dl + ray.d[1] * dy / dl + ray.d[2] * dz / dl;
                                const deg = Math.acos(Math.max(-1, Math.min(1, dot))) * 180 / Math.PI;
                                if (deg < bestDeg) bestDeg = deg;
                            } catch (_) {}
                        }
                    }
                    console.log(`[ourmenu/kickgun] players=${all.length} bestAngle=${bestDeg === 999 ? "n/a" : bestDeg.toFixed(1) + "°"} cone=${KICK_GUN_CONE_DEG}° locked=${target ? "YES" : "no"}`);
                }
            } catch (_) {}

            // Fire on the rising edge of the trigger.
            const triggerNow = m4_rightTrigger;
            const rising = triggerNow && !kickGunTriggerWasHeld;
            kickGunTriggerWasHeld = triggerNow;
            if (rising) {
                let now = 0;
                try { now = TimeClass.method("get_time").invoke() as number; } catch (_) {}
                if (now >= kickGunNext) {
                    kickGunNext = now + KICK_GUN_COOLDOWN;
                    try {
                        if (!target) {
                            console.log("[ourmenu/kickgun] laser isn't on a player — nothing to kick");
                        } else {
                            // Authority-gated: grab master client first, then kick.
                            // If the first kick is rejected, take master client and
                            // retry once (the promotion often lands a frame late).
                            let ok = tryKickPlayerSimple(target);
                            if (!ok) {
                                const gotMc = tryBecomeMasterClient();
                                ok = tryKickPlayerSimple(target);
                                if (!ok) {
                                    console.log(`[ourmenu/kickgun] kick rejected — lobby won't grant authority (master-client grab ${gotMc ? "sent" : "failed"}). Try the "Give Masterclient" button, or you may not have host rights here.`);
                                }
                            }
                            if (ok) console.log("[ourmenu/kickgun] kicked the player the laser was on");
                        }
                    } catch (e) { console.error("[ourmenu/kickgun] FAILED: " + e); }
                }
            }
        } else {
            // Disabled, no hand, or grip released → hide the beam, reset edge.
            hideKickGunLaser();
            kickGunTriggerWasHeld = false;
        }
        // === Spawn NetPlayer Trigger (M4 da.ts:7163-7174) ===
        if (spawnNetPlayerTriggerEnabled && m4_rightTrigger && rightHandTf) {
            try {
                const now = getNow();
                if (now > spawnNetPlayerNext) {
                    spawnNetPlayerNext = now + 0.12;
                    spawnForwardLaunchedNetworkPrefab("NetPlayer", rightHandTf, 18, 1);
                }
            } catch (_) {}
        }
        // === Rocket Launcher / flaregun / boomspear / Robot Dog RPG / egg (M4 da.ts:7222-7316) ===
        // All fire continuously while right grip + right trigger are held.
        if ((rocketLauncherEnabled || flaregunEnabled || boomspearEnabled || robotDogRPGEnabled || eggLauncherEnabled)
            && m4_rightGrab && m4_rightTrigger) {
            const now = getNow();
            if (now > launchNextTime) {
                launchNextTime = now + getFireRate();
                if (rocketLauncherEnabled) spawnAtHandLaunch("RPGRocket");
                if (flaregunEnabled) spawnAtHandLaunch("FlareGunProjectile");
                if (boomspearEnabled) spawnAtHandLaunch("RPGRocketSpear");
                if (robotDogRPGEnabled) spawnAtHandLaunch("RobotDogRPG");
                if (eggLauncherEnabled) spawnAtHandLaunch("RPGRocketEgg");
            }
        }

        // === Grab Selling Machine (M4 da.ts:6794-6839) ===
        if (grabSellingMachineEnabled && m4_rightGrab && rightHandTf) {
            try {
                if (!heldSellingMachineObj || heldSellingMachineObj.isNull?.()) {
                    heldSellingMachineObj = spawnNetworkPrefab("ItemSellingMachineController", [0, 0, 0], getIdentityQuat());
                }
                if (heldSellingMachineObj && !heldSellingMachineObj.isNull?.()) {
                    const hp = rightHandTf.method("get_position").invoke();
                    const hf = rightHandTf.method("get_forward").invoke();
                    const target = [
                        (hp.field("x").value as number) + (hf.field("x").value as number) * 0.9,
                        (hp.field("y").value as number) + (hf.field("y").value as number) * 0.9,
                        (hp.field("z").value as number) + (hf.field("z").value as number) * 0.9,
                    ];
                    try { getTransform(heldSellingMachineObj).method("set_position").invoke(target); } catch (_) {}
                }
            } catch (_) {}
        }

        // === Spaz Explode Machine (M4 da.ts:6927-6963) ===
        if (spazExplodeMachineEnabled) {
            try {
                let now = 0;
                try { now = TimeClass.method("get_time").invoke() as number; } catch (_) {}
                if (now > spazExplodeNextTime) {
                    spazExplodeNextTime = now + 0.09;
                    const acImage = getAcImage();
                    if (!acImage) {
                        if (!(globalThis as any).__spaz_logged) {
                            (globalThis as any).__spaz_logged = true;
                            console.error("[spaz] AC image not loaded");
                        }
                    } else {
                        try {
                            // Try multiple class name candidates — AC may have renamed
                            const candidates = [
                                "AnimalCompany.ItemSellingMachineController",
                                "AnimalCompany.SellingMachineController",
                                "AnimalCompany.ItemSellingMachine",
                                "AnimalCompany.SellingMachine",
                            ];
                            let MachineCls: any = null;
                            let usedName = "";
                            for (const cls of candidates) {
                                try { MachineCls = acImage.class(cls); if (MachineCls) { usedName = cls; break; } } catch (_) {}
                            }
                            if (!MachineCls) {
                                if (!(globalThis as any).__spaz_logged) {
                                    (globalThis as any).__spaz_logged = true;
                                    console.error("[spaz] no machine class found. Tried: " + candidates.join(", "));
                                }
                                return;
                            }
                            const machines = Object_.method("FindObjectsByType", 1).inflate(MachineCls).invoke(0);
                            const len = (machines && !machines.isNull?.()) ? (machines as any).length : 0;
                            if (!(globalThis as any).__spaz_logged) {
                                (globalThis as any).__spaz_logged = true;
                                console.log(`[spaz] using ${usedName}, found ${len} machine(s)`);
                                if (len > 0) {
                                    // Dump methods on the first machine so we can see what's available
                                    try {
                                        const m0 = (machines as any).get(0);
                                        const allMethods: string[] = [];
                                        for (const m of m0.class.methods) {
                                            try {
                                                const n = m.name;
                                                if (/explode|detonate|blow|break|destroy|despawn|kill/i.test(n)) allMethods.push(n);
                                            } catch (_) {}
                                        }
                                        console.log(`[spaz] explode-like methods on machine: ${allMethods.length ? allMethods.join(", ") : "(none)"}`);
                                    } catch (e) { console.error("[spaz] method dump failed: " + e); }
                                }
                            }
                            if (len === 0) return;
                            // M4's full list of RPC name variants.
                            const explodeNames = [
                                "RPC_Explode", "Explode",
                                "RPC_Detonate", "Detonate",
                                "RPC_BlowUp", "BlowUp",
                                "RPC_TriggerExplosion", "TriggerExplosion",
                                "RPC_StartExplosion", "StartExplosion",
                                "RPC_ExplodeMachine", "ExplodeMachine",
                                "RPC_BreakMachine", "BreakMachine",
                                "RPC_DestroyMachine", "DestroyMachine",
                                "RPC_Despawn", "Despawn",
                                "RPC_Kill", "Kill",
                                "RPC_TakeDamage", "TakeDamage",
                                "RPC_Break", "Break",
                            ];
                            let killedAny = false;
                            for (let i = 0; i < len; i++) {
                                try {
                                    const machine = (machines as any).get(i);
                                    if (!machine || machine.isNull?.()) continue;
                                    let exploded = false;
                                    // Try each name with 0 args, then 1 arg (bool true), then 1 arg (int 999999) for damage methods.
                                    for (const mn of explodeNames) {
                                        try { machine.method(mn).invoke(); exploded = true; break; } catch (_) {}
                                        try { machine.method(mn, 0).invoke(); exploded = true; break; } catch (_) {}
                                        try { machine.method(mn, 1).invoke(true); exploded = true; break; } catch (_) {}
                                        try { machine.method(mn, 1).invoke(999999); exploded = true; break; } catch (_) {}
                                        try { machine.method(mn, 1).invoke(999999.0); exploded = true; break; } catch (_) {}
                                    }
                                    // Brute force fallback: despawn via NetworkRunner, then Destroy GameObject.
                                    if (!exploded) {
                                        try {
                                            const inst = PrefabGenCls.field("_instance").value;
                                            const runner = inst.method("get_runner").invoke();
                                            if (runner && !runner.isNull?.()) {
                                                try { runner.method("Despawn").invoke(machine); exploded = true; } catch (_) {}
                                            }
                                        } catch (_) {}
                                    }
                                    if (!exploded) {
                                        try {
                                            const go = machine.method("get_gameObject").invoke();
                                            if (go && !go.isNull?.()) {
                                                Object_.method("Destroy", 1).invoke(go);
                                                exploded = true;
                                            }
                                        } catch (_) {}
                                    }
                                    if (exploded) killedAny = true;
                                } catch (_) {}
                            }
                            if (killedAny && !(globalThis as any).__spaz_kill_logged) {
                                (globalThis as any).__spaz_kill_logged = true;
                                console.log(`[spaz] successfully acted on ${len} machine(s)`);
                            }
                        } catch (e) {
                            if (!(globalThis as any).__spaz_logged) {
                                (globalThis as any).__spaz_logged = true;
                                console.error("[spaz] threw: " + e);
                            }
                        }
                    }
                }
            } catch (_) {}
        }

        // ===== Fly (M4 da.ts:5006-5045) =====
        // Make a fist (grip + trigger) on either hand to apply a smoothed
        // forward force aimed where that hand is pointing. Both hands combine.
        if (flyEnabled) {
            const rightFist = m4_rightGrab && m4_rightTrigger;
            const leftFist  = m4_leftGrab  && m4_leftTrigger;
            if (!rightFist && !leftFist) {
                // Decay the cached velocity back to zero so release is smooth.
                fistFlyVelocity = smoothVec3(fistFlyVelocity, [0, 0, 0], 0.2);
            } else {
                try {
                    refreshLocalPlayerRefs();
                    refreshHandTransforms();
                    if (!NetPlayerCls) resolveModRefs();
                    const player = NetPlayerCls?.method("get_localPlayer").invoke();
                    if (player && !player.isNull?.()) {
                        let desired: [number, number, number] = [0, 0, 0];
                        if (rightFist && rightHandTf && !rightHandTf.isNull?.()) {
                            const f = readVec3Components(rightHandTf.method("get_forward").invoke());
                            desired[0] += f[0]; desired[1] += f[1]; desired[2] += f[2];
                        }
                        if (leftFist && leftHandTf && !leftHandTf.isNull?.()) {
                            const f = readVec3Components(leftHandTf.method("get_forward").invoke());
                            desired[0] += f[0]; desired[1] += f[1]; desired[2] += f[2];
                        }
                        const mag = Math.sqrt(
                            desired[0] * desired[0] +
                            desired[1] * desired[1] +
                            desired[2] * desired[2]);
                        if (mag >= 0.01) {
                            const speed = 0.32;
                            desired = [
                                (desired[0] / mag) * speed,
                                (desired[1] / mag) * speed,
                                (desired[2] / mag) * speed,
                            ];
                            const smoothed = smoothVec3(fistFlyVelocity, desired, 0.16);
                            try {
                                player.method("RPC_AddForce").invoke(smoothed);
                            } catch (e) {
                                if (!(globalThis as any).__fly_rpc_logged) {
                                    (globalThis as any).__fly_rpc_logged = true;
                                    console.error("[fly] RPC_AddForce threw: " + e);
                                }
                            }
                        }
                    }
                } catch (e) {
                    if (!(globalThis as any).__fly_logged) {
                        (globalThis as any).__fly_logged = true;
                        console.error("[fly] threw: " + e);
                    }
                }
            }
        }

        // ===== Joystick Fly (M4 da.ts:5128-5167) =====
        // Right thumbstick moves horizontally relative to head facing; left
        // stick Y moves vertically. Smoothed and dead-zoned.
        if (joystickFlyEnabled) {
            try {
                refreshLocalPlayerRefs();
                if (!NetPlayerCls) resolveModRefs();
                const player = NetPlayerCls?.method("get_localPlayer").invoke();
                if (player && !player.isNull?.() && headColliderTf) {
                    const fwdRaw = readVec3Components(headColliderTf.method("get_forward").invoke());
                    const rightRaw = readVec3Components(headColliderTf.method("get_right").invoke());
                    const [fX, fZ] = normalizeXZ(fwdRaw[0], fwdRaw[2]);
                    const [rX, rZ] = normalizeXZ(rightRaw[0], rightRaw[2]);
                    const moveForward = m4_rightStickY;
                    const moveSide    = m4_rightStickX;
                    const moveX = (fX * moveForward) + (rX * moveSide);
                    const moveZ = (fZ * moveForward) + (rZ * moveSide);
                    const moveY = m4_leftStickY * 0.95;
                    const mag = Math.sqrt((moveX * moveX) + (moveY * moveY) + (moveZ * moveZ));
                    if (mag < 0.025) {
                        joystickFlyVelocity = smoothVec3(joystickFlyVelocity, [0, 0, 0], 0.32);
                    } else {
                        const speed = 0.34;
                        const scale = Math.min(1.25, mag * 1.4);
                        const desired: [number, number, number] = [
                            (moveX / mag) * speed * scale,
                            (moveY / mag) * speed * scale,
                            (moveZ / mag) * speed * scale,
                        ];
                        const smoothed = smoothVec3(joystickFlyVelocity, desired, 0.22);
                        try {
                            player.method("RPC_AddForce").invoke(smoothed);
                        } catch (e) {
                            if (!(globalThis as any).__jfly_rpc_logged) {
                                (globalThis as any).__jfly_rpc_logged = true;
                                console.error("[joystick-fly] RPC_AddForce threw: " + e);
                            }
                        }
                    }
                }
            } catch (e) {
                if (!(globalThis as any).__jfly_logged) {
                    (globalThis as any).__jfly_logged = true;
                    console.error("[joystick-fly] threw: " + e);
                }
            }
        }

        // ===== Player orbits (M4 da.ts:6233-6291 port) =====
        // Three variants share the same math: list of target NetPlayers, spin
        // them around your head every frame using RPC_Teleport.
        //   All  → every non-local player
        //   WL   → only whitelisted players
        //   Per-player → only players whose key is in playerOrbitKeys
        const needPlayerOrbit =
            orbitPlayersAllEnabled || orbitPlayersWLEnabled || playerOrbitKeys.size > 0;
        if (needPlayerOrbit) {
            try {
                refreshLocalPlayerRefs();
                if (headColliderTf) {
                    const tnow = TimeClass.method("get_time").invoke() as number;
                    const cp = headColliderTf.method("get_position").invoke();
                    const cx = cp.field("x").value as number;
                    const cy = cp.field("y").value as number;
                    const cz = cp.field("z").value as number;
                    const radius = 3.5;
                    // Fast mode uses 3× spin.
                    const spinRate = orbitPlayersAllFast ? (1.85 * 3.0) : 1.85;
                    const spin = tnow * spinRate;
                    // Build target list. De-dup by key so a player in both
                    // playerOrbitKeys and the All/WL pool only orbits once.
                    const seen = new Set<string>();
                    const targets: any[] = [];
                    const allPlayers = getAllNetPlayersList(false);
                    for (const p of allPlayers) {
                        const k = playerKeyOf(p);
                        let include = false;
                        if (orbitPlayersAllEnabled) include = true;
                        else if (orbitPlayersWLEnabled && whitelistHasPlayer(p)) include = true;
                        else if (playerOrbitKeys.has(k)) include = true;
                        if (include && !seen.has(k)) {
                            seen.add(k);
                            targets.push(p);
                        }
                    }
                    const n = targets.length;
                    for (let i = 0; i < n; i++) {
                        const p = targets[i];
                        if (!p || p.isNull?.()) continue;
                        const angle = spin + ((i / Math.max(n, 1)) * Math.PI * 2);
                        const wobble = Math.sin((angle * 2.0) + (tnow * (orbitPlayersAllFast ? 1.2 : 0.4))) * 0.25;
                        const orbitPos: [number, number, number] = [
                            cx + Math.cos(angle) * radius,
                            cy + 0.15 + wobble,
                            cz + Math.sin(angle) * radius,
                        ];
                        try { p.method("RPC_Teleport").invoke(orbitPos); } catch (_) {}
                    }
                }
            } catch (e) {
                if (!(globalThis as any).__porbit_logged) {
                    (globalThis as any).__porbit_logged = true;
                    console.error("[player-orbit] threw: " + e);
                }
            }
        }

        // ===== WL bulk loops (M4 da.ts:12053-12159 port) =====
        // Each loop iterates every netplayer at a throttled interval, applying
        // the buff/heal/effect only to whitelisted players. whitelistEnabled
        // gates the WL filter (matches M4: when false, loops affect EVERYONE,
        // which is the explicit user intent of toggling whitelist off).
        if (wlAllSpeedLoopEnabled || wlAllAntiGravLoopEnabled
            || wlInvincibleLoopEnabled || wlReviveLoopEnabled
            || wlRainbowLoopEnabled) {
            try {
                const now = TimeClass.method("get_time").invoke() as number;
                let snapshot: any[] | null = null;
                const getSnapshot = (): any[] => {
                    if (snapshot === null) snapshot = getAllNetPlayersList(false);
                    return snapshot;
                };

                // Speed buff every 3s.
                if (wlAllSpeedLoopEnabled && now >= wlSpeedLoopNext) {
                    wlSpeedLoopNext = now + 3.0;
                    for (const p of getSnapshot()) {
                        if (!p || p.handle.isNull?.() || playerIsLocal(p)) continue;
                        if (whitelistEnabled && !whitelistHasPlayer(p)) continue;
                        try { p.method("RPC_ApplyBuff").invoke(1); } catch (_) {}
                    }
                }
                // AntiGrav every 3s.
                if (wlAllAntiGravLoopEnabled && now >= wlAntiGravLoopNext) {
                    wlAntiGravLoopNext = now + 3.0;
                    for (const p of getSnapshot()) {
                        if (!p || p.handle.isNull?.() || playerIsLocal(p)) continue;
                        if (whitelistEnabled && !whitelistHasPlayer(p)) continue;
                        try { p.method("RPC_ApplyBuff").invoke(7); } catch (_) {}
                    }
                }
                // Invincibility re-asserted every 1s.
                if (wlInvincibleLoopEnabled && now >= wlInvincibleLoopNext) {
                    wlInvincibleLoopNext = now + 1.0;
                    for (const p of getSnapshot()) {
                        if (!p || p.handle.isNull?.() || playerIsLocal(p)) continue;
                        if (whitelistEnabled && !whitelistHasPlayer(p)) continue;
                        try { p.method("set_isInvincible").invoke(true); } catch (_) {}
                    }
                }
                // Auto-revive every 0.5s — only fires on dead players.
                if (wlReviveLoopEnabled && now >= wlReviveLoopNext) {
                    wlReviveLoopNext = now + 0.5;
                    for (const p of getSnapshot()) {
                        if (!p || p.handle.isNull?.() || playerIsLocal(p)) continue;
                        if (whitelistEnabled && !whitelistHasPlayer(p)) continue;
                        try {
                            const dead = p.method("get_isDie").invoke() as boolean;
                            if (dead) p.method("RPC_DoPlayerDie").invoke(false);
                        } catch (_) {}
                    }
                }
                // Rainbow — runs EVERY frame so the color cycles smoothly.
                if (wlRainbowLoopEnabled) {
                    const h = (now * 0.5) % 1.0;
                    for (const p of getSnapshot()) {
                        if (!p || p.handle.isNull?.() || playerIsLocal(p)) continue;
                        if (whitelistEnabled && !whitelistHasPlayer(p)) continue;
                        try { p.method("RPC_SetColorHSV").invoke(99999.0, h, 1.0, 1.0); } catch (_) {}
                    }
                }
            } catch (e) {
                if (!(globalThis as any).__wl_loop_logged) {
                    (globalThis as any).__wl_loop_logged = true;
                    console.error("[ourmenu/wl-loop] threw: " + e);
                }
            }
        }

        // === Goop cleanup loop (M4 da.ts:17290-17309) ===
        if (spawnedGoopObjects.length > 0) {
            const now = getNow();
            for (let i = spawnedGoopObjects.length - 1; i >= 0; i--) {
                try {
                    const entry = spawnedGoopObjects[i];
                    if (!entry || !entry.object || entry.object.isNull?.() || now >= entry.expireAt) {
                        try {
                            if (entry?.object && !entry.object.isNull?.()) {
                                let go = entry.object;
                                try {
                                    const maybeGo = entry.object.method("get_gameObject").invoke();
                                    if (maybeGo && !maybeGo.isNull?.()) go = maybeGo;
                                } catch (_) {}
                                Object_.method("Destroy", 1).invoke(go);
                            }
                        } catch (_) {}
                        spawnedGoopObjects.splice(i, 1);
                    }
                } catch (_) {
                    spawnedGoopObjects.splice(i, 1);
                }
            }
        }
    }

    // ----- Player-action helpers (one-shot Bring/Goto/Launch/etc.) -----
    // Each takes a NetPlayer ref or a key; the key form re-resolves first.
    function playerBring(p: any): boolean {
        try {
            refreshLocalPlayerRefs();
            if (!localPlayer || !headColliderTf) return false;
            const hp = headColliderTf.method("get_position").invoke();
            const x = hp.field("x").value as number;
            const y = hp.field("y").value as number;
            const z = hp.field("z").value as number;
            // Drop them slightly in front of you, not on your head.
            try {
                const fwd = readVec3Components(headColliderTf.method("get_forward").invoke());
                p.method("RPC_Teleport").invoke([x + fwd[0] * 1.2, y, z + fwd[2] * 1.2]);
            } catch (_) {
                p.method("RPC_Teleport").invoke([x, y, z]);
            }
            return true;
        } catch (e) { console.error("[player/bring] " + e); return false; }
    }
    function playerGoto(p: any): boolean {
        try {
            refreshLocalPlayerRefs();
            const tt = p.method("get_transform").invoke();
            const tp = tt.method("get_position").invoke();
            const tx = tp.field("x").value as number;
            const ty = tp.field("y").value as number;
            const tz = tp.field("z").value as number;
            // Teleport YOURSELF to them. Some builds block self-RPC; we attempt
            // it on the local player as a normal call (RPC_Teleport is usually
            // accepted from local for client-side movement).
            if (!localPlayer) return false;
            try {
                localPlayer.method("RPC_Teleport").invoke([tx, ty + 0.05, tz]);
            } catch (_) {
                // Fallback: position the rig transform directly.
                try {
                    const myTr = localPlayer.method("get_transform").invoke();
                    myTr.method("set_position").invoke([tx, ty + 0.05, tz]);
                } catch (_) { return false; }
            }
            return true;
        } catch (e) { console.error("[player/goto] " + e); return false; }
    }
    function playerLaunchUp(p: any, strength: number = 1500): boolean {
        try { p.method("RPC_AddForce").invoke([0, strength, 0]); return true; }
        catch (e) { console.error("[player/launch] " + e); return false; }
    }
    function playerSendFloor(p: any): boolean {
        try { p.method("RPC_Teleport").invoke([0, -99999, 0]); return true; }
        catch (e) { console.error("[player/floor] " + e); return false; }
    }
    function playerKill(p: any): boolean {
        try { p.method("RPC_DoPlayerDie").invoke(true); return true; }
        catch (e) { console.error("[player/kill] " + e); return false; }
    }
    function playerRevive(p: any): boolean {
        try { p.method("RPC_DoPlayerDie").invoke(false); return true; }
        catch (e) { console.error("[player/revive] " + e); return false; }
    }

    // ===== M4 WL one-shot action ports (da.ts:8425-9000 — gun-targeted there,
    //       direct-per-player here since ourmenu's Players tab already has the
    //       target reference). =====
    // Per-player one-shots: each takes the NetPlayer ref and applies one RPC.
    // Return true on success, false on any RPC failure.
    function playerStinky(p: any): boolean {
        try { p.method("RPC_TagAsStinky").invoke(); return true; }
        catch (e) { console.error("[player/stinky] " + e); return false; }
    }
    function playerSpeedBuff(p: any): boolean {
        try { p.method("RPC_ApplyBuff").invoke(1); return true; }
        catch (e) { console.error("[player/speedbuff] " + e); return false; }
    }
    function playerStunFor(p: any, seconds: number): boolean {
        try {
            const tp = p.method("get_transform").invoke().method("get_position").invoke();
            p.method("RPC_PlayerStun").invoke(tp, seconds, seconds, 1);
            return true;
        } catch (e) { console.error("[player/stun] " + e); return false; }
    }
    function playerInvisible(p: any): boolean {
        try {
            let cur = false;
            try { cur = p.method("get_isHide").invoke() as boolean; } catch (_) {}
            try { p.method("set_isHide").invoke(!cur); } catch (_) {}
            try { p.method("RPC_SetHide").invoke(!cur); } catch (_) {}
            return true;
        } catch (e) { console.error("[player/invisible] " + e); return false; }
    }
    function playerRainbowOnce(p: any): boolean {
        try {
            const t = TimeClass.method("get_time").invoke() as number;
            const h = (t * 0.5) % 1.0;
            p.method("RPC_SetColorHSV").invoke(99999.0, h, 1.0, 1.0);
            return true;
        } catch (e) { console.error("[player/rainbow] " + e); return false; }
    }
    function playerFreeze(p: any): boolean {
        // 9999s stun = effectively permanent freeze
        try {
            const tp = p.method("get_transform").invoke().method("get_position").invoke();
            p.method("RPC_PlayerStun").invoke(tp, 999.0, 9999.0, 0);
            return true;
        } catch (e) { console.error("[player/freeze] " + e); return false; }
    }
    function playerVoid(p: any): boolean {
        try { p.method("RPC_Teleport").invoke([0, -99999, 0]); return true; }
        catch (e) { console.error("[player/void] " + e); return false; }
    }
    function playerInvincibleToggle(p: any): boolean {
        try {
            let cur = false;
            try { cur = p.method("get_isInvincible").invoke() as boolean; } catch (_) {}
            try { p.method("set_isInvincible").invoke(!cur); } catch (_) {}
            return true;
        } catch (e) { console.error("[player/invincible] " + e); return false; }
    }

    // ===== M4 bulk WL action ports (da.ts:8998-9039 + 12053-12178). =====
    // One-shot bulk actions.
    function wlClear(): number {
        const n = playerWhitelist.size;
        playerWhitelist.clear();
        console.log(`[ourmenu/wl] Cleared whitelist (${n} entries removed)`);
        return n;
    }
    function wlList(): string[] {
        const arr = Array.from(playerWhitelist);
        console.log(`[ourmenu/wl] Whitelist (${arr.length}): ${arr.join(", ")}`);
        return arr;
    }
    function wlReviveAll(): number {
        let count = 0;
        try {
            for (const p of getAllNetPlayersList(false)) {
                if (!p || p.handle.isNull?.() || playerIsLocal(p)) continue;
                if (whitelistEnabled && !whitelistHasPlayer(p)) continue;
                try { p.method("RPC_DoPlayerDie").invoke(false); count++; } catch (_) {}
            }
        } catch (e) { console.error("[ourmenu/wl] reviveAll: " + e); }
        console.log(`[ourmenu/wl] Revived ${count} WL players`);
        return count;
    }
    function wlTpAll2Me(): number {
        let count = 0;
        try {
            refreshLocalPlayerRefs();
            if (!headColliderTf) { console.error("[ourmenu/wl] tpAll2Me: no headColliderTf"); return 0; }
            const hp = headColliderTf.method("get_position").invoke();
            const myPos: [number, number, number] = [
                hp.field("x").value as number,
                hp.field("y").value as number,
                hp.field("z").value as number,
            ];
            for (const p of getAllNetPlayersList(false)) {
                if (!p || p.handle.isNull?.() || playerIsLocal(p)) continue;
                if (whitelistEnabled && !whitelistHasPlayer(p)) continue;
                try { p.method("RPC_Teleport").invoke(myPos); count++; } catch (_) {}
            }
        } catch (e) { console.error("[ourmenu/wl] tpAll2Me: " + e); }
        console.log(`[ourmenu/wl] TP'd ${count} WL players to me`);
        return count;
    }

    // ===== WL loop toggles (per-frame runners — see runPerFrameMods) =====
    let wlAllSpeedLoopEnabled = false;
    let wlAllAntiGravLoopEnabled = false;
    let wlInvincibleLoopEnabled = false;
    let wlReviveLoopEnabled = false;
    let wlRainbowLoopEnabled = false;
    // Throttle state — these loops only fire every N seconds, not every frame.
    let wlSpeedLoopNext = 0;
    let wlAntiGravLoopNext = 0;
    let wlInvincibleLoopNext = 0;
    let wlReviveLoopNext = 0;

    // Mods that are one-shot actions, NOT toggles — they apply on click and
    // never light up afterward (no "on/off" state to indicate).
    const ONE_SHOT_LABELS = new Set<string>([
        "Unlock All",       // click once → permanently unlocked, no off state
        "Change Multi Buy",
        "Change Eject Dupe Amount",
        "Insta Kill All",   // fires once on click, no off state
        "Server Kick All",  // fires once on click, no off state
        "Spawn Mob Hand",   // fires once on click, no off state
    ]);

    // Returns whether the named toggle is currently ON (used to light up the
    // button when rebuilt). One-shot actions return false so they never light up.
    function isModToggleOn(label: string): boolean {
        if (ONE_SHOT_LABELS.has(label)) return false;
        switch (label) {
            case "Infinite Ammo": return InfAmmo;
            case "No Recoil": return noRecoil;
            case "No Shotgun Cooldown": return noShotgunCooldown;
            case "Rapid Fire": return rapidFireEnabled;
            case "Inf Damage": return infDamage;
            case "Stash Dupe": return stashDupeEnabled;
            case "Multi Buy": return multiBuyEnabled;
            case "Spaz Explode Machine": return spazExplodeMachineEnabled;
            case "Item Rain": return itemRainEnabled;
            case "Item Tornado": return itemTornadoEnabled;
            case "Mob Orbit": return mobOrbitEnabled;
            case "Prefab Orbit": return prefabOrbitEnabled;
            case "Sellingmachine Orbit self": return sellingmachineOrbitEnabled;
            case "Sellingmachine Tower Orbit": return sellingmachineTowerEnabled;
            case "Moon Buggy Orbit self": return moonBuggyOrbitEnabled;
            case "ChristmasBox Orbit self": return christmasBoxOrbitEnabled;
            case "Christmas Present Tower": return christmasPresentTowerEnabled;
            case "Tree Forest Orbit": return treeForestEnabled;
            case "RPG Hands All": return rpgHandsAllEnabled;
            case "Buggy Hands": return buggyHandsEnabled;
            case "Item Launcher": return itemLauncherEnabled;
            case "Right Hand Duper": return rightHandDuperEnabled;
            case "Give Fly All": return giveFlyAllEnabled;
            case "Item Launcher All": return itemLauncherAllEnabled;
            case "All Player Gun Buffs": return allPlayerGunBuffsEnabled;
            case "Goop Spammer": return goopSpammerEnabled;
            case "Piss Mod": return pissModEnabled;
            case "Lag All Items": return lagAllItemsEnabled;
            case "Cage All Players": return cageAllPlayersEnabled;
            case "Grab Selling Machine": return grabSellingMachineEnabled;
            case "Spawn NetPlayer Trigger": return spawnNetPlayerTriggerEnabled;
            case "Kick Gun": return kickGunEnabled;
            case "Nut Pickup Gun": return nutPickupGunEnabled;
            case "Ammo Pickup Gun": return ammoPickupGunEnabled;
            case "Grant All Stash Slots": return grantAllStashSlotsEnabled;
            case "No Container Restrictions": return noContainerRestrictionsEnabled;
            case "Rocket Launcher": return rocketLauncherEnabled;
            case "flaregun": return flaregunEnabled;
            case "boomspear": return boomspearEnabled;
            case "Robot Dog RPG": return robotDogRPGEnabled;
            case "egg": return eggLauncherEnabled;
            case "Fly": return flyEnabled;
            case "Joystick Fly": return joystickFlyEnabled;
            // WL Tools sub-page loop toggles.
            case "Whitelist Enabled": return whitelistEnabled;
            case "WL Speed Loop": return wlAllSpeedLoopEnabled;
            case "WL AntiGrav Loop": return wlAllAntiGravLoopEnabled;
            case "WL Invincible Loop": return wlInvincibleLoopEnabled;
            case "WL Revive Loop": return wlReviveLoopEnabled;
            case "WL Rainbow Loop": return wlRainbowLoopEnabled;
        }
        return false;
    }

    // Mass-off (Reset button): flip every TOGGLE flag to false. One-shot actions
    // (Unlock All etc.) are intentionally NOT reset — they're permanent.
    function resetAllMods(): void {
        InfAmmo = false;
        noRecoil = false;
        noShotgunCooldown = false;
        rapidFireEnabled = false;
        infDamage = false;
        stashDupeEnabled = false;
        multiBuyEnabled = false;
        spazExplodeMachineEnabled = false;
        itemRainEnabled = false;
        itemTornadoEnabled = false; itemTornadoEntries = [];
        mobOrbitEnabled = false; mobOrbitEntries = [];
        prefabOrbitEnabled = false; prefabOrbitEntries = [];
        sellingmachineOrbitEnabled = false; sellingmachineOrbitEntries = [];
        sellingmachineTowerEnabled = false; sellingmachineTowerEntries = [];
        moonBuggyOrbitEnabled = false; moonBuggyOrbitEntries = [];
        christmasBoxOrbitEnabled = false; christmasBoxOrbitEntries = [];
        christmasPresentTowerEnabled = false; christmasPresentTowerEntries = [];
        treeForestEnabled = false; treeForestEntries = [];
        rpgHandsAllEnabled = false;
        buggyHandsEnabled = false;
        itemLauncherEnabled = false;
        rightHandDuperEnabled = false;
        giveFlyAllEnabled = false;
        itemLauncherAllEnabled = false;
        allPlayerGunBuffsEnabled = false;
        goopSpammerEnabled = false;
        pissModEnabled = false;
        for (const entry of spawnedGoopObjects) {
            try { if (entry?.object && !entry.object.isNull?.()) Object_.method("Destroy", 1).invoke(entry.object); } catch (_) {}
        }
        spawnedGoopObjects = [];
        lagAllItemsEnabled = false;
        cageAllPlayersEnabled = false;
        for (const c of cageAllPlayersEntries) { try { destroyNetworkedObjectDeep(c.obj); } catch (_) {} }
        cageAllPlayersEntries = [];
        grabSellingMachineEnabled = false;
        if (heldSellingMachineObj) { try { destroyNetworkedObjectDeep(heldSellingMachineObj); } catch (_) {} heldSellingMachineObj = null; }
        spawnNetPlayerTriggerEnabled = false;
        nutPickupGunEnabled = false;
        ammoPickupGunEnabled = false;
        grantAllStashSlotsEnabled = false;
        noContainerRestrictionsEnabled = false;
        rocketLauncherEnabled = false;
        flaregunEnabled = false;
        boomspearEnabled = false;
        robotDogRPGEnabled = false;
        eggLauncherEnabled = false;
        flyEnabled = false;
        joystickFlyEnabled = false;
        fistFlyVelocity = [0, 0, 0];
        joystickFlyVelocity = [0, 0, 0];
        // Player-tab toggles.
        orbitPlayersAllEnabled = false;
        orbitPlayersWLEnabled = false;
        orbitPlayersAllFast = false;
        playerOrbitKeys.clear();
        // WL loop toggles — clear the per-frame runners. Roster itself persists.
        wlAllSpeedLoopEnabled = false;
        wlAllAntiGravLoopEnabled = false;
        wlInvincibleLoopEnabled = false;
        wlReviveLoopEnabled = false;
        wlRainbowLoopEnabled = false;
        // Whitelist roster + selection survive Reset on purpose — they reflect
        // user intent ("I curated this list"), not transient mod state.
        // unlockAllEnabled intentionally NOT reset — one-shot/permanent.
        console.log("[ourmenu/mod] RESET — all toggle flags cleared (one-shots like Unlock All persist)");
    }

    // Toggle wiring per label. Returns true if the label was a known toggle and
    // the action ran; false otherwise (caller falls back to "log-only" path).
    function tryRunModToggle(label: string): boolean {
        const log = (s: string) => console.log(`[ourmenu/mod] ${s}`);
        switch (label) {
            case "Infinite Ammo":
                InfAmmo = !InfAmmo; log(`Infinite Ammo ${InfAmmo ? "ON" : "OFF"}`); return true;
            case "No Recoil":
                noRecoil = !noRecoil; log(`No Recoil ${noRecoil ? "ON" : "OFF"}`); return true;
            case "No Shotgun Cooldown":
                noShotgunCooldown = !noShotgunCooldown; log(`No Shotgun Cooldown ${noShotgunCooldown ? "ON" : "OFF"}`); return true;
            case "Rapid Fire":
                rapidFireEnabled = !rapidFireEnabled; log(`Rapid Fire ${rapidFireEnabled ? "ON" : "OFF"}`); return true;
            case "Inf Damage":
                infDamage = !infDamage; log(`Inf Damage ${infDamage ? "ON" : "OFF"}`); return true;
            case "Stash Dupe":
                stashDupeEnabled = !stashDupeEnabled;
                log(`Stash Dupe ${stashDupeEnabled ? `ON x${ejectDupeAmount}` : "OFF"}`); return true;
            case "Change Eject Dupe Amount":
                ejectDupeAmount = ejectDupeAmount + 1;
                if (ejectDupeAmount > 10) ejectDupeAmount = 2;
                log(`Eject Dupe Amount = ${ejectDupeAmount}`); return true;
            case "Change Item":
                // Cycle through itemIDs. Item Rain / Tornado / Launcher all read
                // itemIDs[itemIndex % itemIDs.length], so this picks what they
                // spawn. One-shot — not a toggle, just bumps the index.
                itemIndex = (itemIndex + 1) % itemIDs.length;
                log(`Item = ${itemIDs[itemIndex]} (${itemIndex + 1}/${itemIDs.length})`);
                return true;
            case "Multi Buy":
                multiBuyEnabled = !multiBuyEnabled;
                log(`Multi Buy ${multiBuyEnabled ? `ON x${multiBuyAmount}` : "OFF"} (NOTE: needs purchase-machine hook ported from M4)`); return true;
            case "Change Multi Buy":
                multiBuyAmount += 5;
                if (multiBuyAmount > 50) multiBuyAmount = 5;
                log(`Multi Buy amount = ${multiBuyAmount}`); return true;
            case "Unlock All":
                // One-shot: set to true and never flip back. No off state.
                // Beyond the GIS method hooks (which the toggle gates), this also
                // does a one-shot inventory pass: walks every gameplay item and
                // flips its `isUnlocked` SubscriberPattern to true (M4 da.ts:8090-8120).
                // Without this, dev items show in UI but you don't OWN them.
                unlockAllEnabled = true;
                try {
                    const ac = getAcImage();
                    if (ac) {
                        const AppClass = ac.class("AnimalCompany.App");
                        const appState = AppClass.method("get_state").invoke();
                        if (appState && !appState.isNull?.()) {
                            // Inventory dev override (avatar items).
                            try {
                                const userState = appState.method("get_user").invoke();
                                if (userState && !userState.isNull?.()) {
                                    const inv = userState.method("get_inventory").invoke();
                                    if (inv && !inv.isNull?.()) {
                                        try {
                                            const devOv = inv.method("get_devOwnAllAvatarItemsOverride").invoke();
                                            if (devOv && !devOv.isNull?.()) {
                                                devOv.method("set_value").invoke(true);
                                                log("  inventory.devOwnAllAvatarItemsOverride = true OK");
                                            }
                                        } catch (_) {}
                                    }
                                }
                            } catch (e) { log(`  inventory dev override threw: ${e}`); }
                            // Per-item unlock pass — iterate every gameplay item and
                            // flip isUnlocked / unlockDependenciesSatisfied / unlockable.
                            let unlockedCount = 0;
                            try {
                                const gameplayItems = appState.method("get_gameplayItems").invoke();
                                if (gameplayItems && !gameplayItems.isNull?.()) {
                                    const allDict = gameplayItems.method("get_all").invoke();
                                    const values = allDict.method("get_Values").invoke();
                                    const en = values.method("GetEnumerator").invoke();
                                    while (en.method("MoveNext").invoke()) {
                                        try {
                                            const item = en.method("get_Current").invoke();
                                            if (!item || item.isNull?.()) continue;
                                            try {
                                                const sp = item.method("get_isUnlocked").invoke();
                                                if (sp && !sp.isNull?.()) sp.method("set_value").invoke(true);
                                            } catch (_) {}
                                            try {
                                                const sp = item.method("get_unlockDependenciesSatisfied").invoke();
                                                if (sp && !sp.isNull?.()) sp.method("set_value").invoke(true);
                                            } catch (_) {}
                                            try {
                                                const sp = item.method("get_unlockable").invoke();
                                                if (sp && !sp.isNull?.()) sp.method("set_value").invoke(true);
                                            } catch (_) {}
                                            unlockedCount++;
                                        } catch (_) {}
                                    }
                                }
                            } catch (e) { log(`  inventory iteration threw: ${e}`); }
                            log(`  flipped isUnlocked SP on ${unlockedCount} items`);
                        }
                    }
                } catch (e) { log(`  Unlock All inventory pass threw: ${e}`); }
                log(`Unlock All APPLIED (isHidden→false + isPurchasable/isResearchable/allowBlueprintSaving/canBeSavedToLoadoutTemplate → true + per-item isUnlocked pass)`);
                return true;
            case "Spaz Explode Machine":
                spazExplodeMachineEnabled = !spazExplodeMachineEnabled;
                (globalThis as any).__spaz_logged = false;   // reset so we re-log on next ON
                log(`Spaz Explode Machine ${spazExplodeMachineEnabled ? "ON" : "OFF"}`); return true;
            case "Item Rain":
                itemRainEnabled = !itemRainEnabled;
                log(`Item Rain ${itemRainEnabled ? "ON ('" + itemIDs[itemIndex % itemIDs.length] + "')" : "OFF"}`); return true;
            case "Item Tornado":
                itemTornadoEnabled = !itemTornadoEnabled;
                if (!itemTornadoEnabled) itemTornadoEntries = [];
                log(`Item Tornado ${itemTornadoEnabled ? "ON" : "OFF"}`); return true;
            case "Mob Orbit":
                mobOrbitEnabled = !mobOrbitEnabled;
                if (!mobOrbitEnabled) { for (const e of mobOrbitEntries) { try { destroyNetworkedObjectDeep(e.obj); } catch (_) {} } mobOrbitEntries = []; }
                log(`Mob Orbit ${mobOrbitEnabled ? "ON ('" + mobIDs[mobIndex % mobIDs.length].name + "')" : "OFF"}`); return true;
            case "Prefab Orbit":
                prefabOrbitEnabled = !prefabOrbitEnabled;
                if (!prefabOrbitEnabled) { for (const e of prefabOrbitEntries) { try { destroyNetworkedObjectDeep(e.obj); } catch (_) {} } prefabOrbitEntries = []; }
                log(`Prefab Orbit ${prefabOrbitEnabled ? "ON ('" + prefabIDs[prefabIndex % prefabIDs.length] + "')" : "OFF"}`); return true;
            case "Sellingmachine Orbit self":
                sellingmachineOrbitEnabled = !sellingmachineOrbitEnabled;
                if (!sellingmachineOrbitEnabled) { for (const e of sellingmachineOrbitEntries) { try { destroyNetworkedObjectDeep(e.obj); } catch (_) {} } sellingmachineOrbitEntries = []; }
                log(`Sellingmachine Orbit ${sellingmachineOrbitEnabled ? "ON" : "OFF"}`); return true;
            case "Sellingmachine Tower Orbit":
                sellingmachineTowerEnabled = !sellingmachineTowerEnabled;
                if (!sellingmachineTowerEnabled) { for (const e of sellingmachineTowerEntries) { try { destroyNetworkedObjectDeep(e.obj); } catch (_) {} } sellingmachineTowerEntries = []; }
                log(`Sellingmachine Tower ${sellingmachineTowerEnabled ? "ON" : "OFF"}`); return true;
            case "Moon Buggy Orbit self":
                moonBuggyOrbitEnabled = !moonBuggyOrbitEnabled;
                if (!moonBuggyOrbitEnabled) { for (const e of moonBuggyOrbitEntries) { try { destroyNetworkedObjectDeep(e.obj); } catch (_) {} } moonBuggyOrbitEntries = []; }
                log(`Moon Buggy Orbit ${moonBuggyOrbitEnabled ? "ON" : "OFF"}`); return true;
            case "ChristmasBox Orbit self":
                christmasBoxOrbitEnabled = !christmasBoxOrbitEnabled;
                if (!christmasBoxOrbitEnabled) { for (const e of christmasBoxOrbitEntries) { try { destroyNetworkedObjectDeep(e.obj); } catch (_) {} } christmasBoxOrbitEntries = []; }
                log(`ChristmasBox Orbit ${christmasBoxOrbitEnabled ? "ON" : "OFF"}`); return true;
            case "Christmas Present Tower":
                christmasPresentTowerEnabled = !christmasPresentTowerEnabled;
                if (!christmasPresentTowerEnabled) { for (const e of christmasPresentTowerEntries) { try { destroyNetworkedObjectDeep(e.obj); } catch (_) {} } christmasPresentTowerEntries = []; }
                log(`Christmas Present Tower ${christmasPresentTowerEnabled ? "ON" : "OFF"}`); return true;
            case "Tree Forest Orbit":
                treeForestEnabled = !treeForestEnabled;
                if (!treeForestEnabled) { for (const e of treeForestEntries) { try { destroyNetworkedObjectDeep(e.obj); } catch (_) {} } treeForestEntries = []; }
                log(`Tree Forest Orbit ${treeForestEnabled ? "ON" : "OFF"}`); return true;
            case "Give Masterclient":
                try {
                    if (tryBecomeMasterClient()) log("Masterclient → YOU (sent on all runner candidates)");
                    else log("Masterclient FAILED: no runner candidate accepted the call");
                } catch (e) { log("Masterclient FAILED: " + e); }
                return true;
            // === Per-frame toggles (state flag, runner in runPerFrameMods) ===
            case "RPG Hands All":
                rpgHandsAllEnabled = !rpgHandsAllEnabled;
                log(`RPG Hands All ${rpgHandsAllEnabled ? "ON" : "OFF"}`); return true;
            case "Buggy Hands":
                buggyHandsEnabled = !buggyHandsEnabled;
                log(`Buggy Hands ${buggyHandsEnabled ? "ON" : "OFF"}`); return true;
            case "Item Launcher":
                itemLauncherEnabled = !itemLauncherEnabled;
                log(`Item Launcher ${itemLauncherEnabled ? "ON" : "OFF"}`); return true;
            case "Right Hand Duper":
                rightHandDuperEnabled = !rightHandDuperEnabled;
                log(`Right Hand Duper ${rightHandDuperEnabled ? "ON" : "OFF"}`); return true;
            case "Give Fly All":
                giveFlyAllEnabled = !giveFlyAllEnabled;
                log(`Give Fly All ${giveFlyAllEnabled ? "ON" : "OFF"}`); return true;
            case "Item Launcher All":
                itemLauncherAllEnabled = !itemLauncherAllEnabled;
                log(`Item Launcher All ${itemLauncherAllEnabled ? "ON" : "OFF"}`); return true;
            case "All Player Gun Buffs":
                allPlayerGunBuffsEnabled = !allPlayerGunBuffsEnabled;
                if (allPlayerGunBuffsEnabled) { InfAmmo = true; noRecoil = true; rapidFireEnabled = true; }
                log(`All Player Gun Buffs ${allPlayerGunBuffsEnabled ? "ON" : "OFF"}`); return true;
            case "Goop Spammer":
                goopSpammerEnabled = !goopSpammerEnabled;
                log(`Goop Spammer ${goopSpammerEnabled ? "ON" : "OFF"}`); return true;
            case "Piss Mod":
                pissModEnabled = !pissModEnabled;
                log(`Piss Mod ${pissModEnabled ? "ON" : "OFF"}`); return true;
            case "Lag All Items":
                lagAllItemsEnabled = !lagAllItemsEnabled;
                log(`Lag All Items ${lagAllItemsEnabled ? "ON" : "OFF"}`); return true;
            case "Cage All Players":
                cageAllPlayersEnabled = !cageAllPlayersEnabled;
                if (!cageAllPlayersEnabled) {
                    for (const c of cageAllPlayersEntries) {
                        try { destroyNetworkedObjectDeep(c.obj); } catch (_) {}
                    }
                    cageAllPlayersEntries = [];
                }
                log(`Cage All Players ${cageAllPlayersEnabled ? "ON" : "OFF"}`); return true;
            case "Grab Selling Machine":
                grabSellingMachineEnabled = !grabSellingMachineEnabled;
                if (!grabSellingMachineEnabled && heldSellingMachineObj) {
                    try { destroyNetworkedObjectDeep(heldSellingMachineObj); } catch (_) {}
                    heldSellingMachineObj = null;
                }
                log(`Grab Selling Machine ${grabSellingMachineEnabled ? "ON" : "OFF"}`); return true;
            case "Spawn NetPlayer Trigger":
                spawnNetPlayerTriggerEnabled = !spawnNetPlayerTriggerEnabled;
                log(`Spawn NetPlayer Trigger ${spawnNetPlayerTriggerEnabled ? "ON" : "OFF"}`); return true;
            case "Kick Gun":
                kickGunEnabled = !kickGunEnabled;
                kickGunTriggerWasHeld = m4_rightTrigger;   // don't fire on the trigger that's already down
                if (!kickGunEnabled) hideKickGunLaser();
                log(`Kick Gun ${kickGunEnabled ? "ON (hold right grip for laser, click trigger to kick)" : "OFF"}`); return true;
            case "Nut Pickup Gun":
                nutPickupGunEnabled = !nutPickupGunEnabled;
                log(`Nut Pickup Gun ${nutPickupGunEnabled ? "ON" : "OFF"}`); return true;
            case "Ammo Pickup Gun":
                ammoPickupGunEnabled = !ammoPickupGunEnabled;
                log(`Ammo Pickup Gun ${ammoPickupGunEnabled ? "ON" : "OFF"}`); return true;
            case "Grant All Stash Slots":
                grantAllStashSlotsEnabled = !grantAllStashSlotsEnabled;
                log(`Grant All Stash Slots ${grantAllStashSlotsEnabled ? "ON" : "OFF"} (flag set; hook port pending)`); return true;
            case "No Container Restrictions":
                noContainerRestrictionsEnabled = !noContainerRestrictionsEnabled;
                log(`No Container Restrictions ${noContainerRestrictionsEnabled ? "ON" : "OFF"} (flag set; hook port pending)`); return true;
            // === One-shot actions ===
            case "Delete All Lobby Items":
                try {
                    let count = 0;
                    for (const item of collectAllLobbyItemsWithHeld()) {
                        if (destroyNetworkedObjectDeep(item)) count++;
                    }
                    log(`Delete All Lobby Items: deleted ${count}`);
                } catch (e) { log("Delete All Lobby Items FAILED: " + e); }
                return true;
            // === Launcher toggles (fire while right grip + trigger held) ===
            case "Rocket Launcher":
                rocketLauncherEnabled = !rocketLauncherEnabled;
                log(`Rocket Launcher ${rocketLauncherEnabled ? "ON (hold right grip+trigger)" : "OFF"}`); return true;
            case "flaregun":
                flaregunEnabled = !flaregunEnabled;
                log(`flaregun ${flaregunEnabled ? "ON (hold right grip+trigger)" : "OFF"}`); return true;
            case "boomspear":
                boomspearEnabled = !boomspearEnabled;
                log(`boomspear ${boomspearEnabled ? "ON (hold right grip+trigger)" : "OFF"}`); return true;
            case "Robot Dog RPG":
                robotDogRPGEnabled = !robotDogRPGEnabled;
                log(`Robot Dog RPG ${robotDogRPGEnabled ? "ON (hold right grip+trigger)" : "OFF"}`); return true;
            case "egg":
                eggLauncherEnabled = !eggLauncherEnabled;
                log(`egg ${eggLauncherEnabled ? "ON (hold right grip+trigger)" : "OFF"}`); return true;
            // === Movement / local-player fly ===
            case "Fly":
                flyEnabled = !flyEnabled;
                if (!flyEnabled) fistFlyVelocity = [0, 0, 0];
                log(`Fly ${flyEnabled ? "ON (make a fist with grip+trigger to fly where you point)" : "OFF"}`);
                return true;
            case "Joystick Fly":
                joystickFlyEnabled = !joystickFlyEnabled;
                if (!joystickFlyEnabled) joystickFlyVelocity = [0, 0, 0];
                log(`Joystick Fly ${joystickFlyEnabled ? "ON (right stick = horizontal, left stick Y = up/down)" : "OFF"}`);
                return true;
            case "Dump Net Objects":
                try {
                    if (resolveModRefs()) {
                        const inst = PrefabGenCls.field("_instance").value;
                        const runner = inst.method("get_runner").invoke();
                        const sources = runner.field("_config").value.field("PrefabTable").value.field("_sources").value;
                        const cnt = sources.method("get_Count").invoke() as number;
                        log(`Dumping ${cnt} NetworkObject prefabs to console:`);
                        for (let i = 0; i < cnt; i++) {
                            try {
                                const src = sources.method("get_Item").invoke(i);
                                const desc = src.method("get_Description").invoke().toString();
                                console.log(`  [${i}] ${desc}`);
                            } catch (_) {}
                        }
                    }
                } catch (e) { log("Dump Net Objects FAILED: " + e); }
                return true;
            case "Dump Menu TXT":
                log("Dump Menu TXT: not applicable in ourmenu (M4-specific to their menu structure)");
                return true;
            case "Multi Buy":
                // Already wired earlier; this overrides for completeness.
                multiBuyEnabled = !multiBuyEnabled;
                log(`Multi Buy ${multiBuyEnabled ? "ON x" + multiBuyAmount : "OFF"} (purchase-machine hook pending)`);
                return true;
            // === FCS skid menu ports (2026-06-07 da.ts) ===
            case "Insta Kill All":
                try {
                    let killed = 0, failed = 0;
                    let dmgNull: any = null;
                    try {
                        if (DamageSourceInfoClass_M4) {
                            dmgNull = DamageSourceInfoClass_M4.method("get_Null").invoke();
                        }
                    } catch (_) {}
                    for (const target of getAllNetPlayersList(false)) {
                        try {
                            if (!target || target.handle.isNull?.()) { failed++; continue; }
                            if (playerIsLocal(target)) continue;
                            const tp = target.method("get_transform").invoke()
                                .method("get_position").invoke();
                            target.method("RPC_PlayerHit", 3).invoke(9999, tp, dmgNull);
                            killed++;
                        } catch (_) { failed++; }
                    }
                    log(`Insta Kill All: hit ${killed}${failed ? " failed=" + failed : ""}`);
                } catch (e) { log("Insta Kill All FAILED: " + e); }
                return true;
            case "Server Kick All":
                try {
                    let sent = 0, failed = 0;
                    for (const target of getAllNetPlayersList(false)) {
                        try {
                            if (!target || target.handle.isNull?.()) { failed++; continue; }
                            if (playerIsLocal(target)) continue;
                            if (tryKickPlayerSimple(target)) sent++;
                            else failed++;
                        } catch (_) { failed++; }
                    }
                    log(`Server Kick All: sent ${sent}${failed ? " failed=" + failed : ""}`);
                } catch (e) { log("Server Kick All FAILED: " + e); }
                return true;
            case "Spawn Mob Hand":
                try {
                    refreshLocalPlayerRefs();
                    if (!rightHandTf) { log("Spawn Mob Hand FAILED: right hand transform unavailable"); return true; }
                    const mob = mobIDs[mobIndex % mobIDs.length];
                    const hp = rightHandTf.method("get_position").invoke();
                    const fwd = readVec3Components(rightHandTf.method("get_forward").invoke());
                    const spawnPos: [number, number, number] = [
                        (hp.field("x").value as number) + fwd[0] * 1.5,
                        (hp.field("y").value as number) + fwd[1] * 1.5,
                        (hp.field("z").value as number) + fwd[2] * 1.5,
                    ];
                    const result = spawnMobAtPosSimple(mob, spawnPos);
                    if (result) {
                        log(`Spawn Mob Hand: spawned ${mob.name} (id=${mob.id}) 1.5m forward of right hand`);
                    } else {
                        log(`Spawn Mob Hand: FAILED to spawn ${mob.name} (id=${mob.id}) — likely needs validator-bypass infrastructure not ported here`);
                    }
                } catch (e) { log("Spawn Mob Hand FAILED: " + e); }
                return true;
        }
        return false;
    }

    // Direction the right hand points, in WORLD space. The pointer-ball
    // calibration in this AC build found the hand's local -Y = toward the
    // fingertip (and +Z = "up"), so the aim ray is the hand's local -Y axis =
    // negated get_up(). BOTH the kick-gun laser (a child cube that extends
    // along local -Y) and aimTargetPlayer use this, so the beam you see and the
    // player you kick can never disagree. If your build shoots the laser out the
    // back/side of your hand, flip the sign or switch to get_forward/get_right.
    function handAimDir(): [number, number, number] | null {
        if (!rightHandTf) return null;
        try {
            const up = readVec3Components(rightHandTf.method("get_up").invoke());
            const dx = -up[0], dy = -up[1], dz = -up[2];
            const l = Math.hypot(dx, dy, dz) || 1;
            return [dx / l, dy / l, dz / l];
        } catch (_) { return null; }
    }

    // World position of your head/eyes (for head→hand aiming). Prefers the
    // local player's head transform; falls back to the main camera.
    function getHeadPos(): [number, number, number] | null {
        if (headColliderTf && !headColliderTf.isNull?.()) {
            try { return readVec3Components(headColliderTf.method("get_position").invoke()); } catch (_) {}
        }
        try {
            const cam = Camera.method("get_main").invoke();
            if (cam && !cam.isNull?.()) {
                const camTr = getTransform(cam.method("get_gameObject").invoke());
                return readVec3Components(camTr.method("get_position").invoke());
            }
        } catch (_) {}
        return null;
    }

    // The Kick Gun aim ray: origin at the right hand, direction = head→hand
    // extended outward (you point by looking down your arm — natural in VR and
    // independent of the hand bone's confusing local axes). Falls back to the
    // hand's own aim axis if the head isn't resolvable or the hand is right at
    // your face. Returns {o: origin, d: unit direction} or null.
    function kickGunAimRay(): { o: [number, number, number]; d: [number, number, number] } | null {
        if (!rightHandTf) return null;
        let o: [number, number, number];
        try { o = readVec3Components(rightHandTf.method("get_position").invoke()); }
        catch (_) { return null; }
        const head = getHeadPos();
        if (head) {
            let dx = o[0] - head[0], dy = o[1] - head[1], dz = o[2] - head[2];
            const l = Math.hypot(dx, dy, dz);
            if (l >= 0.05) return { o, d: [dx / l, dy / l, dz / l] };
        }
        const hd = handAimDir();
        if (!hd) return null;
        return { o, d: hd };
    }

    // ===== Aim target select: player closest to where rightHandTf points =====
    // Returns the non-local NetPlayer whose direction from the hand is within
    // coneDeg of the hand's aim ray AND nearest to that ray (smallest angle
    // wins). null if nothing is in the cone. Used by Kick Gun; reusable for
    // any "point at a player" mod.
    function aimTargetPlayer(coneDeg: number): any {
        const ray = kickGunAimRay();
        if (!ray) return null;
        const ox = ray.o[0], oy = ray.o[1], oz = ray.o[2];
        let fx = ray.d[0], fy = ray.d[1], fz = ray.d[2];
        const minDot = Math.cos((coneDeg * Math.PI) / 180);
        let best: any = null;
        let bestDot = minDot;   // must beat the cone threshold to be picked
        for (const p of getAllNetPlayersList(false)) {
            try {
                if (!p || p.handle.isNull?.() || playerIsLocal(p)) continue;
                const tp = readVec3Components(
                    p.method("get_transform").invoke().method("get_position").invoke()
                );
                // Aim at chest, not feet — player transform origin sits low.
                let dx = tp[0] - ox, dy = (tp[1] + 0.9) - oy, dz = tp[2] - oz;
                const dlen = Math.hypot(dx, dy, dz);
                if (dlen < 1e-3) continue;
                dx /= dlen; dy /= dlen; dz /= dlen;
                const dot = fx * dx + fy * dy + fz * dz;
                if (dot > bestDot) { bestDot = dot; best = p; }
            } catch (_) {}
        }
        return best;
    }

    // All NetworkRunner instances we can reach, most-reliable first. Ported from
    // M4 da.ts:4160 getRunnerCandidates. CRITICAL: M4's canonical runner is
    // SFXManager._instance._currentRunner — our old port used ONLY
    // PrefabGenerator._instance.get_runner(), which in many lobbies returns null
    // or a non-authoritative runner, so every kick + master-client grab failed.
    function getRunnerCandidates(): any[] {
        const results: any[] = [];
        const seen = new Set<string>();
        const push = (r: any) => {
            try {
                if (!r || r.isNull?.()) return;
                const key = String(r.handle ?? r);
                if (seen.has(key)) return;
                seen.add(key);
                results.push(r);
            } catch (_) {}
        };
        if (!resolveModRefs()) return results;
        try {
            if (SFXManagerCls) {
                const sfx = SFXManagerCls.field("_instance").value;
                if (sfx && !sfx.isNull?.()) {
                    try { push(sfx.method("get__currentRunner").invoke()); } catch (_) {}
                    try { push(sfx.field("_currentRunner").value); } catch (_) {}
                }
            }
        } catch (_) {}
        try {
            const pg = PrefabGenCls.field("_instance").value;
            if (pg && !pg.isNull?.()) { try { push(pg.method("get_runner").invoke()); } catch (_) {} }
        } catch (_) {}
        try {
            if (NManagerClass_M4) {
                const nm = NManagerClass_M4.field("<Instance>k__BackingField").value;
                if (nm && !nm.isNull?.()) { try { push(nm.method("get_runner").invoke()); } catch (_) {} }
            }
        } catch (_) {}
        return results;
    }

    // Best-effort: promote yourself to master client / host so authority-gated
    // actions (like kicking) are accepted. Tries SetMasterClient on EVERY runner
    // candidate (M4 pattern). Returns true if at least one call went through (NOT
    // a guarantee the server honored it — some lobbies refuse).
    function tryBecomeMasterClient(): boolean {
        let any = false;
        for (const runner of getRunnerCandidates()) {
            try {
                const localRef = runner.method("get_LocalPlayer").invoke();
                if (!localRef) continue;
                runner.method("SetMasterClient").invoke(localRef);
                any = true;
            } catch (_) {}
        }
        return any;
    }

    // ===== Port of M4 da.ts:3879 tryKickPlayer (runner path) =====
    // Tries the disconnect/kick method family on EVERY runner candidate (M4
    // pattern), with both the PlayerRef value and the NetPlayer object, in 1- and
    // 2-arg forms. The old port only used PrefabGen's runner — which was null/
    // non-authoritative in many lobbies, so kicks silently failed. Master client
    // / authority is still required server-side; returns false if all attempts
    // are rejected.
    function tryKickPlayerSimple(player: any): boolean {
        if (!player || player.handle.isNull?.() || playerIsLocal(player)) return false;
        const candidates = getRunnerCandidates();
        if (candidates.length === 0) return false;
        let playerRef: any = null;
        try { playerRef = player.method("get_PlayerRef").invoke(); } catch (_) {}
        if (playerRef == null) {
            try { playerRef = player.field("_playerRef").value; } catch (_) {}
        }
        const names = ["DisconnectPlayer", "RemovePlayer", "KickPlayer", "Disconnect", "CloseConnection", "KickPeer"];
        const variants: any[][] = [];
        if (playerRef != null) {
            variants.push([1, playerRef]);
            variants.push([2, playerRef, true]);
        }
        variants.push([1, player]);
        variants.push([2, player, true]);
        for (const runner of candidates) {
            for (const name of names) {
                for (const v of variants) {
                    try {
                        const argc = v[0] as number;
                        const args = v.slice(1);
                        runner.method(name, argc).invoke(...args);
                        return true;
                    } catch (_) {}
                }
            }
        }
        return false;
    }

    // ===== Simplified port of M4 da.ts:1693 spawnMobAtPos =====
    // The full M4 version installs a NetworkObjectSpawnDelegate + validator
    // bypass + acResolveMobID enum walk + multiple SpawnMob overloads. We try
    // the SpawnMob enum path with both 5-arg and 4-arg overloads, then fall
    // back to the existing prefab path used by Mob Orbit. If both fail the
    // caller logs and the user sees a "needs validator-bypass" notice.
    function spawnMobAtPosSimple(mobEntry: { name: string; id: number }, pos: [number, number, number]): any {
        if (!resolveModRefs()) return null;
        const idQ = idQuat;
        // 1. Try the prefab path first — same path Mob Orbit already uses.
        try {
            const cleanName = mobEntry.name;
            const result = spawnNetworkPrefab(cleanName, pos, idQ);
            if (result && !result.isNull?.()) return result;
        } catch (_) {}
        try {
            const result2 = spawnNetworkPrefab("mob_prefab/" + mobEntry.name, pos, idQ);
            if (result2 && !result2.isNull?.()) return result2;
        } catch (_) {}
        // 2. Try the enum-based SpawnMob path (no validator bypass — will fail
        //    silently in many lobbies). Mob enum lookup keyed by mob name.
        try {
            const ac = Il2Cpp.domain.assembly("AnimalCompany").image;
            const MobIDEnum = ac.class("AnimalCompany.MobID");
            const PrefabGen = PrefabGenCls;
            const enumVal = MobIDEnum.field(mobEntry.name).value;
            try {
                return PrefabGen.method("SpawnMob", 5).invoke(enumVal, pos, idQ, NULL_REF, Il2Cpp.string("ourmenu"));
            } catch (_) {}
            try {
                return PrefabGen.method("SpawnMob", 4).invoke(enumVal, pos, idQ, NULL_REF);
            } catch (_) {}
        } catch (_) {}
        return null;
    }

    // Quest-server Photon target version. M4 publishes a new string per build.
    // Setting AppUtils.CalculatePhotonAppVersion to return this string redirects
    // the client onto Quest matchmaking. Note: irreversible per session.
    //
    //  Build         | Photon AppVersion       | Source / status
    //  --------------|-------------------------|---------------------------
    //  current m4.ts | lSpvw1BHUYzcYUWxn8fl    | M4's m4.ts Jun 7 2026     ← ACTIVE
    //  prev m4.ts    | 5M8b0P9cmf0LCq5oFxWy    | M4's m4.ts — VERIFIED working 2026-06-02
    //  1.76.x        | ZwYKrx9DVGFaSqMWP0Vg    | M4 announce 2026-06-02
    //  1.77+         | WLAAg5IQf2ffgegfxkpA    | M4 announce 2026-06-03
    //
    // If Quest connect fails, swap to one of the others (uncomment a line).
    const QUEST_PHOTON_VERSION = "lSpvw1BHUYzcYUWxn8fl";   // ← ACTIVE (latest M4 m4.ts Jun 7)
    // const QUEST_PHOTON_VERSION = "WLAAg5IQf2ffgegfxkpA";   // 1.77+
    // const QUEST_PHOTON_VERSION = "5M8b0P9cmf0LCq5oFxWy";  // confirmed working earlier
    // const QUEST_PHOTON_VERSION = "ZwYKrx9DVGFaSqMWP0Vg";

    // Diagnostic: print Oculus MobileAppID + the current AppVersion (so we know
    // the override actually took effect on next call).
    function logCurrentAppId(): void {
        try {
            const oculusAsm = Il2Cpp.domain.assembly("Oculus.Platform");
            if (oculusAsm) {
                const SettingsClass = oculusAsm.image.class("Oculus.Platform.PlatformSettings");
                const mobileAppID = SettingsClass.method("get_MobileAppID").invoke();
                console.log(`[ourmenu/quest] Oculus MobileAppID = "${mobileAppID}"`);
            }
        } catch (_) {}
    }

    // Full discovery probe — walks Fusion/Photon assemblies, finds every class
    // whose name contains "Settings"/"Config"/"AppVersion"/"GameVersion", and for
    // each, lists Version-like properties + their CURRENT VALUE if readable as
    // a static/singleton. This tells us the exact class+property to hook AND the
    // current photon version string of THIS build (so we can compare to Quest).
    function probePhotonVersion(): void {
        const assemblies = ["Fusion.Runtime", "Fusion.Realtime", "PhotonRealtime", "Photon3Unity3D", "Photon.Realtime"];
        console.log("[ourmenu/probe] === Photon/Fusion version discovery ===");
        let anyFound = false;
        for (const asmName of assemblies) {
            let asm: any = null;
            try { asm = Il2Cpp.domain.assembly(asmName); } catch (_) {}
            if (!asm) continue;
            anyFound = true;
            console.log(`[ourmenu/probe] -- assembly: ${asmName} --`);
            try {
                const classes = asm.image.classes;
                let hits = 0;
                for (const klass of classes) {
                    let nm = "";
                    try { nm = klass.type.name; } catch (_) {}
                    if (!/(Settings|Config|AppVersion|GameVersion|NetworkProject|FusionApp)/i.test(nm)) continue;
                    // List version-like properties for this class.
                    const versionProps: string[] = [];
                    try {
                        for (const m of klass.methods) {
                            let mn = "";
                            try { mn = m.name; } catch (_) {}
                            if (/^get_.*(Version|version)$/.test(mn)) versionProps.push(mn);
                        }
                    } catch (_) {}
                    try {
                        for (const f of klass.fields) {
                            let fn = "";
                            try { fn = f.name; } catch (_) {}
                            if (/(Version|version)/.test(fn)) versionProps.push("field:" + fn);
                        }
                    } catch (_) {}
                    if (versionProps.length === 0) continue;
                    console.log(`[ourmenu/probe]   ${nm} :: ${versionProps.join(", ")}`);
                    hits++;
                    if (hits >= 30) { console.log("[ourmenu/probe]   (truncated)"); break; }
                }
                if (hits === 0) console.log("[ourmenu/probe]   (no version-bearing classes found)");
            } catch (e) { console.log("[ourmenu/probe]   enumeration FAILED: " + e); }
        }
        if (!anyFound) console.log("[ourmenu/probe] none of the Photon/Fusion assemblies are loaded");

        // Bonus — try every candidate path and READ (not write) the current
        // AppVersion. Lets us see what 1.76.0 currently uses.
        const readCandidates: Array<[string, string, string[]]> = [
            ["Fusion.Realtime",     "Fusion.Photon.Realtime.FusionAppSettings", ["AppVersion", "appVersion"]],
            ["Fusion.Realtime",     "Photon.Realtime.AppSettings",              ["AppVersion", "appVersion"]],
            ["Fusion.Runtime",      "Fusion.NetworkProjectConfig",              ["AppVersion", "GameVersion"]],
            ["Fusion.Runtime",      "Fusion.NetworkRunner",                     ["GameVersion", "AppVersion"]],
            ["PhotonRealtime",      "Photon.Realtime.AppSettings",              ["AppVersion"]],
            ["Photon3Unity3D",      "Photon.Realtime.AppSettings",              ["AppVersion"]],
        ];
        console.log("[ourmenu/probe] === current AppVersion getter values ===");
        for (const [asmName, className, propNames] of readCandidates) {
            try {
                const asm = Il2Cpp.domain.assembly(asmName);
                if (!asm) continue;
                let klass: any = null;
                try { klass = asm.image.class(className); } catch (_) {}
                if (!klass) continue;
                for (const propName of propNames) {
                    try {
                        const v = klass.method("get_" + propName).invoke();
                        const s = (v && v.toString) ? v.toString() : String(v);
                        console.log(`[ourmenu/probe]   ${className}.${propName} = "${s}"`);
                    } catch (_) {}
                }
            } catch (_) {}
        }
        console.log("[ourmenu/probe] === end probe ===");
    }

    // Quest server hook — M4 pattern verbatim (m4.ts:11-23). AC has a single
    // method AppUtils.CalculatePhotonAppVersion that returns the Photon AppVersion
    // string used during matchmaking. Replace it to return our Quest string.
    let questHookInstalled = false;
    function installQuestServerHook(): void {
        if (questHookInstalled) {
            console.log("[ourmenu/quest] hook already installed");
            return;
        }
        try {
            const acAsm = Il2Cpp.domain.assembly("AnimalCompany");
            if (!acAsm) {
                console.error("[ourmenu/quest] AnimalCompany assembly not loaded yet");
                return;
            }
            const AppUtils = acAsm.image.class("AnimalCompany.AppUtils");
            const method = AppUtils.method("CalculatePhotonAppVersion");
            const spoofed = QUEST_PHOTON_VERSION;
            method.implementation = function () {
                return Il2Cpp.string(spoofed);
            };
            questHookInstalled = true;
            console.log(`[ourmenu/quest] CalculatePhotonAppVersion → "${spoofed}" (M4 pattern)`);
        } catch (e) {
            console.error("[ourmenu/quest] hook FAILED:", e);
        }
    }

    // ===== BOOT-SAFE STARTUP INSTALL =====
    // The Quest/Photon spoof, anti-cheat/VPN hooks, mod hooks, and dev mode all
    // auto-install at startup — but NOT synchronously at script load anymore.
    // When the loader is attached AT GAME LAUNCH, script load happens during
    // engine boot on the main thread, and the assembly-wide scans
    // (installAntiCheatVpnHooks' dev-hook scan walks EVERY assembly) stalled
    // boot on a black screen. Now a light 250ms poller waits for the game's
    // first rendered frame (Time.frameCount > 0 = render loop is alive), then
    // installs everything. First frame is the splash screen — still long
    // before Photon matchmaking at the main menu, so the spoof + dev mode are
    // always active "on start" no matter when you attach.
    function installCriticalHooks(tag: string): void {
        console.log("======================================================================");
        console.log(`[ourmenu] INSTALL @ ${tag} — Quest spoof="${QUEST_PHOTON_VERSION}" (latest M4 m4.ts)`);
        console.log("======================================================================");
        installAntiCheatVpnHooks();
        installQuestServerHook();     // confirmed working — auto-install
        installModHooks();            // wire all toggle-based mod hooks
        logCurrentAppId();
    }

    // ===== STAGGERED DEV-MODE + AUTO UNLOCK ALL RETRIES =====
    // The "button by the shop" the user is asking about is AC's in-game dev
    // unlock-all UI. Hard to summon via Frida without AC's exact UI class graph.
    // Instead, we auto-trigger BOTH dev mode AND Unlock All at each retry —
    // same end result (dev items visible, all items owned) without needing the
    // AC button to appear at all. Stages are now relative to GAME-READY (first
    // rendered frame), not script load, so attaching at launch can't burn
    // through every retry while the game is still booting.

    function gameIsRendering(): boolean {
        try {
            const fc = TimeClass.method("get_frameCount").invoke();
            return typeof fc === "number" ? fc > 0 : !!fc;
        } catch (_) { return false; }
    }

    let bootPollMs = 0;
    const BOOT_POLL_INTERVAL_MS = 250;
    const BOOT_POLL_MAX_MS = 180_000;
    function bootPoll(): void {
        let ready = false;
        try { Il2Cpp.perform(() => { ready = gameIsRendering(); }); } catch (_) {}
        if (!ready && bootPollMs < BOOT_POLL_MAX_MS) {
            bootPollMs += BOOT_POLL_INTERVAL_MS;
            if (bootPollMs % 5000 === 0) {
                console.log(`[ourmenu] waiting for game to start rendering... (${bootPollMs / 1000}s)`);
            }
            setTimeout(bootPoll, BOOT_POLL_INTERVAL_MS);
            return;
        }
        const tag = ready ? "game-ready" : "timeout-fallback (game never rendered a frame in 180s?)";
        try { Il2Cpp.perform(() => installCriticalHooks(tag)); }
        catch (e) { console.error("[ourmenu] startup install failed:", e); }
        // One follow-up pass 2s later for stragglers + the version probe.
        setTimeout(() => {
            try { Il2Cpp.perform(() => {
                installCriticalHooks("+2s retry");
                probePhotonVersion();
            }); } catch (_) {}
        }, 2000);
    }
    bootPoll();

    // TMP requires a font asset. Without one, TextMeshPro renders nothing.
    // Pattern from M4's gettmpfontnocrash: fetch via TMP_Settings.defaultFontAsset.
    let tmpDefaultFontAsset: any = null;
    function getTmpFont(): any {
        if (tmpDefaultFontAsset && !tmpDefaultFontAsset.isNull?.()) return tmpDefaultFontAsset;
        if (!TMPSettingsClass) return null;
        try {
            tmpDefaultFontAsset = TMPSettingsClass.method("get_defaultFontAsset").invoke();
            if (tmpDefaultFontAsset && !tmpDefaultFontAsset.isNull?.()) return tmpDefaultFontAsset;
        } catch (_) {}
        try {
            const inst = TMPSettingsClass.method("get_instance").invoke();
            if (inst && !inst.isNull?.()) {
                try {
                    tmpDefaultFontAsset = inst.method("get_defaultFontAsset").invoke();
                    if (tmpDefaultFontAsset && !tmpDefaultFontAsset.isNull?.()) return tmpDefaultFontAsset;
                } catch (_) {}
                try {
                    tmpDefaultFontAsset = inst.field("m_defaultFontAsset").value;
                } catch (_) {}
            }
        } catch (_) {}
        return tmpDefaultFontAsset && !tmpDefaultFontAsset.isNull?.() ? tmpDefaultFontAsset : null;
    }

    // Shader lookups are LAZY (resolved on first menu build, cached after).
    // Shader.Find is a main-thread graphics call; running it at script load —
    // which, when the loader is attached at game launch, happens during engine
    // boot — risked stalling startup. The menu builds long after boot, so
    // deferring costs nothing.

    // Shader required for translucent panels. URP Unlit handles alpha correctly.
    let UberShader: any = null;
    let uberShaderTried = false;
    function getUberShader(): any {
        if (uberShaderTried) return UberShader;
        uberShaderTried = true;
        try {
            UberShader = Shader.method("Find").invoke(Il2Cpp.string("Universal Render Pipeline/Unlit"));
            if (!UberShader || UberShader.isNull?.()) {
                UberShader = Shader.method("Find").invoke(Il2Cpp.string("Unlit/Transparent"));
            }
        } catch (_) {}
        if (UberShader && UberShader.isNull?.()) UberShader = null;
        if (!UberShader) {
            console.error("[ourmenu] Couldn't load transparent shader — panels will be opaque");
        }
        return UberShader;
    }

    // Shader for see-through elements (the on-screen keyboard): legacy
    // "GUI/Text Shader" has ZTest Always + ZWrite Off hardcoded, alpha-blends
    // via _Color, ships in Unity's always-included shader list, and (having no
    // LightMode tag) renders as SRPDefaultUnlit under URP. Panels using it draw
    // on top of world geometry — including your hand.
    let OverlayShader: any = null;
    let overlayShaderTried = false;
    function getOverlayShader(): any {
        if (overlayShaderTried) return OverlayShader;
        overlayShaderTried = true;
        try {
            OverlayShader = Shader.method("Find").invoke(Il2Cpp.string("GUI/Text Shader"));
            if (OverlayShader && OverlayShader.isNull?.()) OverlayShader = null;
        } catch (_) { OverlayShader = null; }
        if (!OverlayShader) {
            console.error("[ourmenu] GUI/Text Shader not found — keyboard will not render through the hand");
        }
        return OverlayShader;
    }

    // ============================================================
    // Theme (matched to screenshots: dark blue/purple striped panels)
    // ============================================================
    const COLOR = {
        panelBg:        [0.09, 0.09, 0.16, 0.88] as [number, number, number, number], // dark base
        panelStripe:    [0.05, 0.05, 0.11, 0.60] as [number, number, number, number], // darker rows
        tabBg:          [0.18, 0.18, 0.26, 0.95] as [number, number, number, number],
        tabActive:      [0.35, 0.30, 0.50, 1.00] as [number, number, number, number],
        infoBg:         [0.09, 0.09, 0.16, 0.88] as [number, number, number, number],
        foldoutArrow:   [0.85, 0.85, 0.95, 1.00] as [number, number, number, number],
        textPrimary:    [1.00, 1.00, 1.00, 1.00] as [number, number, number, number],
        textSecondary: [0.78, 0.78, 0.88, 1.00] as [number, number, number, number],
        accent:         [0.62, 0.50, 0.95, 1.00] as [number, number, number, number],
    };

    // ============================================================
    // Tab definitions (top row + main row from the screenshot)
    // ============================================================
    const tabsTop  = ["Settings"];
    // "Sounds" dropped per user request. "Player" + "Players" are now two
    // distinct tabs: Player = last-selected player's detail view, Players = full
    // in-room list.
    const tabsMain = ["Movement", "Items", "Prefabs", "Exploits", "Player", "Players", "Misc"];

    // ============================================================
    // Placeholder data — everything labeled "test"
    // ============================================================
    interface ListEntry {
        label: string;        // shown in left panel
        count: number;        // the ":24" looking number
        children: string[];   // sub-items when expanded
    }

    // Reduced from 18 → 6 rows to cut down the per-build cost of creating ~30
    // TMP labels. Once the visual is dialed in, we can bring rows back.
    const LIST_ROWS = 6;
    const placeholderList: ListEntry[] = Array.from({ length: LIST_ROWS }, (_, i) => ({
        label: "test",
        count: i,
        children: ["test", "test", "test"],
    }));

    // OP mod names ported verbatim from M4 (da.ts category 9 "Over Powered"). Each
    // is rendered as a clickable row button — onClick currently logs only, since
    // real implementations depend on M4's massive helper library (getAllNetPlayersList,
    // spawnNetworkPrefab, etc.) which we haven't ported. Wiring individual mods is
    // a per-mod follow-up; this gets the visual + click plumbing in place.
    const OP_MODS: string[] = [
        "Item Launcher",
        "Right Hand Duper",
        "Item Rain",
        "Goop Spammer",
        "Piss Mod",
        "Grab Selling Machine",
        "Mob Orbit",
        "Prefab Orbit",
        "Spaz Explode Machine",
        "Item Tornado",
        "Lag All Items",
        "Cage All Players",
        "Give Masterclient",
        "Stash Dupe",
        "Change Eject Dupe Amount",
        "Rocket Launcher",
        "flaregun",
        "boomspear",
        "Robot Dog RPG",
        "ChristmasBox Orbit self",
        "Christmas Present Tower",
        "Sellingmachine Orbit self",
        "Sellingmachine Tower Orbit",
        "Moon Buggy Orbit self",
        "Tree Forest Orbit",
        "Infinite Ammo",
        "No Recoil",
        "No Shotgun Cooldown",
        "Rapid Fire",
        "Nut Pickup Gun",
        "Ammo Pickup Gun",
    ];
    // Removed buttons (auto-installed at script launch, no need to click them):
    //   "Connect Quest Servers" — installQuestServerHook() runs at startup

    const infoLines: { left: string; right: string }[] = [
        { left: "test", right: "test" },
        { left: "test", right: "test" },
        { left: "test", right: "test" },
        { left: "test", right: "test" },
    ];

    // ============================================================
    // Helpers (modeled on M4's createObject/renderMenuText pattern)
    // ============================================================
    const zeroVec: [number, number, number] = [0, 0, 0];
    const idQuat = Quaternion.method("get_identity").invoke();

    function getTransform(go: any): any {
        return go.method("get_transform").invoke();
    }

    function getComponent(go: any, klass: any): any {
        return go.method("GetComponent", 1).inflate(klass).invoke();
    }

    function addComponent(go: any, klass: any): any {
        return go.method("AddComponent", 1).inflate(klass).invoke();
    }

    function createEmpty(name: string, parent: any | null): any {
        // Default path: CreatePrimitive(Cube) + hide renderer. Used for the menuRoot
        // and textRoot containers where we want a working transform but no rendering.
        const go = GameObject.method("CreatePrimitive").invoke(3); // Cube
        try { go.method("set_name").invoke(Il2Cpp.string(name)); } catch (_) {}
        try {
            const rend = getComponent(go, Renderer);
            if (rend && !rend.isNull?.()) rend.method("set_enabled").invoke(false);
        } catch (_) {}
        try {
            const col = getComponent(go, BoxCollider);
            if (col && !col.isNull?.()) col.method("set_enabled").invoke(false);
        } catch (_) {}
        if (parent) {
            getTransform(go).method("SetParent", 2).invoke(parent, false);
        }
        return go;
    }

    // Real empty GameObject for TextMeshPro hosting (no pre-existing MeshRenderer
    // / MeshFilter / BoxCollider from CreatePrimitive). M4's pattern. Safe to use
    // because we're inside an Interceptor.onEnter (Unity main thread).
    function createEmptyForText(name: string, parent: any | null): any {
        try {
            const go = GameObject.alloc();
            try { go.method(".ctor", 1).invoke(Il2Cpp.string(name)); }
            catch (_) {
                try { go.method(".ctor", 0).invoke(); } catch (_) {}
                try { go.method("set_name").invoke(Il2Cpp.string(name)); } catch (_) {}
            }
            if (parent) {
                getTransform(go).method("SetParent", 2).invoke(parent, false);
            }
            return go;
        } catch (_) {
            // Fallback: use the primitive-based path
            return createEmpty(name, parent);
        }
    }

    /**
     * Build a flat colored quad/cube panel.
     * @param parent parent transform (Transform il2cpp object) or null
     * @param localPos local position [x, y, z]
     * @param scale    [x, y, z] world scale
     * @param color    rgba 0..1
     * @param primitiveTypeId 3 = Cube, 5 = Quad
     */
    function createPanel(
        parent: any | null,
        localPos: [number, number, number],
        scale: [number, number, number],
        color: [number, number, number, number],
        name: string,
        primitiveTypeId: number = 3,
    ): any {
        // Pattern from M4's da.ts createObject(): no overload count on CreatePrimitive
        const go = GameObject.method("CreatePrimitive").invoke(primitiveTypeId);
        try { go.method("set_name").invoke(Il2Cpp.string(name)); } catch (_) {}
        const tr = getTransform(go);
        if (parent) {
            tr.method("SetParent", 2).invoke(parent, false);
        }
        tr.method("set_localPosition").invoke(localPos);
        tr.method("set_localRotation").invoke(idQuat);
        tr.method("set_localScale").invoke(scale);

        // Disable collider (don't destroy — keep the GO simple)
        try {
            const col = getComponent(go, BoxCollider);
            if (col && !col.isNull?.()) {
                col.method("set_enabled").invoke(false);
                col.method("set_isTrigger").invoke(true);
            }
        } catch (_) {}

        // Material: set transparent shader THEN color, so alpha is respected
        try {
            const rend = getComponent(go, Renderer);
            if (rend && !rend.isNull?.()) {
                const mat = rend.method("get_material").invoke();
                const uber = getUberShader();
                if (uber) {
                    try { mat.method("set_shader").invoke(uber); } catch (_) {}
                }
                mat.method("set_color").invoke(color);
            }
        } catch (_) {}

        return go;
    }

    // Make a panel/button render through world geometry (your hand). Swaps the
    // material to OverlayShader (ZTest Always) and overrides renderQueue so
    // layering among see-through elements is explicit (higher = on top; the
    // overlay shader has ZWrite Off, so draw order alone decides what wins).
    function makeSeeThrough(go: any, queue: number): void {
        try {
            const rend = getComponent(go, Renderer);
            if (!rend || rend.isNull?.()) return;
            const mat = rend.method("get_material").invoke();
            if (!mat || mat.isNull?.()) return;
            // Capture color BEFORE the shader swap: URP Unlit stores it in
            // _BaseColor, GUI/Text Shader in _Color — values don't carry across.
            let color: any = null;
            try { color = mat.method("get_color").invoke(); } catch (_) {}
            const overlay = getOverlayShader();
            if (overlay) {
                try { mat.method("set_shader").invoke(overlay); } catch (_) {}
                if (color) { try { mat.method("set_color").invoke(color); } catch (_) {} }
            }
            try { mat.method("set_renderQueue").invoke(queue); } catch (_) {}
        } catch (_) {}
    }

    // Same idea for a TMP label. TMP's SDF shaders declare `ZTest
    // [unity_GUIZTestMode]`, so setting that property to 8 (CompareFunction.
    // Always) makes the glyphs draw through geometry. get_material() instances
    // the shared font material first, so the rest of the menu's text keeps
    // normal depth testing. The legacy-TextMesh fallback path already uses
    // GUI/Text Shader (ZTest Always) natively, so it needs no help.
    function makeTextSeeThrough(textGo: any, queue: number): void {
        try {
            const rend = getComponent(textGo, Renderer);
            if (!rend || rend.isNull?.()) return;
            const mat = rend.method("get_material").invoke();
            if (!mat || mat.isNull?.()) return;
            try {
                mat.method("SetInt").overload("System.String", "System.Int32")
                    .invoke(Il2Cpp.string("unity_GUIZTestMode"), 8);
            } catch (_) {
                try {
                    mat.method("SetFloat").overload("System.String", "System.Single")
                        .invoke(Il2Cpp.string("unity_GUIZTestMode"), 8.0);
                } catch (_) {}
            }
            try { mat.method("set_renderQueue").invoke(queue); } catch (_) {}
        } catch (_) {}
    }

    // No longer used — text rotation now derives from the surface's world rotation.

    // Text is now safe — we build the menu from inside an Interceptor.attach
    // onEnter wrapped in Il2Cpp.perform, so AddComponent(TextMeshPro) runs on
    // Unity's main thread with a properly attached IL2CPP context.
    const TEXT_ENABLED = true;

    // M4-style text renderer:
    //   - text GameObject parented to textRoot (scale 1) — NOT the panel
    //   - world position computed via surface(panel).TransformPoint(anchorLocal)
    //   - world rotation = surface.rotation (so text faces same way as panel front)
    //   - localScale adjusted via setMenuTextScale-style math to give a consistent
    //     readable size regardless of menuRoot scale
    //
    // `surface` is the panel GameObject (we use its rotation/TransformPoint).
    // `anchorLocal` is in the panel's local space; z should be > 0.5 to sit just
    //   past the +Z face of the cube primitive.
    // `baseScale` is the final world height of a glyph (~0.012m is a reasonable
    //   wrist-menu glyph height).
    let renderTextCount = 0;
    function resetRenderTextDiagnostic() { renderTextCount = 0; }
    function renderText(
        surface: any,
        text: string,
        anchorLocal: [number, number, number],
        baseScale: number,
        color: [number, number, number, number],
        align: number = 514,
    ) {
        renderTextCount++;
        const isFirst = renderTextCount === 1;
        if (isFirst) {
            dbg(`renderText first call, text="${text}"`);
            dbg(`  TextMeshPro3D class: ${TextMeshPro3D ? "OK" : "NULL"}`);
            dbg(`  TextMeshLegacy class: ${TextMeshLegacy ? "OK" : "NULL"}`);
        }
        if (!TEXT_ENABLED) { if (isFirst) dbg("  TEXT_ENABLED is false — returning"); return null; }
        if (!textRoot) {
            if (isFirst) dbg("  textRoot is NULL — returning");
            return null;
        }
        try {
            // ---------- Try TMP first ----------
            if (TextMeshPro3D) {
                const font = getTmpFont();
                if (isFirst) {
                    dbg(`  TMP font: ${font ? (font.isNull?.() ? "NULL handle" : "OK") : "null"}`);
                }
                if (font && !font.isNull?.()) {
                    const STEP = (n: string, fn: () => void) => {
                        if (isFirst) console.log(`[ourmenu]   step: ${n}`);
                        try { fn(); }
                        catch (e) {
                            if (isFirst) dbg(`renderText step "${n}" THREW: ${e}`);
                            throw e;
                        }
                    };
                    let go: any = null;
                    let tmp: any = null;
                    STEP("createEmptyForText", () => { go = createEmptyForText("Label_TMP", textRoot); });
                    STEP("addComponent(TMP)",   () => { tmp = addComponent(go, TextMeshPro3D); });
                    STEP("set_font",            () => { tmp.method("set_font").invoke(font); });
                    STEP("get/set material",    () => {
                        const rend = getComponent(go, Renderer);
                        if (rend && !rend.isNull?.()) {
                            rend.method("set_enabled").invoke(true);
                            const fontMat = font.method("get_material").invoke();
                            try { rend.method("set_sharedMaterial").invoke(fontMat); }
                            catch (_) { try { rend.method("set_material").invoke(fontMat); } catch (_) {} }
                        }
                    });
                    STEP("SetText",             () => {
                        try { tmp.method("SetText", 1).invoke(Il2Cpp.string(text)); }
                        catch (_) { tmp.method("set_text").invoke(Il2Cpp.string(text)); }
                    });
                    STEP("set_fontSize",        () => { tmp.method("set_fontSize").invoke(3.0); });
                    STEP("set_color",           () => { tmp.method("set_color").invoke(color); });
                    STEP("set_alignment",       () => { tmp.method("set_alignment").invoke(align); });
                    // set_enableWordWrapping + ForceMeshUpdate are OPTIONAL and their
                    // overload sets vary by TMP version. They MUST NOT abort text:
                    // ForceMeshUpdate's 0-arg form is absent in this build and the
                    // old STEP() rethrew, which killed EVERY label before
                    // placeTextOnSurface could size/position it. Best-effort only.
                    try { tmp.method("set_enableWordWrapping").invoke(false); } catch (_) {}
                    try { tmp.method("ForceMeshUpdate", 0).invoke(); }
                    catch (_) {
                        try { tmp.method("ForceMeshUpdate", 1).invoke(false); } catch (_) {}
                        // else: skip — TMP regenerates its mesh on its own next frame.
                    }
                    STEP("placeTextOnSurface",  () => { placeTextOnSurface(go, surface, anchorLocal, baseScale); });
                    if (!firstTextGo) firstTextGo = go;
                    if (!(globalThis as any).__ourmenu_textbackend_logged) {
                        (globalThis as any).__ourmenu_textbackend_logged = true;
                        dbg("text backend = TMP (font OK)");
                    }
                    return go;
                }
            }

            // ---------- Fallback: legacy TextMesh + Arial.ttf ----------
            if (isFirst) dbg("renderText: TMP path skipped (font null?) — falling back to legacy TextMesh");
            if (!TextMeshLegacy) { if (isFirst) dbg("renderText: TextMeshLegacy NULL — NO TEXT BACKEND"); return null; }
            const arial = getArialFont();
            if (isFirst) dbg(`renderText: Arial.ttf = ${arial ? (arial.isNull?.() ? "NULL handle" : "OK") : "null"}`);
            if (!arial || arial.isNull?.()) return null;
            const go = createEmptyForText("Label_Mesh", textRoot);
            const tm = addComponent(go, TextMeshLegacy);
            try { tm.method("set_font").invoke(arial); } catch (_) {}
            try {
                const rend = getComponent(go, Renderer);
                if (rend && !rend.isNull?.()) {
                    rend.method("set_enabled").invoke(true);
                    const fontMat = arial.method("get_material").invoke();
                    try { rend.method("set_sharedMaterial").invoke(fontMat); }
                    catch (_) { try { rend.method("set_material").invoke(fontMat); } catch (_) {} }
                }
            } catch (_) {}
            try { tm.method("set_text").invoke(Il2Cpp.string(text)); } catch (_) {}
            try { tm.method("set_fontSize").invoke(100); } catch (_) {}
            try { tm.method("set_characterSize").invoke(0.025); } catch (_) {}
            try { tm.method("set_color").invoke(color); } catch (_) {}
            try { tm.method("set_anchor").invoke(4); } catch (_) {} // MiddleCenter
            try { tm.method("set_alignment").invoke(1); } catch (_) {} // Center
            placeTextOnSurface(go, surface, anchorLocal, baseScale);
            if (!(globalThis as any).__ourmenu_textbackend_logged) {
                (globalThis as any).__ourmenu_textbackend_logged = true;
                dbg("text backend = legacy TextMesh (Arial.ttf)");
            }
            return go;
        } catch (e) {
            if (!(globalThis as any).__ourmenu_text_err_logged) {
                (globalThis as any).__ourmenu_text_err_logged = true;
                dbg(`renderText THREW (text="${text}"): ${e}`);
                console.error(`[ourmenu] renderText failed (text="${text}"):`, e);
            }
            return null;
        }
    }

    // Place a text GameObject at a world-space position derived from the surface
    // panel's local anchor, with rotation matching the panel and a uniform world
    // scale that compensates for any scale inherited from the parent chain
    // (especially the hand transform, which can be heavily scaled in AC).
    // ===== PORTED FROM M4 (da.ts renderMenuText + setMenuTextScale) =====
    // M4's pipeline, line-for-line, with only orientation adapted for our panels:
    //   * M4's panels are thin on +X → text gets Euler(0,90,90) + X-mirror to face +X.
    //   * Our panels are thin on +Z → text already faces +Z (TMP default) → no
    //     rotation correction needed, no X-mirror needed.
    //
    // The recipe (matches M4 exactly otherwise):
    //   1. Parent text to `textRoot` (sibling of panels, NOT the panel itself).
    //   2. WORLD position = panel.TransformPoint(anchorLocal). Anchor is in panel
    //      unit-cube space (-0.5..0.5 on each axis).
    //   3. WORLD rotation = panel.rotation (text faces panel's +Z = front face).
    //   4. LOCAL scale = baseScale / menuRoot.localScale (M4's setMenuTextScale).
    //      With our menuRoot at (1,1,1), this collapses to [base, base, base] in
    //      world units — identical effective text world scale as M4's build.
    //
    // Auto-size lock: see `pendingTexts` push at the bottom — a few frames after
    // build, deferredMeasure() reads the real glyph height and corrects every
    // text in one pass. We don't have to guess baseScale right anymore.
    //
    // ===== TEXT-SIZE-POP CACHE =====
    // First build: cachedTextCorrection=1.0, text placed too big, deferredMeasure
    // measures the over-sized glyph, computes correction (e.g. 0.36), and stores
    // it here. THE FIRST BUILD STILL VISIBLY POPS — that's unavoidable without
    // pre-measuring the font.
    // Every build after that: placeTextOnSurface multiplies baseScale by 0.36
    // immediately, so text appears at correct size from frame 1. deferredMeasure
    // still runs but its correction lands ≈ 1.0 → no visible jump.
    let cachedTextCorrection = 1.0;
    // STABLE-SIZE LOCK: once one measurement succeeds, the correction is final.
    // Re-measuring on every rebuild made text size drift on page changes —
    // each page's FIRST label differs (header vs body, different baseScale),
    // so each page computed a different correction and banked it cumulatively.
    let textCorrectionLocked = false;
    function placeTextOnSurface(
        textGo: any,
        surface: any,
        anchorLocal: [number, number, number],
        baseScale: number,
    ) {
        const surfaceTr = getTransform(surface);
        const textTr = getTransform(textGo);

        // 1. Parent to textRoot (M4 line 2614: createEmptyObject("MenuText", getTransform(textRootObject))).
        if (textRoot) {
            try { textTr.method("SetParent", 2).invoke(textRoot, false); } catch (_) {}
        }

        // 2. WORLD position via panel TransformPoint. Z negated to put text on
        //    the user-facing face of the panel (was on the back face).
        const anchorFront: [number, number, number] = [anchorLocal[0], anchorLocal[1], -anchorLocal[2]];
        try {
            const worldPos = surfaceTr.method("TransformPoint", 1).invoke(anchorFront);
            textTr.method("set_position").invoke(worldPos);
        } catch (_) {
            try { textTr.method("set_localPosition").invoke(anchorFront); } catch (_) {}
        }

        // 3. WORLD rotation = panel.rotation. Panels are upright facing camera, so
        //    text flush with panel = text upright facing camera. Simple.
        try {
            const surfaceRot = surfaceTr.method("get_rotation").invoke();
            textTr.method("set_rotation").invoke(surfaceRot);
        } catch (_) {}

        // 4. LOCAL scale via setMenuTextScale logic (M4 line 1129-1140).
        //    Read menuRoot's localScale; divide baseScale by each axis. Since
        //    our menuRoot is (1,1,1), this is just [base, base, base].
        let sx = 1, sy = 1, sz = 1;
        try {
            const rootTr2 = getTransform(menuRoot);
            const ms = rootTr2.method("get_localScale").invoke();
            sx = Math.abs(ms.field("x").value as number) || 1;
            sy = Math.abs(ms.field("y").value as number) || 1;
            sz = Math.abs(ms.field("z").value as number) || 1;
        } catch (_) {}
        // ===== TEXT-SIZE-POP FIX =====
        // Pre-apply the cached correction factor learned from previous deferredMeasure()
        // runs. First build still pops (correction=1.0, deferredMeasure measures & caches),
        // but every rebuild after that uses the cached factor at placement time → text
        // appears at correct size immediately, no visible jump 8 frames later.
        const effectiveScale = baseScale * cachedTextCorrection;
        const cx = effectiveScale / sx;
        const cy = effectiveScale / sy;
        const cz = effectiveScale / sz;
        // Positive X. Text on front face → user sees TMP's natural front of quad.
        // (-X was needed earlier when text was on the BACK face and user saw the
        // mirror-rendered backside through the panel.)
        try {
            textTr.method("set_localScale").invoke([cx, cy, cz]);
        } catch (e) {
            if (!(globalThis as any).__ourmenu_scale_err_logged) {
                (globalThis as any).__ourmenu_scale_err_logged = true;
                console.error("[ourmenu] set_localScale FAILED:", e);
            }
        }

        // Track for the deferred auto-correction pass. Saves the per-text scale
        // we set so we can rescale to the measured-correct value later.
        try { pendingTexts.push({ go: textGo, baseScale }); } catch (_) {}
        return;

    }

    // AUTO-SIZE LOCK. Run a few frames after build, once TMP has generated its
    // mesh (synchronous bounds-read at build time returns 0). Measure the first
    // text's real world glyph height, compute correction = TARGET / measured,
    // and rescale every tracked text by that factor. baseScale at the call sites
    // becomes irrelevant — final size is set by TARGET_GLYPH_H in one shot.
    const TARGET_GLYPH_H = 0.009; // meters — readable wrist-menu glyph height
    function deferredMeasure(): void {
        let out = "=== ourmenu auto-size lock (mesh settled) ===\n";
        try {
            if (textCorrectionLocked) return; // size already locked — never re-measure
            if (!firstTextGo || firstTextGo.isNull?.()) {
                writeFileDual(MEASURE_PATH, out + "no first text object captured\n");
                return;
            }
            const tr = getComponent(firstTextGo, Renderer);
            const b = tr.method("get_bounds").invoke();
            const sz = b.method("get_size").invoke();
            const measuredH = sz.field("y").value as number;
            out += `measured glyph height: ${measuredH.toFixed(5)} m\n`;
            out += `target  glyph height: ${TARGET_GLYPH_H.toFixed(5)} m\n`;
            if (measuredH <= 1e-6) {
                out += "=> text mesh still empty; TMP not rendering this text\n";
                writeFileDual(MEASURE_PATH, out);
                return;
            }
            const correction = TARGET_GLYPH_H / measuredH;
            // Sanity window: a bogus bounds read (mid-regeneration mesh, emoji
            // glyph, etc.) must not get locked in as the permanent size.
            if (correction < 0.05 || correction > 20) {
                out += `=> correction ${correction.toFixed(4)} outside sanity window [0.05, 20] — skipped, will retry next build\n`;
                writeFileDual(MEASURE_PATH, out);
                return;
            }
            // Bank the correction into the module-level cache so every later
            // build's placeTextOnSurface pre-applies it, and LOCK it — one
            // measurement is the single source of truth for text size from now
            // on. Page changes no longer re-measure (that caused size drift).
            cachedTextCorrection = cachedTextCorrection * correction;
            textCorrectionLocked = true;
            out += `=> correction factor: ${correction.toFixed(4)} (cached now: ${cachedTextCorrection.toFixed(4)}, LOCKED)\n`;
            out += `=> applying to ${pendingTexts.length} text object(s)...\n`;
            // Rescale every tracked text by the correction factor. Reads the
            // CURRENT localScale and multiplies — preserves any per-axis sign.
            let applied = 0, failed = 0;
            for (const entry of pendingTexts) {
                try {
                    if (!entry || !entry.go || entry.go.isNull?.()) continue;
                    const ttr = getTransform(entry.go);
                    const cur = ttr.method("get_localScale").invoke();
                    const cxn = (cur.field("x").value as number) * correction;
                    const cyn = (cur.field("y").value as number) * correction;
                    const czn = (cur.field("z").value as number) * correction;
                    ttr.method("set_localScale").invoke([cxn, cyn, czn]);
                    applied++;
                } catch (_) { failed++; }
            }
            out += `=> applied=${applied} failed=${failed}\n`;
            out += `done. Text now sized to ${(TARGET_GLYPH_H * 1000).toFixed(1)}mm glyph height.\n`;
        } catch (e) {
            out += "deferredMeasure FAILED: " + e + "\n";
        }
        writeFileDual(MEASURE_PATH, out);
    }

    // ============================================================
    // Menu geometry — overall dimensions in world units
    //   left panel  ~ 0.60 wide
    //   gap         ~ 0.02
    //   right panel ~ 0.28 wide
    //   total       ~ 0.90 wide x 0.62 tall
    // ============================================================
    // Wrist-menu dimensions (in meters). Scaled up ~50% from previous pass — total
    // ~40cm wide × 22cm tall. Easier to see and read while in the headset.
    const G = {
        leftPanelW:    0.255,
        leftPanelH:    0.225,
        rightPanelW:   0.128,
        rightPanelH:   0.225,
        gap:           0.008,
        panelDepth:    0.006,
        tabBarH:       0.022,
        tabTopRowH:    0.015,
        rowH:          0.0105,
        rowGap:        0.0015,
        leftEdgeIndent:0.010,
        headerPad:     0.006,
    };

    // ============================================================
    // Build the menu
    // ============================================================
    let menuRoot: any = null;

    // Set during buildMenu; renderText parents text to this (scale 1, identity rot)
    // and computes world positions via the surface's TransformPoint. Following
    // M4's renderMenuText pattern verbatim.
    let textRoot: any = null;

    function buildMenu(forceFloating: boolean = false): any {
        resetRenderTextDiagnostic();
        __dbgBuf = "";
        // Reset one-shot guards EVERY build, else a rebuild (menu stays open and
        // Y is held again) skips the measurement and its file-write overwrites the
        // first build's, hiding the data. These persist on globalThis otherwise.
        (globalThis as any).__ourmenu_measured = false;
        (globalThis as any).__ourmenu_textbackend_logged = false;
        (globalThis as any).__ourmenu_text_err_logged = false;
        (globalThis as any).__ourmenu_scale_err_logged = false;
        dbg("buildMenu: start");
        // Prefer hand attachment (M4-style). The menu follows the hand for free.
        const handTr = forceFloating ? null : getHandTransform(/*useRight=*/false);
        dbg("buildMenu: handTr resolved = " + (handTr ? "OK" : "NULL"));

        menuRoot = createEmpty("OurMenuRoot", handTr);
        dbg("buildMenu: menuRoot created");
        const rootTr = getTransform(menuRoot);
        dbg("buildMenu: rootTr fetched");

        // textRoot is a scale-1 sibling of the panels. Text gets parented here,
        // then positioned absolutely in world space via panel.TransformPoint(),
        // so it isn't distorted by the panels' thin Z scale.
        // CRITICAL: store as TRANSFORM (not GameObject), since createEmptyForText
        // passes it as the SetParent argument which expects a Transform.
        textRoot = getTransform(createEmpty("OurMenuTextRoot", rootTr));
        console.log("[ourmenu] buildMenu: textRoot created");

        if (handTr) {
            rootTr.method("set_localPosition").invoke([0.0, 0.05, 0.10]);
            rootTr.method("set_localRotation").invoke(
                Quaternion.method("Euler").invoke(120.0, 0.0, 0.0)
            );
            console.log("[ourmenu] attached to left hand");
        } else {
            // Hand not ready — fall back to camera-locked placement
            let placedFromCamera = false;
            try {
                const cam = Camera.method("get_main").invoke();
                if (cam && !cam.isNull?.()) {
                    const camTr = getTransform(cam.method("get_gameObject").invoke());
                    const worldPos = camTr.method("TransformPoint", 1).invoke([0, 0, 0.4]);
                    const camRot = camTr.method("get_rotation").invoke();
                    rootTr.method("set_position").invoke(worldPos);
                    rootTr.method("set_rotation").invoke(camRot);
                    placedFromCamera = true;
                }
            } catch (_) {}
            if (!placedFromCamera) {
                rootTr.method("set_position").invoke([0, 1.5, 1]);
            }
            console.log("[ourmenu] hand not available — using camera-front fallback");
        }

        try {
            dbg("buildMenu: about to buildLeftPanel");
            buildLeftPanel(rootTr);
            dbg("buildMenu: left panel done");
            buildRightPanel(rootTr);
            dbg("buildMenu: right panel done");
            buildTabBar(rootTr);
            dbg("buildMenu: tab bar done");
            buildButtonRow(rootTr);
            dbg("buildMenu: button row done");
            // === TOOLTIP PANEL DISABLED (user request) ===
            // The description box to the left of the main panels has been removed.
            // currentTooltipLabel still tracks the last-clicked mod (used elsewhere)
            // but no panel renders. To re-enable: uncomment the line below.
            // buildTooltipPanel(rootTr);
            // dbg("buildMenu: tooltip panel done");
            // === ITEM PICKER PANEL (only renders when Items tab is active) ===
            buildItemListPanel(rootTr);
            dbg("buildMenu: item list panel done");
            // === PREFAB PICKER PANEL (only renders when Prefabs tab is active) ===
            buildPrefabListPanel(rootTr);
            dbg("buildMenu: prefab list panel done");
            // === ON-SCREEN KEYBOARD (only renders when searchKeyboardOpen) ===
            buildKeyboard(rootTr);
            dbg("buildMenu: keyboard done");
            createPointerBall();
            dbg("buildMenu: pointer ball done");
        } catch (e) {
            dbg("buildMenu: THREW: " + e);
        } finally {
            dbg(`buildMenu: renderText was called ${renderTextCount} time(s)`);
            dbgFlush();
        }

        return menuRoot;
    }

    // ----- Left panel ------------------------------------------------
    // ----- Settings view (alternative left panel content) -----
    function buildSettingsView(parent: any, leftX: number) {
        const usableTop = (G.leftPanelH / 2) - G.tabBarH - G.headerPad;
        const usableBot = -(G.leftPanelH / 2) + G.headerPad;
        const navH = 0.020;
        const navGap = 0.004;
        const listTop = usableTop;
        const listBot = usableBot + navH + navGap;
        const listH = listTop - listBot;
        const rowGap = 0.005;
        const ROWS = 4;   // header + fire-rate row + spacer + back
        const rowH = (listH - (ROWS - 1) * rowGap) / ROWS;
        const rowStride = rowH + rowGap;
        const btnInset = 0.006;
        const btnW = G.leftPanelW - 2 * btnInset;

        // Row 0: header label
        const headerY = listTop - rowH / 2;
        createButton(
            parent,
            [leftX, headerY, -G.panelDepth * 0.55],
            [btnW, rowH * 0.96, G.panelDepth * 0.5],
            "— SETTINGS —",
            COLOR.panelStripe,
            () => {},
        );

        // Row 1: Fire Rate cycler
        const fireRateY = listTop - rowStride - rowH / 2;
        const fr = getFireRate();
        const fireRateLabel = `Fire Rate: ${fr.toFixed(3)}s (${(1 / fr).toFixed(1)}/s)`;
        createButton(
            parent,
            [leftX, fireRateY, -G.panelDepth * 0.55],
            [btnW, rowH * 0.96, G.panelDepth * 0.5],
            fireRateLabel,
            COLOR.tabBg,
            () => {
                fireRateIndex = (fireRateIndex + 1) % FIRE_RATE_PRESETS.length;
                console.log(`[ourmenu/settings] Fire rate → ${getFireRate()}s`);
                rebuildMenu();
            },
        );

        // Row 2: real draggable scrollbar.
        //   - Hit-zone panel: full-row sized, registered with the slider system.
        //     Pointer + right trigger inside this zone starts a drag.
        //   - Visible track: thin bar showing the slider line.
        //   - Knob: marker on the line, lives at the current preset's t.
        // During drag the knob's localPosition.x follows the pointer's local X
        // (clamped to [-0.5, +0.5] of the hit-zone). fireRateIndex updates LIVE
        // every frame so the per-frame mods using getFireRate() see new values
        // immediately. On trigger release we commit the snapped index and
        // rebuild the menu (label refreshes to the new rate).
        const sliderY = listTop - rowStride * 2 - rowH / 2;
        const sliderW = btnW;
        const trackVisualH = rowH * 0.30 * 0.4;       // skinny visible track
        const hitH = rowH * 0.95;                      // generous hit-zone
        const knobVisualH = rowH * 0.85;               // tall knob — easy to see
        const knobVisualW = sliderW * 0.06;
        const trackLeftEdgeX = leftX - sliderW / 2;
        const sliderZ = -G.panelDepth * 0.55;
        const knobZ = -G.panelDepth * 0.60;

        // Hit-zone panel — full slider row. Slightly lighter than the panel
        // background so the user can see this is the draggable area.
        const hitGo = createPanel(
            parent,
            [leftX, sliderY, sliderZ],
            [sliderW, hitH, G.panelDepth * 0.5],
            COLOR.tabBg,
            "FireRateSliderHit",
        );
        const hitTr = getTransform(hitGo);
        // Track (visible thin bar laid over the hit zone).
        createPanel(
            parent,
            [leftX, sliderY, sliderZ - 0.0005],
            [sliderW, trackVisualH, G.panelDepth * 0.5],
            COLOR.panelStripe,
            "FireRateTrack",
        );
        // Knob (movable). Live drag rewrites this Transform's localPosition.
        const progress = fireRateIndex / Math.max(1, FIRE_RATE_PRESETS.length - 1);
        const knobX = trackLeftEdgeX + sliderW * progress;
        const knobGo = createPanel(
            parent,
            [knobX, sliderY, knobZ],
            [knobVisualW, knobVisualH, G.panelDepth * 0.5],
            COLOR.tabActive,
            "FireRateKnob",
        );
        const knobTr = getTransform(knobGo);
        const knobBaseY = sliderY;
        const knobBaseZ = knobZ;
        const snapCount = FIRE_RATE_PRESETS.length;
        menuSliders.push({
            label: "FireRate",
            hitTr,
            hitHalfExtents: [sliderW * 0.5, hitH * 0.5, (G.panelDepth * 0.5) * 0.5],
            onDrag: (t: number) => {
                // Live preview: knob follows the pointer 1:1 across the row.
                const liveX = trackLeftEdgeX + sliderW * t;
                try {
                    knobTr.method("set_localPosition").invoke([liveX, knobBaseY, knobBaseZ]);
                } catch (_) {}
                // Live fire-rate update so per-frame mods feel the change while
                // dragging. Snap to nearest preset so the value stays sane.
                const idx = Math.max(0, Math.min(snapCount - 1, Math.round(t * (snapCount - 1))));
                if (idx !== fireRateIndex) {
                    fireRateIndex = idx;
                }
            },
            onCommit: (t: number) => {
                // Final snap on release — clamp to a preset.
                fireRateIndex = Math.max(0, Math.min(snapCount - 1, Math.round(t * (snapCount - 1))));
                console.log(`[ourmenu/settings] Fire rate committed → ${getFireRate()}s (idx ${fireRateIndex})`);
            },
        });

        // Row 3: Back button
        const backY = listBot + navH / 2;
        createButton(
            parent,
            [leftX, backY, -G.panelDepth * 0.55],
            [btnW * 0.6, navH, G.panelDepth * 0.5],
            "< Back to OP",
            COLOR.tabActive,
            () => { currentLeftView = "op"; rebuildMenu(); },
        );
    }

    // Per-group mod lists. Each tab that has a real list of mods registers
    // them here; the left panel renders them as toggle buttons (same wiring as
    // the Exploits page — color reflects isModToggleOn, click goes through
    // tryRunModToggle). Tabs not in this map fall back to a placeholder view.
    const MOVEMENT_MODS: string[] = [
        "Fly",
        "Joystick Fly",
    ];

    // ----- Group mod-list view (used by groups that have real wired mods) -----
    function buildModListView(parent: any, leftX: number, groupLabel: string, mods: string[]) {
        const usableTop = (G.leftPanelH / 2) - G.tabBarH - G.headerPad;
        const usableBot = -(G.leftPanelH / 2) + G.headerPad;
        const navH = 0.020;
        const navGap = 0.004;
        const listTop = usableTop;
        const listBot = usableBot + navH + navGap;
        const listH = listTop - listBot;
        const btnInset = 0.006;
        const btnW = G.leftPanelW - 2 * btnInset;

        // Header label.
        const headerH = 0.045;
        const headerY = listTop - headerH / 2;
        createButton(
            parent,
            [leftX, headerY, -G.panelDepth * 0.55],
            [btnW, headerH, G.panelDepth * 0.5],
            `— ${groupLabel.toUpperCase()} —`,
            COLOR.panelStripe,
            () => {},
        );

        // Mod rows. Big rows since we have few entries; one row per mod.
        const rowsTop = headerY - headerH / 2 - 0.008;
        const rowsBot = listBot;
        const rowsH = rowsTop - rowsBot;
        const rowGap = 0.005;
        const maxRows = Math.max(1, mods.length);
        const rowH = Math.min(0.05, (rowsH - (maxRows - 1) * rowGap) / maxRows);
        const rowStride = rowH + rowGap;

        for (let i = 0; i < mods.length; i++) {
            const label = mods[i];
            const rowY = rowsTop - (i * rowStride) - (rowH / 2);
            const onClick = () => {
                currentTooltipLabel = label;
                if (tryRunModToggle(label)) {
                    // toggled; rebuild to refresh color + tooltip
                } else {
                    console.log(`[ourmenu] "${label}" (no toggle handler)`);
                }
                rebuildMenu();
            };
            const btnColor = isModToggleOn(label) ? COLOR.tabActive : COLOR.tabBg;
            createButton(
                parent,
                [leftX, rowY, -G.panelDepth * 0.55],
                [btnW, rowH * 0.96, G.panelDepth * 0.5],
                label,
                btnColor,
                onClick,
            );
        }

        // Back-to-Exploits nav at the very bottom of the panel.
        const navY = usableBot + navH / 2;
        createButton(
            parent,
            [leftX, navY, -G.panelDepth * 0.55],
            [btnW * 0.6, navH, G.panelDepth * 0.5],
            "< Back to Exploits",
            COLOR.tabActive,
            () => { currentLeftView = "op"; rebuildMenu(); },
        );
    }

    // ----- Players view (list of all players in the room + bulk toggles) -----
    function buildPlayersView(parent: any, leftX: number) {
        // Minimal layout: header at the top, big list of player rows filling
        // the panel, page nav at the bottom. No bulk-action grid — the per-
        // player dropdown (orbit / bring / WL toggle / etc.) is reachable by
        // clicking any player row, which is what the user asked for. All the
        // WL bulk plumbing still exists in the per-player detail view.
        const usableTop = (G.leftPanelH / 2) - G.tabBarH - G.headerPad;
        const usableBot = -(G.leftPanelH / 2) + G.headerPad;
        const navH = 0.020;
        const navGap = 0.004;
        const listTop = usableTop;
        const listBot = usableBot + navH + navGap;
        const btnInset = 0.006;
        const btnW = G.leftPanelW - 2 * btnInset;

        // Header strip: passive "— PLAYERS (n) —" label on the left, clickable
        // "WL Tools" button on the right (jumps to the global whitelist controls).
        // The (n) count is the total roster size before paging.
        const headerH = 0.035;
        const headerY = listTop - headerH / 2;
        const headerGap = 0.003;
        const headerLeftW = (btnW * 0.62) - headerGap / 2;
        const headerRightW = (btnW * 0.38) - headerGap / 2;
        const headerLeftX = leftX - btnW / 2 + headerLeftW / 2;
        const headerRightX = leftX + btnW / 2 - headerRightW / 2;
        // (Roster fetch happens below — we need it for the (n) count, so peek
        // here by reading it once and reusing.)
        const allHeaderPreview = getAllNetPlayersList(true);
        createButton(
            parent,
            [headerLeftX, headerY, -G.panelDepth * 0.55],
            [headerLeftW, headerH, G.panelDepth * 0.5],
            `— PLAYERS (${allHeaderPreview.length}) —`,
            COLOR.panelStripe,
            () => {},
        );
        const wlBtnColor = (currentLeftView as LeftView) === "wlTools" ? COLOR.tabActive : COLOR.tabBg;
        createButton(
            parent,
            [headerRightX, headerY, -G.panelDepth * 0.55],
            [headerRightW, headerH, G.panelDepth * 0.5],
            `WL Tools (${playerWhitelist.size})`,
            wlBtnColor,
            () => { currentLeftView = "wlTools"; rebuildMenu(); },
        );

        // Reuse the roster already fetched for the header count — avoids paying
        // for getAllNetPlayersList() twice per build.
        const all = allHeaderPreview;
        // First open: dump the NetPlayer class shape so we can see what field/
        // method actually carries the display name on this build. Triggers
        // once total per session.
        if (all.length > 0) dumpNetPlayerShape(all[0]);
        const totalPages = Math.max(1, Math.ceil(all.length / PLAYERS_PER_PAGE));
        if (playerListPage >= totalPages) playerListPage = 0;
        const startIdx = playerListPage * PLAYERS_PER_PAGE;
        const endIdx = Math.min(startIdx + PLAYERS_PER_PAGE, all.length);

        // List rows: pack the panel from just below the header down to just
        // above the nav strip, splitting evenly across PLAYERS_PER_PAGE slots.
        const listSectionTop = headerY - headerH / 2 - 0.006;
        const listSectionBot = listBot + 0.004;
        const listSectionH = listSectionTop - listSectionBot;
        const rowGap = 0.004;
        const rowH = (listSectionH - (PLAYERS_PER_PAGE - 1) * rowGap) / PLAYERS_PER_PAGE;
        const rowStride = rowH + rowGap;

        if (all.length === 0) {
            // Empty-room state — show a friendly notice instead of bare rows.
            const midY = (listSectionTop + listSectionBot) / 2;
            const notice = createPanel(
                parent,
                [leftX, midY, -G.panelDepth * 0.6],
                [btnW, 0.05, G.panelDepth * 0.4],
                COLOR.panelBg,
                "PlayersEmpty",
            );
            renderText(notice, "no players in room", [0, 0, 1.0], 0.022, COLOR.textSecondary, 514);
        } else {
            for (let r = 0; r < PLAYERS_PER_PAGE; r++) {
                const idx = startIdx + r;
                if (idx >= endIdx) break;
                const p = all[idx];
                const k = playerKeyOf(p);
                const isLocal = playerIsLocal(p);
                const name = getPlayerName(p);
                const wl = whitelistHasPlayer(p);
                const orb = playerOrbitKeys.has(k);
                const flags: string[] = [];
                if (isLocal) flags.push("ME");
                if (wl) flags.push("WL");
                if (orb) flags.push("ORB");
                const label = flags.length > 0 ? `${name}  [${flags.join("/")}]` : name;
                const rowY = listSectionTop - r * rowStride - rowH / 2;
                // Self row is dimmed and a tap is a no-op (no accidental self-RPC).
                // Whitelisted rows take on the accent so you can spot your roster.
                const color = isLocal ? COLOR.panelStripe : (wl ? COLOR.accent : COLOR.tabBg);
                createButton(
                    parent,
                    [leftX, rowY, -G.panelDepth * 0.55],
                    [btnW, rowH * 0.96, G.panelDepth * 0.5],
                    label,
                    color,
                    () => {
                        // DIAGNOSTIC: fires unconditionally so we can confirm the
                        // hit-test reached this row's handler at all.
                        console.log(`[ourmenu/players-click] row tapped: name="${name}" key="${k}" isLocal=${isLocal}`);
                        if (isLocal) {
                            console.log(`[ourmenu/players] (self — no detail)`);
                            return;
                        }
                        try {
                            selectedPlayerKey = k;
                            currentLeftView = "playerDetail";
                            playerDetailPage = 0;  // always land on base-action page first
                            console.log(`[ourmenu/players] selected "${name}" (${k}) → currentLeftView=${currentLeftView}`);
                            rebuildMenu();
                            console.log(`[ourmenu/players] rebuildMenu() returned (view now: ${currentLeftView})`);
                        } catch (e) {
                            console.error(`[ourmenu/players] click handler threw:`, e);
                        }
                    },
                );
            }
        }

        // Bottom nav: < Prev | Page X/Y | Next >
        const navY = usableBot + navH / 2;
        const innerNavW = (btnW - 2 * 0.003) / 3;
        const xPrev = leftX - (innerNavW + 0.003);
        const xMid = leftX;
        const xNext = leftX + (innerNavW + 0.003);
        createButton(
            parent,
            [xPrev, navY, -G.panelDepth * 0.55],
            [innerNavW, navH, G.panelDepth * 0.5],
            "< Prev",
            COLOR.tabActive,
            () => { playerListPage = (playerListPage - 1 + totalPages) % totalPages; rebuildMenu(); },
        );
        createButton(
            parent,
            [xMid, navY, -G.panelDepth * 0.55],
            [innerNavW, navH, G.panelDepth * 0.5],
            `Page ${playerListPage + 1}/${totalPages}`,
            COLOR.panelStripe,
            () => {},   // passive page indicator
        );
        createButton(
            parent,
            [xNext, navY, -G.panelDepth * 0.55],
            [innerNavW, navH, G.panelDepth * 0.5],
            "Next >",
            COLOR.tabActive,
            () => { playerListPage = (playerListPage + 1) % totalPages; rebuildMenu(); },
        );
    }

    // ----- Player detail view (dropdown of actions for the selected player) -----
    function buildPlayerDetailView(parent: any, leftX: number) {
        const usableTop = (G.leftPanelH / 2) - G.tabBarH - G.headerPad;
        const usableBot = -(G.leftPanelH / 2) + G.headerPad;
        const navH = 0.020;
        const navGap = 0.004;
        const listTop = usableTop;
        const listBot = usableBot + navH + navGap;
        const btnInset = 0.006;
        const btnW = G.leftPanelW - 2 * btnInset;

        const target = selectedPlayerKey ? findPlayerByKey(selectedPlayerKey) : null;
        const name = target ? getPlayerName(target) : (selectedPlayerKey ?? "?");

        // Row 0: header
        const headerH = 0.035;
        const headerY = listTop - headerH / 2;
        createButton(
            parent,
            [leftX, headerY, -G.panelDepth * 0.55],
            [btnW, headerH, G.panelDepth * 0.5],
            `— ${name} —`,
            COLOR.panelStripe,
            () => {},
        );

        if (!target) {
            // Player left the room or alias changed. Show a notice + Back.
            const midY = (headerY + listBot) / 2;
            const notice = createPanel(
                parent,
                [leftX, midY, -G.panelDepth * 0.6],
                [btnW, 0.05, G.panelDepth * 0.4],
                COLOR.panelBg,
                "PlayerGone",
            );
            // Distinguish "you never picked anyone" from "they left the room"
            // so the singular Player tab isn't confusing on first open.
            const noticeText = selectedPlayerKey
                ? "Player not in room"
                : "Pick a player from the\nPlayers tab first";
            renderText(notice, noticeText, [0, 0, 1.0], 0.022, COLOR.textSecondary, 514);
            const navY = usableBot + navH / 2;
            createButton(
                parent,
                [leftX, navY, -G.panelDepth * 0.55],
                [btnW * 0.6, navH, G.panelDepth * 0.5],
                "< Back to Players",
                COLOR.tabActive,
                () => { currentLeftView = "Players"; rebuildMenu(); },
            );
            return;
        }

        // Action grid: 2 columns × 4 rows = 8 actions per page.
        // 3 pages total (paged via "More >" nav button at the bottom):
        //   Page 0 — base player ops:
        //     Bring          | Goto
        //     Orbit (toggle) | Launch Up
        //     Send to Floor  | Kill
        //     Revive         | (empty)
        //   Page 1 — effects + toggles:
        //     Stinky    | Rainbow
        //     Speed     | Stun 5s
        //     Freeze    | Invisible
        //     Void      | Invincible
        const gridTop = headerY - headerH / 2 - 0.008;
        const gridBot = usableBot + navH + navGap + 0.004;
        const gridH = gridTop - gridBot;
        const rows = 4;
        const cellGap = 0.005;
        const cellH = (gridH - (rows - 1) * cellGap) / rows;
        const cellW = (btnW - cellGap) / 2;
        const leftCellX = leftX - (cellW + cellGap) / 2;
        const rightCellX = leftX + (cellW + cellGap) / 2;

        const orbiting = playerOrbitKeys.has(selectedPlayerKey ?? "");
        const PLAYER_DETAIL_PAGES = 2;
        if (playerDetailPage < 0) playerDetailPage = PLAYER_DETAIL_PAGES - 1;
        if (playerDetailPage >= PLAYER_DETAIL_PAGES) playerDetailPage = 0;

        type DetailAction = {
            label: string; col: 0 | 1; row: number;
            color: [number, number, number, number];
            onClick: () => void;
        };

        const pageActions: DetailAction[][] = [
            // ===== Page 0 — base player ops =====
            [
                {
                    label: "Bring", col: 0, row: 0, color: COLOR.tabBg,
                    onClick: () => {
                        const ok = playerBring(target);
                        console.log(`[ourmenu/players] Bring "${name}" → ${ok}`);
                        rebuildMenu();
                    },
                },
                {
                    label: "Goto", col: 1, row: 0, color: COLOR.tabBg,
                    onClick: () => {
                        const ok = playerGoto(target);
                        console.log(`[ourmenu/players] Goto "${name}" → ${ok}`);
                        rebuildMenu();
                    },
                },
                {
                    label: orbiting ? "Orbit: ON" : "Orbit: OFF",
                    col: 0, row: 1, color: orbiting ? COLOR.tabActive : COLOR.tabBg,
                    onClick: () => {
                        if (orbiting) playerOrbitKeys.delete(selectedPlayerKey!);
                        else playerOrbitKeys.add(selectedPlayerKey!);
                        console.log(`[ourmenu/players] Orbit "${name}" ${!orbiting ? "ON" : "OFF"}`);
                        rebuildMenu();
                    },
                },
                {
                    label: "Launch Up", col: 1, row: 1, color: COLOR.tabBg,
                    onClick: () => {
                        const ok = playerLaunchUp(target, 1500);
                        console.log(`[ourmenu/players] Launch "${name}" → ${ok}`);
                        rebuildMenu();
                    },
                },
                {
                    label: "Send Floor", col: 0, row: 2, color: COLOR.tabBg,
                    onClick: () => {
                        const ok = playerSendFloor(target);
                        console.log(`[ourmenu/players] Floor "${name}" → ${ok}`);
                        rebuildMenu();
                    },
                },
                {
                    label: "Kill", col: 1, row: 2, color: COLOR.foldoutArrow,
                    onClick: () => {
                        const ok = playerKill(target);
                        console.log(`[ourmenu/players] Kill "${name}" → ${ok}`);
                        rebuildMenu();
                    },
                },
                {
                    label: "Revive", col: 0, row: 3, color: COLOR.tabBg,
                    onClick: () => {
                        const ok = playerRevive(target);
                        console.log(`[ourmenu/players] Revive "${name}" → ${ok}`);
                        rebuildMenu();
                    },
                },
            ],
            // ===== Page 1 — effects + toggles =====
            [
                {
                    label: "Stinky", col: 0, row: 0, color: COLOR.tabBg,
                    onClick: () => {
                        const ok = playerStinky(target);
                        console.log(`[ourmenu/players] Stinky "${name}" → ${ok}`);
                        rebuildMenu();
                    },
                },
                {
                    label: "Rainbow", col: 1, row: 0, color: COLOR.tabBg,
                    onClick: () => {
                        const ok = playerRainbowOnce(target);
                        console.log(`[ourmenu/players] Rainbow "${name}" → ${ok}`);
                        rebuildMenu();
                    },
                },
                {
                    label: "Speed Buff", col: 0, row: 1, color: COLOR.tabBg,
                    onClick: () => {
                        const ok = playerSpeedBuff(target);
                        console.log(`[ourmenu/players] SpeedBuff "${name}" → ${ok}`);
                        rebuildMenu();
                    },
                },
                {
                    label: "Stun 5s", col: 1, row: 1, color: COLOR.tabBg,
                    onClick: () => {
                        const ok = playerStunFor(target, 5.0);
                        console.log(`[ourmenu/players] Stun5s "${name}" → ${ok}`);
                        rebuildMenu();
                    },
                },
                {
                    label: "Freeze", col: 0, row: 2, color: COLOR.foldoutArrow,
                    onClick: () => {
                        const ok = playerFreeze(target);
                        console.log(`[ourmenu/players] Freeze "${name}" → ${ok}`);
                        rebuildMenu();
                    },
                },
                {
                    label: "Invisible", col: 1, row: 2, color: COLOR.tabBg,
                    onClick: () => {
                        const ok = playerInvisible(target);
                        console.log(`[ourmenu/players] Invisible "${name}" → ${ok}`);
                        rebuildMenu();
                    },
                },
                {
                    label: "Void", col: 0, row: 3, color: COLOR.foldoutArrow,
                    onClick: () => {
                        const ok = playerVoid(target);
                        console.log(`[ourmenu/players] Void "${name}" → ${ok}`);
                        rebuildMenu();
                    },
                },
                {
                    label: "Invincible", col: 1, row: 3, color: COLOR.tabBg,
                    onClick: () => {
                        const ok = playerInvincibleToggle(target);
                        console.log(`[ourmenu/players] Invincible toggle "${name}" → ${ok}`);
                        rebuildMenu();
                    },
                },
            ],
        ];

        const actions = pageActions[playerDetailPage];
        for (const a of actions) {
            const cx = a.col === 0 ? leftCellX : rightCellX;
            const cy = gridTop - a.row * (cellH + cellGap) - cellH / 2;
            createButton(
                parent,
                [cx, cy, -G.panelDepth * 0.55],
                [cellW, cellH, G.panelDepth * 0.5],
                a.label,
                a.color,
                a.onClick,
            );
        }

        // Bottom nav row: < Back to Players | Page X/3 | More >
        const navY = usableBot + navH / 2;
        const innerNavW = (btnW - 2 * 0.003) / 3;
        const xPrev = leftX - (innerNavW + 0.003);
        const xMid = leftX;
        const xNext = leftX + (innerNavW + 0.003);
        createButton(
            parent,
            [xPrev, navY, -G.panelDepth * 0.55],
            [innerNavW, navH, G.panelDepth * 0.5],
            "< Back",
            COLOR.tabActive,
            () => { currentLeftView = "Players"; playerDetailPage = 0; rebuildMenu(); },
        );
        createButton(
            parent,
            [xMid, navY, -G.panelDepth * 0.55],
            [innerNavW, navH, G.panelDepth * 0.5],
            `Page ${playerDetailPage + 1}/${PLAYER_DETAIL_PAGES}`,
            COLOR.panelStripe,
            () => {},   // passive page indicator
        );
        createButton(
            parent,
            [xNext, navY, -G.panelDepth * 0.55],
            [innerNavW, navH, G.panelDepth * 0.5],
            "More >",
            COLOR.tabActive,
            () => {
                playerDetailPage = (playerDetailPage + 1) % PLAYER_DETAIL_PAGES;
                rebuildMenu();
            },
        );
    }

    // ----- WL Tools view (global whitelist controls + loop toggles) -----
    // Ported from M4 da.ts:8245-9039 + 12053-12159 (Whitelist mods category).
    // The per-player WL one-shot actions live on playerDetail pages 1-2; this
    // page hosts the GLOBAL controls (toggle WL gating, clear, bulk apply, loops).
    function buildWlToolsView(parent: any, leftX: number) {
        const usableTop = (G.leftPanelH / 2) - G.tabBarH - G.headerPad;
        const usableBot = -(G.leftPanelH / 2) + G.headerPad;
        const navH = 0.020;
        const navGap = 0.004;
        const listTop = usableTop;
        const listBot = usableBot + navH + navGap;
        const btnInset = 0.006;
        const btnW = G.leftPanelW - 2 * btnInset;

        // Row 0: header
        const headerH = 0.035;
        const headerY = listTop - headerH / 2;
        const wlCount = playerWhitelist.size;
        createButton(
            parent,
            [leftX, headerY, -G.panelDepth * 0.55],
            [btnW, headerH, G.panelDepth * 0.5],
            `— WL TOOLS (${wlCount}) —`,
            COLOR.panelStripe,
            () => {},
        );

        // Action grid: 2 cols × 5 rows = 10 cells. Last cell (R4C1) is reserved
        // padding to keep visual rhythm.
        //   r0: Whitelist Enabled (toggle) | Clear WL
        //   r1: Revive All WL              | TP All WL 2 Me
        //   r2: List WL (console log)      | Speed Loop (toggle)
        //   r3: AntiGrav Loop (toggle)     | Invincible Loop (toggle)
        //   r4: Revive Loop (toggle)       | Rainbow Loop (toggle)
        const gridTop = headerY - headerH / 2 - 0.008;
        const gridBot = usableBot + navH + navGap + 0.004;
        const gridH = gridTop - gridBot;
        const rows = 5;
        const cellGap = 0.005;
        const cellH = (gridH - (rows - 1) * cellGap) / rows;
        const cellW = (btnW - cellGap) / 2;
        const leftCellX = leftX - (cellW + cellGap) / 2;
        const rightCellX = leftX + (cellW + cellGap) / 2;

        type WlToolAction = {
            label: string; col: 0 | 1; row: number;
            color: [number, number, number, number];
            onClick: () => void;
        };

        const actions: WlToolAction[] = [
            {
                label: whitelistEnabled ? "WL Gate: ON" : "WL Gate: OFF",
                col: 0, row: 0,
                color: whitelistEnabled ? COLOR.tabActive : COLOR.tabBg,
                onClick: () => {
                    whitelistEnabled = !whitelistEnabled;
                    console.log(`[ourmenu/wl] WL Gate ${whitelistEnabled ? "ON (WL-only)" : "OFF (everyone)"}`);
                    rebuildMenu();
                },
            },
            {
                label: "Clear WL", col: 1, row: 0, color: COLOR.foldoutArrow,
                onClick: () => {
                    const n = wlClear();
                    console.log(`[ourmenu/wl] Clear → removed ${n} entries`);
                    rebuildMenu();
                },
            },
            {
                label: "Revive All WL", col: 0, row: 1, color: COLOR.tabBg,
                onClick: () => {
                    const n = wlReviveAll();
                    console.log(`[ourmenu/wl] ReviveAll → ${n}`);
                    rebuildMenu();
                },
            },
            {
                label: "TP All WL 2 Me", col: 1, row: 1, color: COLOR.tabBg,
                onClick: () => {
                    const n = wlTpAll2Me();
                    console.log(`[ourmenu/wl] TpAll2Me → ${n}`);
                    rebuildMenu();
                },
            },
            {
                label: "List WL", col: 0, row: 2, color: COLOR.tabBg,
                onClick: () => {
                    const arr = wlList();
                    console.log(`[ourmenu/wl] List → ${arr.length} entries (logged above)`);
                    rebuildMenu();
                },
            },
            {
                label: wlAllSpeedLoopEnabled ? "Speed Loop: ON" : "Speed Loop: OFF",
                col: 1, row: 2,
                color: wlAllSpeedLoopEnabled ? COLOR.tabActive : COLOR.tabBg,
                onClick: () => {
                    wlAllSpeedLoopEnabled = !wlAllSpeedLoopEnabled;
                    wlSpeedLoopNext = 0;  // fire immediately on next frame
                    console.log(`[ourmenu/wl] Speed Loop ${wlAllSpeedLoopEnabled ? "ON" : "OFF"}`);
                    rebuildMenu();
                },
            },
            {
                label: wlAllAntiGravLoopEnabled ? "AntiGrav Loop: ON" : "AntiGrav Loop: OFF",
                col: 0, row: 3,
                color: wlAllAntiGravLoopEnabled ? COLOR.tabActive : COLOR.tabBg,
                onClick: () => {
                    wlAllAntiGravLoopEnabled = !wlAllAntiGravLoopEnabled;
                    wlAntiGravLoopNext = 0;
                    console.log(`[ourmenu/wl] AntiGrav Loop ${wlAllAntiGravLoopEnabled ? "ON" : "OFF"}`);
                    rebuildMenu();
                },
            },
            {
                label: wlInvincibleLoopEnabled ? "Invinc Loop: ON" : "Invinc Loop: OFF",
                col: 1, row: 3,
                color: wlInvincibleLoopEnabled ? COLOR.tabActive : COLOR.tabBg,
                onClick: () => {
                    wlInvincibleLoopEnabled = !wlInvincibleLoopEnabled;
                    wlInvincibleLoopNext = 0;
                    console.log(`[ourmenu/wl] Invincible Loop ${wlInvincibleLoopEnabled ? "ON" : "OFF"}`);
                    rebuildMenu();
                },
            },
            {
                label: wlReviveLoopEnabled ? "Revive Loop: ON" : "Revive Loop: OFF",
                col: 0, row: 4,
                color: wlReviveLoopEnabled ? COLOR.tabActive : COLOR.tabBg,
                onClick: () => {
                    wlReviveLoopEnabled = !wlReviveLoopEnabled;
                    wlReviveLoopNext = 0;
                    console.log(`[ourmenu/wl] Revive Loop ${wlReviveLoopEnabled ? "ON" : "OFF"}`);
                    rebuildMenu();
                },
            },
            {
                label: wlRainbowLoopEnabled ? "Rainbow Loop: ON" : "Rainbow Loop: OFF",
                col: 1, row: 4,
                color: wlRainbowLoopEnabled ? COLOR.tabActive : COLOR.tabBg,
                onClick: () => {
                    wlRainbowLoopEnabled = !wlRainbowLoopEnabled;
                    console.log(`[ourmenu/wl] Rainbow Loop ${wlRainbowLoopEnabled ? "ON" : "OFF"}`);
                    rebuildMenu();
                },
            },
        ];

        for (const a of actions) {
            const cx = a.col === 0 ? leftCellX : rightCellX;
            const cy = gridTop - a.row * (cellH + cellGap) - cellH / 2;
            createButton(
                parent,
                [cx, cy, -G.panelDepth * 0.55],
                [cellW, cellH, G.panelDepth * 0.5],
                a.label,
                a.color,
                a.onClick,
            );
        }

        // Bottom nav: Back to Players list.
        const navY = usableBot + navH / 2;
        createButton(
            parent,
            [leftX, navY, -G.panelDepth * 0.55],
            [btnW * 0.6, navH, G.panelDepth * 0.5],
            "< Back to Players",
            COLOR.tabActive,
            () => { currentLeftView = "Players"; rebuildMenu(); },
        );
    }

    // ----- Placeholder view (used for groups that aren't built out yet) -----
    function buildPlaceholderView(parent: any, leftX: number, groupLabel: string, blurb: string) {
        const usableTop = (G.leftPanelH / 2) - G.tabBarH - G.headerPad;
        const usableBot = -(G.leftPanelH / 2) + G.headerPad;
        const navH = 0.020;
        const navGap = 0.004;
        const listTop = usableTop;
        const listBot = usableBot + navH + navGap;
        const listH = listTop - listBot;
        const btnInset = 0.006;
        const btnW = G.leftPanelW - 2 * btnInset;

        // Header label
        const headerY = listTop - 0.04;
        createButton(
            parent,
            [leftX, headerY, -G.panelDepth * 0.55],
            [btnW, 0.045, G.panelDepth * 0.5],
            `— ${groupLabel.toUpperCase()} —`,
            COLOR.panelStripe,
            () => {},
        );

        // Centered placeholder card
        const cardH = 0.12;
        const cardY = (listTop + listBot) / 2;
        createPanel(
            parent,
            [leftX, cardY, -G.panelDepth * 0.55],
            [btnW * 0.9, cardH, G.panelDepth * 0.5],
            COLOR.tabBg,
            `Placeholder_${groupLabel}`,
        );
        // Big group label (centered text on the card)
        const cardTransform = createPanel(
            parent,
            [leftX, cardY + 0.025, -G.panelDepth * 0.6],
            [btnW * 0.85, 0.04, G.panelDepth * 0.4],
            COLOR.panelBg,
            `PlaceholderLabel_${groupLabel}`,
        );
        renderText(cardTransform, groupLabel, [0, 0, 1.0], 0.040, COLOR.textPrimary, 514);
        // Blurb below
        const blurbTransform = createPanel(
            parent,
            [leftX, cardY - 0.02, -G.panelDepth * 0.6],
            [btnW * 0.85, 0.05, G.panelDepth * 0.4],
            COLOR.panelBg,
            `PlaceholderBlurb_${groupLabel}`,
        );
        renderText(blurbTransform, blurb, [0, 0, 1.0], 0.022, COLOR.textSecondary, 514);
        // "Coming soon" mini tag
        const tagTransform = createPanel(
            parent,
            [leftX, cardY - 0.045, -G.panelDepth * 0.6],
            [btnW * 0.40, 0.025, G.panelDepth * 0.4],
            COLOR.panelStripe,
            `PlaceholderTag_${groupLabel}`,
        );
        renderText(tagTransform, "( coming soon )", [0, 0, 1.0], 0.018, COLOR.textSecondary, 514);

        // Back-to-OP at the bottom (mirrors Settings view)
        const backY = listBot + navH / 2;
        createButton(
            parent,
            [leftX, backY, -G.panelDepth * 0.55],
            [btnW * 0.6, navH, G.panelDepth * 0.5],
            "< Back to Exploits",
            COLOR.tabActive,
            () => { currentLeftView = "op"; rebuildMenu(); },
        );
    }

    function buildLeftPanel(parent: any) {
        // Center the whole menu: total span = leftW + gap + rightW
        // Left panel center sits at -totalW/2 + leftW/2
        const totalW = G.leftPanelW + G.gap + G.rightPanelW;
        const leftX = -(totalW / 2) + (G.leftPanelW / 2);
        const baseY = 0;
        const z = 0;

        const panel = createPanel(
            parent,
            [leftX, baseY, z],
            [G.leftPanelW, G.leftPanelH, G.panelDepth],
            COLOR.panelBg,
            "LeftPanel",
        );
        const panelTr = getTransform(panel);

        // Dispatch by current view. "op" and "Exploits" share the OP-mod list
        // (Exploits is the canonical tab name). Everything else routes to its
        // own placeholder until those groups are built out.
        if (currentLeftView === "settings") {
            buildSettingsView(parent, leftX);
            return;
        }
        if (currentLeftView === "Movement") {
            buildModListView(parent, leftX, "Movement", MOVEMENT_MODS);
            return;
        }
        if (currentLeftView === "Items") {
            buildItemsView(parent, leftX);
            return;
        }
        if (currentLeftView === "Prefabs") {
            buildPrefabsView(parent, leftX);
            return;
        }
        // "Players" (plural) → full in-room player list.
        if (currentLeftView === "Players") {
            buildPlayersView(parent, leftX);
            return;
        }
        // "Player" (singular) → detail view of the LAST-SELECTED player. If
        // nothing was selected yet, buildPlayerDetailView's null-target branch
        // shows a placeholder + "Back to Players" nav.
        if (currentLeftView === "Player") {
            buildPlayerDetailView(parent, leftX);
            return;
        }
        if (currentLeftView === "playerDetail") {
            buildPlayerDetailView(parent, leftX);
            return;
        }
        if (currentLeftView === "wlTools") {
            buildWlToolsView(parent, leftX);
            return;
        }
        if (currentLeftView === "Misc") {
            buildPlaceholderView(parent, leftX, "Misc",
                "Things that don't fit\nany of the other groups\nend up here.");
            return;
        }
        // "Exploits" and the legacy "op" alias both fall through to the OP list.

        // OP mods list — paged. BUTTONS_PER_PAGE rows per page, with Prev/Next at
        // the bottom that re-build the menu on the new page. Bigger rows since
        // fewer per page.
        const usableTop = (G.leftPanelH / 2) - G.tabBarH - G.headerPad;
        const usableBot = -(G.leftPanelH / 2) + G.headerPad;
        const navH = 0.020;                 // height reserved for prev/next nav at bottom
        const navGap = 0.004;
        const listTop = usableTop;
        const listBot = usableBot + navH + navGap;
        const listH = listTop - listBot;
        const rowGap = 0.0025;
        const rowH = (listH - (BUTTONS_PER_PAGE - 1) * rowGap) / BUTTONS_PER_PAGE;
        const rowStride = rowH + rowGap;
        const btnInset = 0.006;
        const btnW = G.leftPanelW - 2 * btnInset;

        const totalPages = Math.max(1, Math.ceil(OP_MODS.length / BUTTONS_PER_PAGE));
        if (currentPage >= totalPages) currentPage = 0;
        if (currentPage < 0) currentPage = totalPages - 1;
        const startIdx = currentPage * BUTTONS_PER_PAGE;
        const endIdx = Math.min(startIdx + BUTTONS_PER_PAGE, OP_MODS.length);

        for (let r = 0; r < BUTTONS_PER_PAGE; r++) {
            const modIdx = startIdx + r;
            if (modIdx >= endIdx) break;
            const rowYLocal = listTop - (r * rowStride) - (rowH / 2);
            const label = OP_MODS[modIdx];
            // Per-label onClick. Order: special-cases first, then toggle flags,
            // then log-only for mods that still need M4's helper library ported.
            const onClick = () => {
                let didToggle = false;
                // Show this mod's description in the tooltip panel on next rebuild.
                currentTooltipLabel = label;
                if (label === "Connect Quest Servers") {
                    if (questHookInstalled) {
                        console.log(`[ourmenu/quest] already active → "${QUEST_PHOTON_VERSION}"`);
                    } else {
                        installQuestServerHook();
                    }
                    didToggle = true;
                } else if (tryRunModToggle(label)) {
                    didToggle = true;
                } else {
                    console.log(`[ourmenu] "${label}" (needs M4 helper library port — log-only)`);
                }
                // Always rebuild — both for toggle color updates AND tooltip refresh.
                rebuildMenu();
            };
            // Light the button if its corresponding mod is currently ON.
            const btnColor = isModToggleOn(label) ? COLOR.tabActive : COLOR.tabBg;
            createButton(
                parent,
                [leftX, rowYLocal, -G.panelDepth * 0.55],
                [btnW, rowH * 0.96, G.panelDepth * 0.5],
                label,
                btnColor,
                onClick,
            );
        }

        // Prev / Page X/Y / Next nav row.
        const navY = usableBot + navH / 2;
        const navW = (G.leftPanelW - 2 * btnInset - 2 * navGap) / 3;
        const xPrev = leftX - (navW + navGap);
        const xMid = leftX;
        const xNext = leftX + (navW + navGap);
        createButton(
            parent,
            [xPrev, navY, -G.panelDepth * 0.55],
            [navW, navH, G.panelDepth * 0.5],
            "< Prev",
            COLOR.tabActive,
            () => { currentPage = (currentPage - 1 + totalPages) % totalPages; rebuildMenu(); },
        );
        // Middle is a non-clickable label panel — make it visually a button but
        // its onClick is a no-op.
        createButton(
            parent,
            [xMid, navY, -G.panelDepth * 0.55],
            [navW, navH, G.panelDepth * 0.5],
            `Page ${currentPage + 1}/${totalPages}`,
            COLOR.panelStripe,
            () => {},
        );
        createButton(
            parent,
            [xNext, navY, -G.panelDepth * 0.55],
            [navW, navH, G.panelDepth * 0.5],
            "Next >",
            COLOR.tabActive,
            () => { currentPage = (currentPage + 1) % totalPages; rebuildMenu(); },
        );
    }

    // ----- Right info panel -----------------------------------------
    // Try to read the current room/session code from NetworkManager → runner →
    // SessionInfo. Probe a few field/method names because Fusion's API varies.
    function getCurrentRoomCode(): string {
        try {
            const acImage = getAcImage();
            if (!acImage) return "?";
            const NM = acImage.class("AnimalCompany.NetworkManager");
            const inst = NM.method("get_instance").invoke();
            if (!inst || inst.isNull?.()) return "(no NM instance)";
            let runner: any = null;
            for (const m of ["get_runner", "get_Runner", "get__runner", "get_currentRunner", "get__currentRunner"]) {
                try { runner = inst.method(m).invoke(); if (runner && !runner.isNull?.()) break; } catch (_) {}
            }
            if (!runner || runner.isNull?.()) return "(not in room)";
            let session: any = null;
            for (const m of ["get_SessionInfo", "get_sessionInfo"]) {
                try { session = runner.method(m).invoke(); if (session && !session.isNull?.()) break; } catch (_) {}
            }
            if (session && !session.isNull?.()) {
                for (const m of ["get_Name", "get_name", "get_RoomName", "get_RoomCode", "get_SessionName"]) {
                    try {
                        const v = session.method(m).invoke();
                        if (v) {
                            const s = v.toString ? v.toString() : String(v);
                            if (s && s !== "null" && s !== "") return s;
                        }
                    } catch (_) {}
                }
            }
            return "(unknown)";
        } catch (_) { return "(err)"; }
    }

    function disconnectFromRoom(): void {
        try {
            const acImage = getAcImage();
            if (!acImage) { console.error("[ourmenu] disconnect: no AC asm"); return; }
            const NM = acImage.class("AnimalCompany.NetworkManager");
            const inst = NM.method("get_instance").invoke();
            if (!inst || inst.isNull?.()) { console.error("[ourmenu] disconnect: no NM instance"); return; }
            inst.method("TryShutdownAndCancelConnecting").invoke();
            console.log("[ourmenu] disconnect called");
        } catch (e) { console.error("[ourmenu] disconnect FAILED:", e); }
    }

    function buildRightPanel(parent: any) {
        const totalW = G.leftPanelW + G.gap + G.rightPanelW;
        const x = (totalW / 2) - (G.rightPanelW / 2);

        const panel = createPanel(
            parent,
            [x, 0, 0],
            [G.rightPanelW, G.rightPanelH, G.panelDepth],
            COLOR.infoBg,
            "RightPanel",
        );

        // Top: room code header + value
        renderText(
            panel,
            "ROOM CODE",
            [0, 0.46, 1.0],
            0.022,
            COLOR.textSecondary,
        );
        renderText(
            panel,
            getCurrentRoomCode(),
            [0, 0.38, 1.0],
            0.042,
            COLOR.textPrimary,
        );

        // Bottom: Disconnect button (positioned in menu-local space, below panel center).
        const dcBtnH = G.tabBarH * 1.2;
        const dcBtnW = G.rightPanelW * 0.85;
        const dcBtnY = -(G.rightPanelH / 2) + dcBtnH / 2 + 0.008;
        createButton(
            parent,
            [x, dcBtnY, -G.panelDepth * 0.55],
            [dcBtnW, dcBtnH, G.panelDepth * 0.5],
            "Disconnect",
            COLOR.foldoutArrow,
            () => { disconnectFromRoom(); },
        );
    }

    // ----- Pointer ball + per-frame click check -----------------------
    // A small white sphere parented to the right hand, offset forward toward
    // the fingertip. Each frame we check OOBB overlap against every registered
    // button and fire the closest one's onClick (with debounce).
    const POINTER_RADIUS = 0.004;                            // 4 mm radius (8 mm dia) — small
    // Axis mapping discovered empirically in this AC build's right-hand frame:
    //   +Y = toward elbow      (tried, ball ended up on arm)
    //   +Z = up                (tried, ball ended up above hand)
    //   → -Y is therefore toward the fingertip.
    const POINTER_OFFSET: [number, number, number] = [0, -0.14, 0];
    function createPointerBall(): void {
        try {
            if (pointerBall && !pointerBall.isNull?.()) {
                try { Object_.method("Destroy", 1).invoke(pointerBall); } catch (_) {}
                pointerBall = null;
            }
            const rightHand = getHandTransform(/*useRight=*/true);
            // CreatePrimitive(0) = Sphere
            const ball = GameObject.method("CreatePrimitive").invoke(0);
            try { ball.method("set_name").invoke(Il2Cpp.string("OurMenuPointer")); } catch (_) {}
            const tr = getTransform(ball);
            if (rightHand) tr.method("SetParent", 2).invoke(rightHand, false);
            tr.method("set_localPosition").invoke(POINTER_OFFSET);
            tr.method("set_localScale").invoke([POINTER_RADIUS * 2, POINTER_RADIUS * 2, POINTER_RADIUS * 2]);
            // Bright white material so it's visible. Use the SAME UberShader the
            // menu panels use — the default Unity material is not single-pass
            // stereo-instanced, so it only rendered in one eye. UberShader is
            // proven to work in both eyes for this VR build.
            try {
                const rend = getComponent(ball, Renderer);
                if (rend && !rend.isNull?.()) {
                    const mat = rend.method("get_material").invoke();
                    const uber = getUberShader();
                    if (uber) {
                        try { mat.method("set_shader").invoke(uber); } catch (_) {}
                    }
                    mat.method("set_color").invoke([1.0, 1.0, 1.0, 1.0]);
                }
            } catch (_) {}
            try {
                const col = getComponent(ball, BoxCollider);
                if (col && !col.isNull?.()) col.method("set_enabled").invoke(false);
            } catch (_) {}
            makeSeeThrough(ball, 4010);
            pointerBall = ball;
        } catch (e) {
            dbg("createPointerBall FAILED: " + e);
        }
    }

    // ----- Kick Gun laser beam ----------------------------------------
    // A thin cube placed in WORLD space each frame along the head→hand aim ray
    // (NOT parented — parenting tied it to the hand bone's local axes, which is
    // exactly what made the old beam and the detection cone disagree). Created
    // lazily, then positioned/oriented/recolored per frame. See-through so it
    // draws over your own hand.
    function ensureKickGunLaser(): boolean {
        if (kickGunLaser && !kickGunLaser.isNull?.()) return true;
        try {
            const beam = GameObject.method("CreatePrimitive").invoke(3); // Cube
            try { beam.method("set_name").invoke(Il2Cpp.string("KickGunLaser")); } catch (_) {}
            try {
                const col = getComponent(beam, BoxCollider);
                if (col && !col.isNull?.()) col.method("set_enabled").invoke(false);
            } catch (_) {}
            // Stereo-safe material ONLY (UberShader = URP Unlit, proven in both
            // eyes — same as the pointer ball). Do NOT makeSeeThrough() this:
            // GUI/Text Shader is legacy, not single-pass-stereo-instanced, so
            // the beam rendered in one eye only = ghostly "transparent" look.
            // Trade-off: the beam no longer draws through your hand/walls.
            let shaderOk = false, matOk = false;
            try {
                const rend = getComponent(beam, Renderer);
                if (rend && !rend.isNull?.()) {
                    const mat = rend.method("get_material").invoke();
                    if (mat && !mat.isNull?.()) {
                        matOk = true;
                        const uber = getUberShader();
                        if (uber) { try { mat.method("set_shader").invoke(uber); shaderOk = true; } catch (_) {} }
                        // Initial opaque color in the SAME material chain as the
                        // pointer ball (proven visible). showKickGunLaser recolors.
                        try { mat.method("set_color").invoke([1.0, 0.25, 0.25, 1.0]); } catch (_) {}
                    }
                }
            } catch (_) {}
            kickGunLaser = beam;
            console.log(`[ourmenu/kickgun] laser created (material=${matOk} shader=${shaderOk})`);
            return true;
        } catch (e) {
            console.error("[ourmenu/kickgun] ensureKickGunLaser FAILED: " + e);
            return false;
        }
    }

    // Place the beam from origin `o` along unit direction `d` for `lenMeters`.
    // Long axis = local +Z (we orient with LookRotation(d) so +Z aligns with d),
    // centered at o + d*len/2.
    function showKickGunLaser(
        o: [number, number, number],
        d: [number, number, number],
        lenMeters: number,
        color: [number, number, number, number],
    ): void {
        if (!ensureKickGunLaser()) return;
        try {
            const len = Math.max(0.05, lenMeters);
            const tr = getTransform(kickGunLaser);
            tr.method("set_localScale").invoke([KICK_GUN_LASER_THICK, KICK_GUN_LASER_THICK, len]);
            try {
                const rot = Quaternion.method("LookRotation", 2).invoke(
                    makeV3(d[0], d[1], d[2]), makeV3(0, 1, 0),
                );
                tr.method("set_rotation").invoke(rot);
            } catch (_) {}
            tr.method("set_position").invoke([
                o[0] + d[0] * len / 2,
                o[1] + d[1] * len / 2,
                o[2] + d[2] * len / 2,
            ]);
            const rend = getComponent(kickGunLaser, Renderer);
            let rendEnabled = false;
            if (rend && !rend.isNull?.()) {
                try { rend.method("set_enabled").invoke(true); } catch (_) {}
                try { rendEnabled = !!rend.method("get_enabled").invoke(); } catch (_) {}
                const mat = rend.method("get_material").invoke();
                if (mat && !mat.isNull?.()) { try { mat.method("set_color").invoke(color); } catch (_) {} }
            }
            try { kickGunLaser.method("SetActive").invoke(true); } catch (_) {}
            if (!(globalThis as any).__kicklaser_logged) {
                (globalThis as any).__kicklaser_logged = true;
                let actualPos = "?";
                try {
                    const wp = readVec3Components(tr.method("get_position").invoke());
                    actualPos = `[${wp[0].toFixed(2)}, ${wp[1].toFixed(2)}, ${wp[2].toFixed(2)}]`;
                } catch (_) {}
                console.log(`[ourmenu/kickgun] laser SHOWN: origin=[${o[0].toFixed(2)},${o[1].toFixed(2)},${o[2].toFixed(2)}] dir=[${d[0].toFixed(2)},${d[1].toFixed(2)},${d[2].toFixed(2)}] len=${len.toFixed(1)} worldPos=${actualPos} rendererEnabled=${rendEnabled}`);
            }
        } catch (e) { console.error("[ourmenu/kickgun] showKickGunLaser FAILED: " + e); }
    }

    function hideKickGunLaser(): void {
        if (!kickGunLaser || kickGunLaser.isNull?.()) return;
        try { kickGunLaser.method("SetActive").invoke(false); } catch (_) {}
    }

    // Proper OBB overlap check: convert the pointer's world position into each
    // button's LOCAL frame (Transform.InverseTransformPoint), then check against
    // the unit cube [-0.5, 0.5] on every axis. This respects the button's own
    // width, height, AND thin Z depth — so a pointer hovering above/below a
    // button no longer falsely triggers it (the prior sphere check had the
    // pointer trigger zone bleed outward by ~4cm on every axis).
    let tickCount = 0;
    let nearestDistSq = Infinity;
    let nearestLabel = "";
    function tickPointer(): void {
        if (!menuActive) return;
        if (!pointerBall || pointerBall.isNull?.()) {
            if (++tickCount === 1) console.log("[ourmenu/click] tickPointer firing but pointerBall is null");
            return;
        }
        if (menuButtons.length === 0 && menuSliders.length === 0) {
            if (++tickCount === 1) console.log("[ourmenu/click] tickPointer firing but no buttons/sliders registered");
            return;
        }
        let now = 0;
        try { now = TimeClass.method("get_time").invoke() as number; } catch (_) {}

        // Resolve pointer world position once for both slider + button logic.
        let pPos: any = null;
        try {
            const pTr = getTransform(pointerBall);
            pPos = pTr.method("get_position").invoke();
        } catch (_) { return; }

        // ----- Slider drag handling (runs BEFORE button clicks) -----
        // While dragging, we consume input — buttons don't fire. The drag ends
        // the frame the right trigger goes false; we then commit and rebuild.
        if (activeSlider) {
            if (!m4_rightTrigger) {
                try {
                    const localP = activeSlider.hitTr.method("InverseTransformPoint", 1).invoke(pPos);
                    const lx = localP.field("x").value as number;
                    const t = Math.max(0, Math.min(1, lx + 0.5));
                    console.log(`[ourmenu/slider] RELEASE: ${activeSlider.label} t=${t.toFixed(3)}`);
                    activeSlider.onCommit(t);
                } catch (_) {}
                activeSlider = null;
                rebuildMenu();
                return;
            }
            try {
                const localP = activeSlider.hitTr.method("InverseTransformPoint", 1).invoke(pPos);
                const lx = localP.field("x").value as number;
                const t = Math.max(0, Math.min(1, lx + 0.5));
                activeSlider.onDrag(t);
            } catch (_) {}
            return;     // consume input — no button clicks while dragging
        }
        // New drag detection: trigger held + pointer inside any slider hitbox.
        if (m4_rightTrigger && menuSliders.length > 0) {
            for (const sl of menuSliders) {
                try {
                    const localP = sl.hitTr.method("InverseTransformPoint", 1).invoke(pPos);
                    const lx = localP.field("x").value as number;
                    const ly = localP.field("y").value as number;
                    const lz = localP.field("z").value as number;
                    const W = sl.hitHalfExtents[0] * 2 || 1e-6;
                    const H = sl.hitHalfExtents[1] * 2 || 1e-6;
                    const D = sl.hitHalfExtents[2] * 2 || 1e-6;
                    const rx = POINTER_RADIUS / W;
                    const ry = POINTER_RADIUS / H;
                    const rz = POINTER_RADIUS / D;
                    if (Math.abs(lx) <= 0.5 + rx &&
                        Math.abs(ly) <= 0.5 + ry &&
                        Math.abs(lz) <= 0.5 + rz) {
                        activeSlider = sl;
                        console.log(`[ourmenu/slider] BEGIN drag: ${sl.label}`);
                        // Apply the first drag frame so the knob jumps to the
                        // pointer immediately instead of waiting one tick.
                        const t = Math.max(0, Math.min(1, lx + 0.5));
                        sl.onDrag(t);
                        return;
                    }
                } catch (_) {}
            }
        }

        if (now - lastClickTime < CLICK_DEBOUNCE_S) return;
        try {
            for (const btn of menuButtons) {
                if (!btn || !btn.go || btn.go.isNull?.()) continue;
                try {
                    const localP = btn.tr.method("InverseTransformPoint", 1).invoke(pPos);
                    const lx = localP.field("x").value as number;
                    const ly = localP.field("y").value as number;
                    const lz = localP.field("z").value as number;
                    const W = btn.halfExtents[0] * 2 || 1e-6;
                    const H = btn.halfExtents[1] * 2 || 1e-6;
                    const D = btn.halfExtents[2] * 2 || 1e-6;
                    const rx = POINTER_RADIUS / W;
                    const ry = POINTER_RADIUS / H;
                    const rz = POINTER_RADIUS / D;
                    // Track nearest miss in local space (sum of axis distances)
                    const distSq = Math.max(0, Math.abs(lx) - 0.5) ** 2
                                 + Math.max(0, Math.abs(ly) - 0.5) ** 2
                                 + Math.max(0, Math.abs(lz) - 0.5) ** 2;
                    if (distSq < nearestDistSq) {
                        nearestDistSq = distSq;
                        nearestLabel = btn.label;
                    }
                    if (Math.abs(lx) <= 0.5 + rx &&
                        Math.abs(ly) <= 0.5 + ry &&
                        Math.abs(lz) <= 0.5 + rz) {
                        console.log(`[ourmenu/click] HIT: ${btn.label}`);
                        lastClickTime = now;
                        try { btn.onClick(); } catch (e) { console.error("[ourmenu] button onClick threw:", e); }
                        return;
                    }
                } catch (_) {}
            }
            // Every 2 seconds (~120 ticks at 60fps), log the closest button so we
            // can see if pointer is even in the ballpark.
            tickCount++;
            if (tickCount % 120 === 0 && nearestLabel) {
                console.log(`[ourmenu/click] nearest: "${nearestLabel}" (local dist ${Math.sqrt(nearestDistSq).toFixed(3)})`);
                nearestDistSq = Infinity;
                nearestLabel = "";
            }
        } catch (_) {}
    }

    // ----- Buttons ----------------------------------------------------
    // A button = colored panel + centered text label + registration in menuButtons
    // for the pointer-ball click system. onClick fires when the right-hand pointer
    // ball overlaps the button's world-space bounding box.
    function createButton(
        parent: any,
        localPos: [number, number, number],
        size: [number, number, number],
        label: string,
        color: [number, number, number, number],
        onClick: () => void,
        seeThrough: boolean = false,
    ): any {
        const btn = createPanel(parent, localPos, size, color, `Btn_${label}`);
        const txt = renderText(btn, label, [0, 0, 1.0], 0.030, COLOR.textPrimary, 514 /*MidCenter*/);
        if (seeThrough) {
            makeSeeThrough(btn, 4001);
            if (txt) makeTextSeeThrough(txt, 4002);
        }
        // Register for the pointer-ball overlap check. World half-extents are
        // approximated from world scale of the panel (set in createPanel above).
        try {
            const tr = getTransform(btn);
            menuButtons.push({
                go: btn,
                tr,
                halfExtents: [size[0] * 0.5, size[1] * 0.5, size[2] * 0.5],
                label,
                onClick,
            });
        } catch (_) {}
        return btn;
    }

    // Row of demo buttons under the main panels. Each onClick logs and could
    // later toggle features. Wiring real actions is just filling in onClick.
    // Tooltip panel to the LEFT of the main menu — shows last clicked mod's
    // description. Width-wraps long text by manually splitting on spaces.
    function buildTooltipPanel(parent: any) {
        const totalW = G.leftPanelW + G.gap + G.rightPanelW;
        const tooltipW = 0.16;
        const tooltipH = G.leftPanelH * 0.7;
        const tooltipX = -(totalW / 2) - 0.012 - tooltipW / 2;   // left of main panels

        const panel = createPanel(
            parent,
            [tooltipX, 0, 0],
            [tooltipW, tooltipH, G.panelDepth],
            COLOR.infoBg,
            "TooltipPanel",
        );

        if (!currentTooltipLabel) {
            renderText(panel, "tap a mod →", [0, 0, 1.0], 0.022, COLOR.textSecondary, 514);
            return;
        }
        // Header: mod label.
        renderText(panel, currentTooltipLabel, [0, 0.38, 1.0], 0.030, COLOR.foldoutArrow, 514);

        // Body: tooltip text, word-wrapped manually.
        const txt = OP_TOOLTIPS[currentTooltipLabel] || "(no description)";
        const words = txt.split(" ");
        const maxLineChars = 22; // rough chars-per-line that fits the panel width
        const lines: string[] = [];
        let cur = "";
        for (const w of words) {
            if ((cur + " " + w).trim().length > maxLineChars) {
                if (cur) lines.push(cur);
                cur = w;
            } else {
                cur = (cur ? cur + " " : "") + w;
            }
        }
        if (cur) lines.push(cur);
        const lineSpacing = 0.07;
        const startY = 0.22;
        for (let i = 0; i < Math.min(lines.length, 9); i++) {
            renderText(
                panel,
                lines[i],
                [0, startY - i * lineSpacing, 1.0],
                0.020,
                COLOR.textPrimary,
                514,
            );
        }
    }

    // ===== ITEM PICKER PANEL (renders only on Items tab) =====
    // Secondary panel to the LEFT of the main menu. Stacked layout:
    //   1. Header — current item name + position (n/total)
    //   2. 6 item rows — alphabetical, clickable to select
    //   3. Big draggable scroll slider — settings-tab-style horizontal slider
    //   4. SPAWN button — drops the current item in front of right hand
    //   5. Size slider — set_scaleModifier (-128..127)
    //   6. Hue slider — set_colorHue (-127..127)
    //   7. Sat slider — set_colorSaturation (-20..127)
    //
    // Sliders match the FireRate slider pattern in buildSettingsView exactly:
    // hit-zone panel + thin track + draggable knob, registered with menuSliders
    // so the pointer-ball drag system picks them up.
    interface SortedItem { originalIndex: number; displayName: string; fullId: string; }
    let _sortedItemsCache: SortedItem[] | null = null;
    let itemScrollOffset = 0;
    const ITEMS_PANEL_VISIBLE_ROWS = 10;
    // Letter filter: "" = show all, "a".."z" = only items whose displayName
    // starts with that letter. Tap a letter button to filter, tap "All" to clear.
    let itemFilterPrefix = "";
    // Search bar + on-screen keyboard. searchQuery is a substring match used by
    // both the Items and Prefabs pickers. searchKeyboardOpen toggles whether the
    // keyboard renders below the menu. Tap the search bar at the bottom of the
    // menu to toggle. Both states persist across rebuilds.
    let searchQuery = "";
    let searchKeyboardOpen = false;
    // Spawn modifiers (M4 da.ts:610-611 + scaleModifier). Applied to every
    // SPAWN button press via set_scaleModifier / set_colorHue / set_colorSaturation
    // on the spawned GBO component.
    let spawnScaleModifier = 0;   // range -128..127
    let spawnColorHue       = 0;   // range -127..127
    let spawnColorSaturation = 0;  // range  -20..127

    function getSortedItems(): SortedItem[] {
        if (_sortedItemsCache !== null) return _sortedItemsCache;
        const list: SortedItem[] = itemIDs.map((id, i) => ({
            originalIndex: i,
            displayName: id.replace(/^item_/, "").replace(/_/g, " "),
            fullId: id,
        }));
        list.sort((a, b) => a.displayName.localeCompare(b.displayName));
        _sortedItemsCache = list;
        return list;
    }

    // M4-style spawn: drop the currently selected item ~0.4m in front of the
    // right hand, then apply scaleModifier/hue/saturation to the spawned GBO.
    // First call dumps result.class + GBO schema so we can see exactly what
    // class came back and which methods/fields are actually on it.
    let _spawnDiagnosed = false;
    function spawnSelectedItemNow(): void {
        try {
            refreshLocalPlayerRefs();
            if (!rightHandTf) {
                console.error("[ourmenu/items] SPAWN failed: right hand transform unavailable");
                return;
            }
            const itemId = itemIDs[itemIndex % itemIDs.length];
            const hp = rightHandTf.method("get_position").invoke();
            const fwd = readVec3Components(rightHandTf.method("get_forward").invoke());
            const spawnPos: [number, number, number] = [
                (hp.field("x").value as number) + fwd[0] * 0.4,
                (hp.field("y").value as number) + fwd[1] * 0.4,
                (hp.field("z").value as number) + fwd[2] * 0.4,
            ];
            const idQ = getIdentityQuat();
            const result = spawnItemAtPos(itemId, spawnPos, idQ);
            if (!result || result.isNull?.()) {
                console.error(`[ourmenu/items] SPAWN '${itemId}' returned null`);
                return;
            }
            const verbose = !_spawnDiagnosed;

            // ===== FIRST-SPAWN DIAGNOSTIC (one-shot) =====
            // Dumps result.class + GBO class so we know exactly what types we
            // got back. Tells us if set_scaleModifier even exists on this build.
            if (verbose) {
                console.log("==================================================");
                console.log(`[ourmenu/items] FIRST-SPAWN DIAGNOSTIC for '${itemId}'`);
                console.log("==================================================");
                try {
                    console.log(`[ourmenu/items]   result.class.type.name = ${result.class.type.name}`);
                } catch (e) {
                    console.error(`[ourmenu/items]   reading result.class FAILED: ${e}`);
                }
            }

            if (!GBOClass_M4) {
                console.warn("[ourmenu/items] GBOClass_M4 not resolved — retrying resolveM4Refs()...");
                try { resolveM4Refs(); } catch (_) {}
            }
            if (!GBOClass_M4) {
                console.error("[ourmenu/items] GBOClass_M4 STILL not resolved — cannot apply modifiers");
                _spawnDiagnosed = true;
                return;
            }

            // ===== Find the GBO — try every reasonable path =====
            let gbo: any = null;
            let gboFoundVia = "(none)";
            // Path A: GetComponent on result directly (M4 pattern).
            try {
                const g = result.method("GetComponent", 1).inflate(GBOClass_M4).invoke();
                if (g && !g.isNull?.()) { gbo = g; gboFoundVia = "result.GetComponent<GBO>"; }
            } catch (e) { if (verbose) console.log(`[ourmenu/items]   path A (result.GetComponent) threw: ${e}`); }
            // Path B: via gameObject.
            if (!gbo) {
                try {
                    const go = result.method("get_gameObject").invoke();
                    const g = go.method("GetComponent", 1).inflate(GBOClass_M4).invoke();
                    if (g && !g.isNull?.()) { gbo = g; gboFoundVia = "go.GetComponent<GBO>"; }
                } catch (e) { if (verbose) console.log(`[ourmenu/items]   path B (go.GetComponent) threw: ${e}`); }
            }
            // Path C: GetComponentInChildren — for cases where GBO is on a child GO.
            if (!gbo) {
                try {
                    const g = result.method("GetComponentInChildren", 1).inflate(GBOClass_M4).invoke();
                    if (g && !g.isNull?.()) { gbo = g; gboFoundVia = "result.GetComponentInChildren<GBO>"; }
                } catch (e) { if (verbose) console.log(`[ourmenu/items]   path C (GetComponentInChildren) threw: ${e}`); }
            }
            // Path D: gameObject.GetComponentInChildren.
            if (!gbo) {
                try {
                    const go = result.method("get_gameObject").invoke();
                    const g = go.method("GetComponentInChildren", 1).inflate(GBOClass_M4).invoke();
                    if (g && !g.isNull?.()) { gbo = g; gboFoundVia = "go.GetComponentInChildren<GBO>"; }
                } catch (e) { if (verbose) console.log(`[ourmenu/items]   path D (go.GetComponentInChildren) threw: ${e}`); }
            }

            if (!gbo) {
                console.error(`[ourmenu/items] All 4 GBO lookup paths failed for '${itemId}'. Modifiers skipped.`);
                if (verbose) console.log(`[ourmenu/items] (See 'result.class.type.name' above — hints at the actual class.)`);
                _spawnDiagnosed = true;
                return;
            }

            if (verbose) {
                console.log(`[ourmenu/items]   GBO found via: ${gboFoundVia}`);
                try {
                    console.log(`[ourmenu/items]   gbo.class.type.name = ${gbo.class.type.name}`);
                    const want = new Set(["set_scaleModifier", "set_colorHue", "set_colorSaturation"]);
                    const haveMethods: string[] = [];
                    const haveFields: string[] = [];
                    try { for (const m of (gbo.class.methods ?? [])) { try { if (want.has(m.name)) haveMethods.push(m.name); } catch (_) {} } } catch (_) {}
                    try { for (const f of (gbo.class.fields ?? [])) { try { if (f.name.includes("scale") || f.name.includes("color") || f.name.includes("hue") || f.name.includes("saturation")) haveFields.push(f.name); } catch (_) {} } } catch (_) {}
                    console.log(`[ourmenu/items]   wanted methods found: ${haveMethods.join(", ") || "NONE"}`);
                    console.log(`[ourmenu/items]   related fields: ${haveFields.join(", ") || "NONE"}`);
                } catch (e) {
                    console.error(`[ourmenu/items]   GBO introspection threw: ${e}`);
                }
            }

            // ===== Apply modifiers — loud per-attempt =====
            const sizeOK = (() => {
                try { gbo.method("set_scaleModifier").invoke(spawnScaleModifier); return true; }
                catch (e) {
                    // Fallback: direct field write.
                    try { gbo.field("_scaleModifier").value = spawnScaleModifier; return true; } catch (_) {}
                    try { gbo.field("scaleModifier").value = spawnScaleModifier; return true; } catch (_) {}
                    console.error(`[ourmenu/items] set_scaleModifier(${spawnScaleModifier}) threw + field fallbacks failed: ${e}`); return false;
                }
            })();
            const hueOK = (() => {
                try { gbo.method("set_colorHue").invoke(spawnColorHue); return true; }
                catch (e) {
                    try { gbo.field("_colorHue").value = spawnColorHue; return true; } catch (_) {}
                    try { gbo.field("colorHue").value = spawnColorHue; return true; } catch (_) {}
                    console.error(`[ourmenu/items] set_colorHue(${spawnColorHue}) threw + field fallbacks failed: ${e}`); return false;
                }
            })();
            const satOK = (() => {
                try { gbo.method("set_colorSaturation").invoke(spawnColorSaturation); return true; }
                catch (e) {
                    try { gbo.field("_colorSaturation").value = spawnColorSaturation; return true; } catch (_) {}
                    try { gbo.field("colorSaturation").value = spawnColorSaturation; return true; } catch (_) {}
                    console.error(`[ourmenu/items] set_colorSaturation(${spawnColorSaturation}) threw + field fallbacks failed: ${e}`); return false;
                }
            })();

            console.log(`[ourmenu/items] Spawned '${itemId}' size=${spawnScaleModifier}(${sizeOK ? "OK" : "FAIL"}) hue=${spawnColorHue}(${hueOK ? "OK" : "FAIL"}) sat=${spawnColorSaturation}(${satOK ? "OK" : "FAIL"})`);
            if (verbose) {
                console.log("==================================================");
                console.log("[ourmenu/items] DIAGNOSTIC DONE — subsequent spawns will be quiet.");
                console.log("==================================================");
            }
            _spawnDiagnosed = true;
        } catch (e) {
            console.error("[ourmenu/items] SPAWN threw:", e);
        }
    }

    // Helper: register a generic horizontal slider.
    // ONE visible bar (combined hit zone + track) + ONE movable knob.
    // The single visible bar avoids the "looks like there are 2 sliders" bug
    // from the previous version where hit zone + track were separate panels.
    function buildHorizontalSlider(
        parent: any,
        label: string,
        centerX: number,
        centerY: number,
        sliderW: number,
        rowH: number,
        currentT: number,            // 0..1 initial knob position
        onDragT: (t: number) => void,
        onCommitT: (t: number) => void,
    ): void {
        const sliderZ = -G.panelDepth * 0.55;
        const knobZ = -G.panelDepth * 0.60;
        const barH = rowH * 0.55;                  // chunkier so it's grabbable
        const knobVisualH = rowH * 0.85;
        const knobVisualW = Math.max(0.008, sliderW * 0.06);
        const trackLeftEdgeX = centerX - sliderW / 2;
        // Combined hit zone + visible bar (one panel, no overlap).
        const barGo = createPanel(
            parent,
            [centerX, centerY, sliderZ],
            [sliderW, barH, G.panelDepth * 0.5],
            COLOR.panelStripe,
            `${label}_Bar`,
        );
        const barTr = getTransform(barGo);
        // Knob (movable marker).
        const knobX = trackLeftEdgeX + sliderW * Math.max(0, Math.min(1, currentT));
        const knobGo = createPanel(
            parent,
            [knobX, centerY, knobZ],
            [knobVisualW, knobVisualH, G.panelDepth * 0.5],
            COLOR.tabActive,
            `${label}_Knob`,
        );
        const knobTr = getTransform(knobGo);
        menuSliders.push({
            label,
            hitTr: barTr,
            hitHalfExtents: [sliderW * 0.5, barH * 0.5, (G.panelDepth * 0.5) * 0.5],
            onDrag: (t: number) => {
                const liveX = trackLeftEdgeX + sliderW * t;
                try { knobTr.method("set_localPosition").invoke([liveX, centerY, knobZ]); } catch (_) {}
                onDragT(t);
            },
            onCommit: (t: number) => {
                onCommitT(t);
                rebuildMenu();
            },
        });
    }

    function buildItemListPanel(parent: any): void {
        // Only render on the Items tab — keeps the picker out of the way on
        // every other view.
        // Layout: header + search-bar row + item rows + scrollbar.
        if (currentLeftView !== "Items") return;

        // Get full sorted list, then apply substring search filter.
        // searchQuery is shared with the Prefabs panel and driven by the
        // on-screen keyboard at the bottom of the menu.
        const allSorted = getSortedItems();
        const q = searchQuery.toLowerCase();
        const filtered = q === ""
            ? allSorted
            : allSorted.filter(s => s.displayName.toLowerCase().includes(q));

        const totalW = G.leftPanelW + G.gap + G.rightPanelW;
        const listW = 0.185;
        const listH = G.leftPanelH;
        const listX = -(totalW / 2) - 0.012 - listW / 2;   // left of the main menu

        // Clamp scroll offset against the FILTERED list size.
        const maxOffset = Math.max(0, filtered.length - ITEMS_PANEL_VISIBLE_ROWS);
        if (itemScrollOffset > maxOffset) itemScrollOffset = maxOffset;
        if (itemScrollOffset < 0) itemScrollOffset = 0;

        createPanel(
            parent,
            [listX, 0, 0],
            [listW, listH, G.panelDepth],
            COLOR.panelBg,
            "ItemListPanel",
        );

        // Vertical layout.
        const sidePad = 0.004;
        const topY = listH / 2 - 0.004;
        const botY = -listH / 2 + 0.004;
        const rowGap = 0.003;
        const headerH = 0.020;
        const searchRowH = 0.020;
        const scrollH = 0.028;

        // 1. Header
        const headerY = topY - headerH / 2;
        const currentItem = allSorted.find(s => s.originalIndex === itemIndex);
        const currentName = currentItem ? currentItem.displayName : `item #${itemIndex}`;
        const headerW = listW - 2 * sidePad;
        createButton(
            parent,
            [listX, headerY, -G.panelDepth * 0.55],
            [headerW, headerH, G.panelDepth * 0.5],
            `${currentName} (${filtered.length}/${allSorted.length})`,
            COLOR.panelStripe,
            () => {},
        );

        // 2. Search bar row — clicking the field opens the keyboard at the
        //    bottom of the menu. Backspace + clear inline.
        const searchRowY = headerY - headerH / 2 - 0.003 - searchRowH / 2;
        const searchRowWidth = listW - 2 * sidePad;
        const sGap = 0.003;
        const fieldW = searchRowWidth * 0.66;
        const smallW = (searchRowWidth - fieldW - 2 * sGap) / 2;
        const fieldX = listX - searchRowWidth / 2 + fieldW / 2;
        const bspX   = fieldX + fieldW / 2 + sGap + smallW / 2;
        const clrX   = bspX  + smallW + sGap;
        const fieldLabel = searchQuery !== ""
            ? `🔍 ${searchQuery}`
            : (searchKeyboardOpen ? "type..." : "search…");
        const fieldColor = searchKeyboardOpen ? COLOR.tabActive : COLOR.tabBg;
        createButton(
            parent,
            [fieldX, searchRowY, -G.panelDepth * 0.55],
            [fieldW, searchRowH, G.panelDepth * 0.5],
            fieldLabel, fieldColor,
            () => {
                searchKeyboardOpen = !searchKeyboardOpen;
                rebuildMenu();
            },
        );
        createButton(
            parent,
            [bspX, searchRowY, -G.panelDepth * 0.55],
            [smallW, searchRowH, G.panelDepth * 0.5],
            "<", COLOR.tabBg,
            () => {
                if (searchQuery.length > 0) {
                    searchQuery = searchQuery.slice(0, -1);
                    itemScrollOffset = 0;
                    rebuildMenu();
                }
            },
        );
        createButton(
            parent,
            [clrX, searchRowY, -G.panelDepth * 0.55],
            [smallW, searchRowH, G.panelDepth * 0.5],
            "Clr", COLOR.tabBg,
            () => {
                searchQuery = "";
                itemScrollOffset = 0;
                rebuildMenu();
            },
        );
        const filterRowsBot = searchRowY - searchRowH / 2;

        // 3. Scrollbar at the bottom.
        const scrollY = botY + scrollH / 2;
        const scrollW = listW - 2 * sidePad;
        const scrollRange = Math.max(1, filtered.length - ITEMS_PANEL_VISIBLE_ROWS);
        const currentScrollT = itemScrollOffset / scrollRange;
        buildHorizontalSlider(
            parent,
            "ItemScroll",
            listX,
            scrollY,
            scrollW,
            scrollH,
            Math.max(0, Math.min(1, currentScrollT)),
            (t) => {
                itemScrollOffset = Math.round(t * scrollRange);
            },
            (t) => {
                itemScrollOffset = Math.round(t * scrollRange);
                if (itemScrollOffset > maxOffset) itemScrollOffset = maxOffset;
                if (itemScrollOffset < 0) itemScrollOffset = 0;
            },
        );

        // 4. Item rows fill space between filter rows and scrollbar.
        const rowsTop = filterRowsBot - 0.003;
        const rowsBot = scrollY + scrollH / 2 + 0.004;
        const rowsH = rowsTop - rowsBot;
        const rowH = (rowsH - (ITEMS_PANEL_VISIBLE_ROWS - 1) * rowGap) / ITEMS_PANEL_VISIBLE_ROWS;
        const rowW = listW - 2 * sidePad;

        if (filtered.length === 0) {
            // Show a "no matches" notice.
            const midY = (rowsTop + rowsBot) / 2;
            const notice = createPanel(
                parent,
                [listX, midY, -G.panelDepth * 0.6],
                [rowW, 0.04, G.panelDepth * 0.4],
                COLOR.panelBg,
                "NoItemsNotice",
            );
            renderText(notice, `no items match "${searchQuery}"`, [0, 0, 1.0], 0.018, COLOR.textSecondary, 514);
        } else {
            for (let r = 0; r < ITEMS_PANEL_VISIBLE_ROWS; r++) {
                const idx = itemScrollOffset + r;
                if (idx >= filtered.length) break;
                const item = filtered[idx];
                const rowY = rowsTop - r * (rowH + rowGap) - rowH / 2;
                const isCurrent = item.originalIndex === itemIndex;
                const color = isCurrent ? COLOR.tabActive : COLOR.tabBg;
                createButton(
                    parent,
                    [listX, rowY, -G.panelDepth * 0.55],
                    [rowW, rowH * 0.95, G.panelDepth * 0.5],
                    item.displayName,
                    color,
                    () => {
                        itemIndex = item.originalIndex;
                        console.log(`[ourmenu/items] Selected: ${item.fullId}`);
                        rebuildMenu();
                    },
                );
            }
        }
    }

    // ===== ITEMS MAIN VIEW (replaces placeholder when currentLeftView === "Items") =====
    // Lives in the main center panel. Shows:
    //   - Big SPAWN button (drops current item in front of right hand)
    //   - 3 sliders for Size / Hue / Sat that apply to every spawn
    //   - Back-to-Exploits nav at the bottom
    // Pairs with the side picker on the left — pick item there, spawn here.
    function buildItemsView(parent: any, leftX: number) {
        const usableTop = (G.leftPanelH / 2) - G.tabBarH - G.headerPad;
        const usableBot = -(G.leftPanelH / 2) + G.headerPad;
        const btnInset = 0.006;
        const btnW = G.leftPanelW - 2 * btnInset;

        // Resolve display name of current item.
        const sorted = getSortedItems();
        const curr = sorted.find(s => s.originalIndex === itemIndex);
        const currName = curr ? curr.displayName : `item #${itemIndex}`;

        // TIGHT layout — must fit in usable height (~0.191m).
        // header(.022) + gap + SPAWN(.038) + gap + 3 sliders(.024 each) + gaps + nav(.020) = ~0.181m
        const headerH = 0.022;
        const spawnH = 0.038;
        const sliderRowH = 0.024;
        const navH = 0.020;
        const rowGap = 0.004;

        let y = usableTop;
        // Header
        const headerY = y - headerH / 2;
        y -= headerH + rowGap;
        createButton(
            parent,
            [leftX, headerY, -G.panelDepth * 0.55],
            [btnW, headerH, G.panelDepth * 0.5],
            `— ${currName} —`,
            COLOR.panelStripe,
            () => {},
        );

        // SPAWN row — 3 buttons:  [ SPAWN currName ]  [ x5 ]  [ x20 ]
        // Single row keeps the vertical space free for the 3 sliders below.
        const spawnY = y - spawnH / 2;
        y -= spawnH + rowGap * 2;
        const spawnGap = 0.003;
        const bulkBtnW = btnW * 0.16;                                // each bulk button
        const mainSpawnW = btnW - 2 * (bulkBtnW + spawnGap);          // SPAWN takes what's left
        const mainSpawnX = leftX - btnW / 2 + mainSpawnW / 2;
        const x5X       = mainSpawnX + mainSpawnW / 2 + spawnGap + bulkBtnW / 2;
        const x20X      = x5X + bulkBtnW + spawnGap;
        // Main SPAWN — wide accent button.
        createButton(
            parent,
            [mainSpawnX, spawnY, -G.panelDepth * 0.55],
            [mainSpawnW, spawnH, G.panelDepth * 0.5],
            `SPAWN  ${currName}`,
            COLOR.accent,
            () => { spawnSelectedItemNow(); },
        );
        // Spawn x5 — quick burst.
        createButton(
            parent,
            [x5X, spawnY, -G.panelDepth * 0.55],
            [bulkBtnW, spawnH, G.panelDepth * 0.5],
            "x5",
            COLOR.tabActive,
            () => {
                for (let i = 0; i < 5; i++) spawnSelectedItemNow();
            },
        );
        // Spawn x20 — pile drop.
        createButton(
            parent,
            [x20X, spawnY, -G.panelDepth * 0.55],
            [bulkBtnW, spawnH, G.panelDepth * 0.5],
            "x20",
            COLOR.tabActive,
            () => {
                for (let i = 0; i < 20; i++) spawnSelectedItemNow();
            },
        );

        // 3 slider rows
        const sliderConfigs: {
            label: string;
            value: number;
            min: number;
            max: number;
            apply: (v: number) => void;
        }[] = [
            { label: "Size", value: spawnScaleModifier,   min: -128, max: 127, apply: (v) => { spawnScaleModifier = v; } },
            { label: "Hue",  value: spawnColorHue,        min: -127, max: 127, apply: (v) => { spawnColorHue = v; } },
            { label: "Sat",  value: spawnColorSaturation, min: -20,  max: 127, apply: (v) => { spawnColorSaturation = v; } },
        ];
        for (const sc of sliderConfigs) {
            const rowY = y - sliderRowH / 2;
            y -= sliderRowH + rowGap;
            // Label panel takes the left 30% of the row.
            const labelW = btnW * 0.30;
            const labelX = leftX - btnW / 2 + labelW / 2;
            const sliderW = btnW - labelW - 0.006;
            const sliderCenterX = labelX + labelW / 2 + 0.006 + sliderW / 2;
            createButton(
                parent,
                [labelX, rowY, -G.panelDepth * 0.55],
                [labelW, sliderRowH * 0.95, G.panelDepth * 0.5],
                `${sc.label}:${sc.value}`,
                COLOR.tabBg,
                () => {},
            );
            const range = sc.max - sc.min;
            const currentT = (sc.value - sc.min) / Math.max(1, range);
            buildHorizontalSlider(
                parent,
                `Items_${sc.label}`,
                sliderCenterX,
                rowY,
                sliderW,
                sliderRowH,
                Math.max(0, Math.min(1, currentT)),
                (t) => {
                    const v = Math.round(sc.min + t * range);
                    sc.apply(v);
                },
                (t) => {
                    const v = Math.round(sc.min + t * range);
                    sc.apply(v);
                    console.log(`[ourmenu/items] ${sc.label} → ${v}`);
                },
            );
        }

        // Back-to-Exploits nav at the very bottom.
        const navY = usableBot + navH / 2;
        createButton(
            parent,
            [leftX, navY, -G.panelDepth * 0.55],
            [btnW * 0.6, navH, G.panelDepth * 0.5],
            "< Back to Exploits",
            COLOR.tabActive,
            () => { currentLeftView = "op"; rebuildMenu(); },
        );
    }

    // ===== PREFAB PICKER PANEL (renders only on Prefabs tab) =====
    // Same layout pattern as the item picker but without the letter filter
    // (only ~22 prefabs, fits in a couple of scroll positions).
    interface SortedPrefab { originalIndex: number; displayName: string; fullId: string; }
    let _sortedPrefabsCache: SortedPrefab[] | null = null;
    let prefabScrollOffset = 0;
    const PREFABS_PANEL_VISIBLE_ROWS = 12;
    // Tracks per-prefab spawn result so the picker can color-code buttons.
    // Updated after each spawn attempt. "ok" if SpawnItem returned non-null,
    // "failed" if it returned null or threw. Lets the user discover which
    // prefabs actually work in this AC build without me having to guess.
    const prefabSpawnResults = new Map<string, "ok" | "failed">();

    function getSortedPrefabs(): SortedPrefab[] {
        if (_sortedPrefabsCache !== null) return _sortedPrefabsCache;
        const list: SortedPrefab[] = prefabIDs.map((id, i) => ({
            originalIndex: i,
            displayName: id.replace(/_/g, " "),
            fullId: id,
        }));
        list.sort((a, b) => a.displayName.localeCompare(b.displayName));
        _sortedPrefabsCache = list;
        return list;
    }

    let _prefabSpawnDiagnosed = false;
    function spawnSelectedPrefabNow(): void {
        try {
            refreshLocalPlayerRefs();
            if (!rightHandTf) {
                console.error("[ourmenu/prefabs] SPAWN failed: right hand transform unavailable");
                return;
            }
            const prefabName = prefabIDs[prefabIndex % prefabIDs.length];
            const hp = rightHandTf.method("get_position").invoke();
            const fwd = readVec3Components(rightHandTf.method("get_forward").invoke());
            // Spawn ~0.6m forward so vehicles/large props don't clip the player.
            const spawnPos: [number, number, number] = [
                (hp.field("x").value as number) + fwd[0] * 0.6,
                (hp.field("y").value as number) + fwd[1] * 0.6,
                (hp.field("z").value as number) + fwd[2] * 0.6,
            ];
            const idQ = getIdentityQuat();
            let result: any = null;
            let threw = false;
            try { result = spawnNetworkPrefab(prefabName, spawnPos, idQ); }
            catch (e) { threw = true; console.error(`[ourmenu/prefabs] SPAWN '${prefabName}' threw: ${e}`); }
            const ok = !!(result && !result.isNull?.()) && !threw;
            // Record result so the picker can color-code the row.
            prefabSpawnResults.set(prefabName, ok ? "ok" : "failed");
            console.log(`[ourmenu/prefabs] Spawned '${prefabName}' ${ok ? "OK" : "FAILED (returned null — prefab name may be wrong or not in PrefabTable)"}`);
            if (!_prefabSpawnDiagnosed && ok) {
                try { console.log(`[ourmenu/prefabs]   result.class.type.name = ${result.class.type.name}`); } catch (_) {}
                _prefabSpawnDiagnosed = true;
            }
        } catch (e) {
            console.error("[ourmenu/prefabs] SPAWN threw:", e);
        }
    }

    function buildPrefabListPanel(parent: any): void {
        // Only render on the Prefabs tab.
        if (currentLeftView !== "Prefabs") return;

        const allSorted = getSortedPrefabs();
        // Substring search filter, shared with the Items panel.
        const q = searchQuery.toLowerCase();
        const sorted = q === ""
            ? allSorted
            : allSorted.filter(s => s.displayName.toLowerCase().includes(q));
        const totalW = G.leftPanelW + G.gap + G.rightPanelW;
        const listW = 0.185;
        const listH = G.leftPanelH;
        const listX = -(totalW / 2) - 0.012 - listW / 2;

        const maxOffset = Math.max(0, sorted.length - PREFABS_PANEL_VISIBLE_ROWS);
        if (prefabScrollOffset > maxOffset) prefabScrollOffset = maxOffset;
        if (prefabScrollOffset < 0) prefabScrollOffset = 0;

        createPanel(
            parent,
            [listX, 0, 0],
            [listW, listH, G.panelDepth],
            COLOR.panelBg,
            "PrefabListPanel",
        );

        const sidePad = 0.004;
        const topY = listH / 2 - 0.004;
        const botY = -listH / 2 + 0.004;
        const rowGap = 0.003;
        const headerH = 0.022;
        const searchRowH = 0.020;
        const scrollH = 0.028;

        // 1. Header — shows current selection + live spawn-result counts.
        const headerY = topY - headerH / 2;
        const currentPrefab = allSorted.find(s => s.originalIndex === prefabIndex);
        const currentName = currentPrefab ? currentPrefab.displayName : `prefab #${prefabIndex}`;
        let okCount = 0, failCount = 0;
        for (const v of prefabSpawnResults.values()) {
            if (v === "ok") okCount++;
            else if (v === "failed") failCount++;
        }
        const headerW = listW - 2 * sidePad;
        createButton(
            parent,
            [listX, headerY, -G.panelDepth * 0.55],
            [headerW, headerH, G.panelDepth * 0.5],
            `${currentName}  ✓${okCount} ✗${failCount}`,
            COLOR.panelStripe,
            () => {},
        );

        // 2. Search bar row (same pattern as Items panel).
        const searchRowY = headerY - headerH / 2 - 0.003 - searchRowH / 2;
        const searchRowWidth = listW - 2 * sidePad;
        const sGap = 0.003;
        const fieldW = searchRowWidth * 0.66;
        const smallW = (searchRowWidth - fieldW - 2 * sGap) / 2;
        const fieldX = listX - searchRowWidth / 2 + fieldW / 2;
        const bspX   = fieldX + fieldW / 2 + sGap + smallW / 2;
        const clrX   = bspX  + smallW + sGap;
        const fieldLabel = searchQuery !== ""
            ? `🔍 ${searchQuery}`
            : (searchKeyboardOpen ? "type..." : "search…");
        const fieldColor = searchKeyboardOpen ? COLOR.tabActive : COLOR.tabBg;
        createButton(
            parent,
            [fieldX, searchRowY, -G.panelDepth * 0.55],
            [fieldW, searchRowH, G.panelDepth * 0.5],
            fieldLabel, fieldColor,
            () => { searchKeyboardOpen = !searchKeyboardOpen; rebuildMenu(); },
        );
        createButton(
            parent,
            [bspX, searchRowY, -G.panelDepth * 0.55],
            [smallW, searchRowH, G.panelDepth * 0.5],
            "<", COLOR.tabBg,
            () => {
                if (searchQuery.length > 0) {
                    searchQuery = searchQuery.slice(0, -1);
                    prefabScrollOffset = 0;
                    rebuildMenu();
                }
            },
        );
        createButton(
            parent,
            [clrX, searchRowY, -G.panelDepth * 0.55],
            [smallW, searchRowH, G.panelDepth * 0.5],
            "Clr", COLOR.tabBg,
            () => {
                searchQuery = "";
                prefabScrollOffset = 0;
                rebuildMenu();
            },
        );

        // 2. Scrollbar at the bottom.
        const scrollY = botY + scrollH / 2;
        const scrollW = listW - 2 * sidePad;
        const scrollRange = Math.max(1, sorted.length - PREFABS_PANEL_VISIBLE_ROWS);
        const currentScrollT = prefabScrollOffset / scrollRange;
        buildHorizontalSlider(
            parent,
            "PrefabScroll",
            listX,
            scrollY,
            scrollW,
            scrollH,
            Math.max(0, Math.min(1, currentScrollT)),
            (t) => { prefabScrollOffset = Math.round(t * scrollRange); },
            (t) => {
                prefabScrollOffset = Math.round(t * scrollRange);
                if (prefabScrollOffset > maxOffset) prefabScrollOffset = maxOffset;
                if (prefabScrollOffset < 0) prefabScrollOffset = 0;
            },
        );

        // 3. Prefab rows — start below the search bar row.
        const rowsTop = searchRowY - searchRowH / 2 - 0.003;
        const rowsBot = scrollY + scrollH / 2 + 0.004;
        const rowsH = rowsTop - rowsBot;
        const rowH = (rowsH - (PREFABS_PANEL_VISIBLE_ROWS - 1) * rowGap) / PREFABS_PANEL_VISIBLE_ROWS;
        const rowW = listW - 2 * sidePad;

        for (let r = 0; r < PREFABS_PANEL_VISIBLE_ROWS; r++) {
            const idx = prefabScrollOffset + r;
            if (idx >= sorted.length) break;
            const p = sorted[idx];
            const rowY = rowsTop - r * (rowH + rowGap) - rowH / 2;
            const isCurrent = p.originalIndex === prefabIndex;
            const status = prefabSpawnResults.get(p.fullId);   // "ok" | "failed" | undefined
            // Color-code by spawn result:
            //   currently selected → bright accent (overrides everything)
            //   worked previously → muted purple (tabActive)
            //   failed previously → very dark (panelStripe)
            //   untried → default panel button (tabBg)
            let color: [number, number, number, number];
            if (isCurrent) color = COLOR.accent;
            else if (status === "ok") color = COLOR.tabActive;
            else if (status === "failed") color = COLOR.panelStripe;
            else color = COLOR.tabBg;
            // Prefix display with a small status glyph for extra clarity.
            let prefix = "  ";
            if (status === "ok") prefix = "✓ ";
            else if (status === "failed") prefix = "✗ ";
            createButton(
                parent,
                [listX, rowY, -G.panelDepth * 0.55],
                [rowW, rowH * 0.95, G.panelDepth * 0.5],
                prefix + p.displayName,
                color,
                () => {
                    prefabIndex = p.originalIndex;
                    console.log(`[ourmenu/prefabs] Selected: ${p.fullId}`);
                    rebuildMenu();
                },
            );
        }
    }

    // ===== PREFABS MAIN VIEW (replaces placeholder when currentLeftView === "Prefabs") =====
    // Big SPAWN button + "Spawn 5" multi-shot button + back nav.
    // Pairs with the side picker on the left — pick prefab there, spawn here.
    function buildPrefabsView(parent: any, leftX: number) {
        const usableTop = (G.leftPanelH / 2) - G.tabBarH - G.headerPad;
        const usableBot = -(G.leftPanelH / 2) + G.headerPad;
        const btnInset = 0.006;
        const btnW = G.leftPanelW - 2 * btnInset;

        const sorted = getSortedPrefabs();
        const curr = sorted.find(s => s.originalIndex === prefabIndex);
        const currName = curr ? curr.displayName : `prefab #${prefabIndex}`;

        const headerH = 0.022;
        const spawnH = 0.050;
        const spawn5H = 0.030;
        const navH = 0.020;
        const rowGap = 0.005;

        let y = usableTop;
        // Header
        const headerY = y - headerH / 2;
        y -= headerH + rowGap;
        createButton(
            parent,
            [leftX, headerY, -G.panelDepth * 0.55],
            [btnW, headerH, G.panelDepth * 0.5],
            `— ${currName} —`,
            COLOR.panelStripe,
            () => {},
        );

        // SPAWN button — big and obvious.
        const spawnY = y - spawnH / 2;
        y -= spawnH + rowGap;
        createButton(
            parent,
            [leftX, spawnY, -G.panelDepth * 0.55],
            [btnW, spawnH, G.panelDepth * 0.5],
            `SPAWN  ${currName}`,
            COLOR.accent,
            () => { spawnSelectedPrefabNow(); },
        );

        // Spawn x5 — quick way to drop multiple (useful for RPGRocket, Landmine etc).
        const spawn5Y = y - spawn5H / 2;
        y -= spawn5H + rowGap;
        createButton(
            parent,
            [leftX, spawn5Y, -G.panelDepth * 0.55],
            [btnW * 0.8, spawn5H, G.panelDepth * 0.5],
            `Spawn x5`,
            COLOR.tabBg,
            () => {
                for (let i = 0; i < 5; i++) spawnSelectedPrefabNow();
            },
        );

        // Spawn x20 — for crowd-drop testing.
        const spawn20Y = y - spawn5H / 2;
        y -= spawn5H + rowGap;
        createButton(
            parent,
            [leftX, spawn20Y, -G.panelDepth * 0.55],
            [btnW * 0.8, spawn5H, G.panelDepth * 0.5],
            `Spawn x20`,
            COLOR.tabBg,
            () => {
                for (let i = 0; i < 20; i++) spawnSelectedPrefabNow();
            },
        );

        // Clear spawn results — wipes the per-prefab status map so all
        // entries go back to "untried" coloring. Useful if AC state changed
        // (e.g. you reconnected) and old failures don't apply anymore.
        const clearY = y - spawn5H / 2;
        y -= spawn5H + rowGap;
        const clearedCount = prefabSpawnResults.size;
        createButton(
            parent,
            [leftX, clearY, -G.panelDepth * 0.55],
            [btnW * 0.8, spawn5H, G.panelDepth * 0.5],
            `Clear results (${clearedCount})`,
            COLOR.tabBg,
            () => {
                prefabSpawnResults.clear();
                console.log("[ourmenu/prefabs] cleared spawn-result tracking");
                rebuildMenu();
            },
        );

        // Back-to-Exploits nav at the bottom.
        const navY = usableBot + navH / 2;
        createButton(
            parent,
            [leftX, navY, -G.panelDepth * 0.55],
            [btnW * 0.6, navH, G.panelDepth * 0.5],
            "< Back to Exploits",
            COLOR.tabActive,
            () => { currentLeftView = "op"; rebuildMenu(); },
        );
    }

    function buildButtonRow(_parent: any) {
        // Reset/Close buttons removed per user request. The bottom-of-menu
        // space they used to occupy is now reserved for the on-screen keyboard
        // (see buildKeyboard, which only renders when searchKeyboardOpen).
        // To close the menu: press Y on left controller.
        // To clear toggles: untoggle them individually (or call resetAllMods()
        // from the Frida REPL if you really need a hard reset).
    }

    // ===== ON-SCREEN KEYBOARD (only renders when searchKeyboardOpen) =====
    // Sits below the menu's button row. 3 letter rows (QWERTY) + a space bar
    // wide row at the bottom. Each tap appends to `searchQuery` and rebuilds
    // the menu, so the filtered Items / Prefabs lists update live.
    function buildKeyboard(parent: any): void {
        if (!searchKeyboardOpen) return;
        const fullW = G.leftPanelW + G.gap + G.rightPanelW;
        const padX = 0.006;
        const rowW = fullW - 2 * padX;
        const keyH = 0.022;
        const rowGap = 0.003;
        const keyGap = 0.003;

        // Start just below the search-bar row.
        const buttonRowY = -(G.leftPanelH / 2) - G.tabBarH;
        const topY = buttonRowY - G.tabBarH / 2 - 0.006;

        // Tilt the keyboard up so it faces the user's downward gaze (like a
        // physical keyboard angled toward your chin). Pivot at the TOP edge so
        // the top row stays where it was and only the lower rows swing forward
        // toward you. Negative-X Euler rotates the bottom of the panel in front
        // of (closer to) the user.
        const KB_TILT_DEGREES = 25;
        const kbRoot = createEmpty("KeyboardRoot", parent);
        const kbTr = getTransform(kbRoot);
        try {
            kbTr.method("set_localPosition").invoke([0, topY, 0]);
            kbTr.method("set_localRotation").invoke(
                Quaternion.method("Euler").invoke(KB_TILT_DEGREES, 0.0, 0.0)
            );
            // Reset scale — createEmpty uses a Cube primitive which inherits scale,
            // and any non-1 scale on the parent would warp the keys.
            kbTr.method("set_localScale").invoke([1.0, 1.0, 1.0]);
        } catch (_) {}

        const rows: string[] = ["qwertyuiop", "asdfghjkl", "zxcvbnm"];

        // Backdrop panel so the keys don't float in mid-air. Spans the full
        // menu width and wraps all four key rows (3 letter rows + space row)
        // with a little padding. Content spans y ∈ [kbBottom, 0] in kbRoot
        // space, so center the backdrop at kbBottom/2. Z offset puts it fully
        // behind the keys (user faces the -Z side).
        const kbBottom = -(rows.length * (keyH + rowGap)) - keyH; // bottom edge of space row
        const padY = 0.006;
        const bg = createPanel(
            kbTr,
            [0, kbBottom / 2, 0.006],
            [fullW, -kbBottom + 2 * padY, 0.004],
            COLOR.panelBg,
            "KeyboardBg",
        );
        makeSeeThrough(bg, 4000); // behind keys (4001) and key labels (4002)

        for (let r = 0; r < rows.length; r++) {
            const row = rows[r];
            // Y coords are now relative to kbTr origin (which sits at topY of the
            // keyboard). Row 0 sits just below origin, row 1 below that, etc.
            const rowY = -(r * (keyH + rowGap)) - keyH / 2;
            const numKeys = row.length;
            const keyW = (rowW - (numKeys - 1) * keyGap) / numKeys;
            const startX = -rowW / 2 + keyW / 2;
            for (let c = 0; c < numKeys; c++) {
                const ch = row[c];
                const x = startX + c * (keyW + keyGap);
                createButton(kbTr, [x, rowY, 0], [keyW, keyH, G.panelDepth],
                    ch.toUpperCase(), COLOR.tabBg,
                    () => {
                        searchQuery += ch;
                        rebuildMenu();
                    },
                    /*seeThrough=*/true);
            }
        }
        // 4th row: clear | space bar (wide, centered) | backspace. The side
        // keys fill the gaps the centered space bar leaves on the bottom row,
        // mirroring the "<" / "clr" buttons up on the search bar so you don't
        // have to leave the keyboard to fix a typo.
        const spaceY = -(rows.length * (keyH + rowGap)) - keyH / 2;
        const spaceW = rowW * 0.55;
        const sideW = (rowW - spaceW) / 2 - keyGap;
        const sideX = spaceW / 2 + keyGap + sideW / 2;
        createButton(kbTr, [0, spaceY, 0], [spaceW, keyH, G.panelDepth],
            "Space", COLOR.tabBg,
            () => {
                searchQuery += " ";
                rebuildMenu();
            },
            /*seeThrough=*/true);
        createButton(kbTr, [-sideX, spaceY, 0], [sideW, keyH, G.panelDepth],
            "clr", COLOR.tabBg,
            () => {
                if (searchQuery !== "") {
                    searchQuery = "";
                    itemScrollOffset = 0;
                    rebuildMenu();
                }
            },
            /*seeThrough=*/true);
        createButton(kbTr, [sideX, spaceY, 0], [sideW, keyH, G.panelDepth],
            "<", COLOR.tabBg,
            () => {
                if (searchQuery.length > 0) {
                    searchQuery = searchQuery.slice(0, -1);
                    itemScrollOffset = 0;
                    rebuildMenu();
                }
            },
            /*seeThrough=*/true);
    }

    // ----- Tab bar (top row + main row spanning both panels) ---------
    function buildTabBar(parent: any) {
        const fullW = G.leftPanelW + G.gap + G.rightPanelW;
        const topY = (G.leftPanelH / 2) + G.tabBarH;

        // Top row: Settings, About
        const topRowY = topY + G.tabTopRowH + 0.005;
        const topTabW = 0.10;
        const topTabGap = 0.008;
        const topRowTotalW = tabsTop.length * topTabW + (tabsTop.length - 1) * topTabGap;
        const topStartX = -fullW / 2 + 0.005;

        for (let i = 0; i < tabsTop.length; i++) {
            const x = topStartX + i * (topTabW + topTabGap) + topTabW / 2;
            const label = tabsTop[i];
            const targetView: LeftView =
                label === "Settings" ? "settings" :
                "op";
            const isActive = (currentLeftView === targetView);
            createButton(
                parent,
                [x, topRowY, 0],
                [topTabW, G.tabTopRowH, G.panelDepth],
                label,
                isActive ? COLOR.tabActive : COLOR.tabBg,
                () => {
                    // Toggle: clicking the active top tab returns to OP list.
                    currentLeftView = isActive ? "op" : targetView;
                    console.log(`[ourmenu] view → ${currentLeftView}`);
                    rebuildMenu();
                },
            );
        }

        // Main row: Movement, Items, Prefabs, Sounds, Exploits, Player, Players, Misc.
        // Every label is now a real clickable button. Clicking switches the left
        // panel to that group's view (placeholder for now, except "Exploits"
        // which is the existing OP-mod list).
        const mainTabH = G.tabBarH;
        const mainTabGap = 0.006;
        const tabsCount = tabsMain.length;
        const mainTabW = (fullW - (tabsCount - 1) * mainTabGap) / tabsCount;
        const mainStartX = -fullW / 2 + mainTabW / 2;

        for (let i = 0; i < tabsCount; i++) {
            const x = mainStartX + i * (mainTabW + mainTabGap);
            const label = tabsMain[i];
            // "Exploits" is the OP list (currentLeftView === "op" is the legacy
            // alias for the same view, so highlight it for either name).
            // "Player" and "Players" are now SEPARATE tabs with their own
            // active state. "playerDetail" + "wlTools" both highlight under
            // "Players" because that's where they're reached from.
            const isExploits = (label === "Exploits");
            const isPlayersList = (label === "Players");
            const isPlayerSingular = (label === "Player");
            const targetView: LeftView = isExploits ? "op" : (label as LeftView);
            const isActive =
                isExploits        ? (currentLeftView === "op" || currentLeftView === "Exploits")
              : isPlayersList     ? (currentLeftView === "Players" || currentLeftView === "playerDetail" || currentLeftView === "wlTools")
              : isPlayerSingular  ? (currentLeftView === "Player")
              :                     (currentLeftView === label);
            createButton(
                parent,
                [x, topY, 0],
                [mainTabW, mainTabH, G.panelDepth],
                label,
                isActive ? COLOR.tabActive : COLOR.tabBg,
                () => {
                    currentLeftView = targetView;
                    console.log(`[ourmenu] view → ${currentLeftView}`);
                    rebuildMenu();
                },
            );
        }
    }

    // ============================================================
    // Public API
    // ============================================================
    // IL2CPP calls require an attached thread. setTimeout callbacks and REPL
    // invocations fire OUTSIDE the original Il2Cpp.perform context, so wrap
    // every entry point in Il2Cpp.perform() to re-attach.

    // showMenu only renders if the hand is ready. If you want to force-render
    // in floating mode (no hand), call ourmenu.showFloating().
    function showMenu(): boolean {
        let result = false;
        Il2Cpp.perform(() => {
            if (menuRoot && !menuRoot.isNull?.()) { result = true; return; }
            const handTr = getHandTransform(/*useRight=*/false);
            if (!handTr) { result = false; return; }
            buildMenu(/*forceFloating=*/false);
            console.log("[ourmenu] menu shown (hand-attached)");
            result = true;
        });
        return result;
    }

    function showFloating() {
        Il2Cpp.perform(() => {
            if (menuRoot && !menuRoot.isNull?.()) return;
            buildMenu(/*forceFloating=*/true);
            console.log("[ourmenu] menu shown (floating)");
        });
    }

    function hideMenu() {
        Il2Cpp.perform(() => {
            if (menuRoot && !menuRoot.isNull?.()) {
                try { Object_.method("Destroy", 1).invoke(menuRoot); } catch (_) {}
                menuRoot = null;
                console.log("[ourmenu] menu hidden");
            }
        });
    }

    function toggleMenu() {
        if (menuRoot && !menuRoot.isNull?.()) hideMenu();
        else showMenu();
    }

    // Expose to global for debugging from REPL
    (globalThis as any).ourmenu = {
        show: showMenu,
        showFloating: showFloating,
        hide: hideMenu,
        toggle: toggleMenu,
    };

    // ============================================================
    // Input — keyboard Y key (works on PC VR + desktop)
    // ============================================================
    // UnityEngine.Input.GetKeyDown(KeyCode key) → true on the frame the key
    // becomes pressed. KeyCode.Y = 121. Lives in UnityEngine.InputLegacyModule.
    let InputClass: any = null;
    let inputResolved = false;
    const INPUT_ASSEMBLY_CANDIDATES = [
        "UnityEngine.InputLegacyModule",
        "UnityEngine.CoreModule",
        "UnityEngine",
    ];
    const KEYCODE_Y = 121;

    function resolveInputClass(): any {
        if (inputResolved) return InputClass;
        for (const asmName of INPUT_ASSEMBLY_CANDIDATES) {
            try {
                const k = Il2Cpp.domain.assembly(asmName).image.class("UnityEngine.Input");
                if (k) {
                    InputClass = k;
                    console.log(`[ourmenu] UnityEngine.Input found in ${asmName}`);
                    break;
                }
            } catch (_) {}
        }
        if (!InputClass) console.error("[ourmenu] UnityEngine.Input class not found — Y toggle disabled");
        inputResolved = true;
        return InputClass;
    }

    // GetKeyDown is rising-edge only and Unity clears it after each Update tick.
    // If we poll from FixedUpdate (which runs on the physics tick, not the frame
    // tick), we miss the press. Use GetKey (held state) + manual edge tracking
    // so we still catch the press regardless of which hook ticks first.
    let prevYHeld = false;
    let pollCount = 0;

    // Use Input.GetKey(string) — the string overload picks the key by name
    // regardless of which KeyCode int Unity assigned. Avoids overload-picking
    // ambiguity that bites us when calling `.method("GetKey", 1)` blind.
    const KEY_NAME_Y = "y";

    // ============================================================
    // VR Controller Y (left secondaryButton) — using M4's working pattern
    // ============================================================
    // M4's da.ts polls VR buttons every frame this way:
    //   const InputDevices = Il2Cpp.domain.assembly("UnityEngine.XRModule").image.class("UnityEngine.XR.InputDevices");
    //   const CommonUsages = ...image.class("UnityEngine.XR.CommonUsages");
    //   const leftDevice = InputDevices.method("GetDeviceAtXRNode", 1).invoke(4); // XRNode.LeftHand=4
    //   const outBool = Il2Cpp.alloc(1);
    //   leftDevice.method("TryGetFeatureValue", 2).invoke(
    //       CommonUsages.field("secondaryButton").value, outBool);
    //   const isPressed = outBool.readU8() !== 0;
    let XRInputDevicesClass: any = null;
    let XRCommonUsagesClass: any = null;
    let xrYReady = false;
    let xrYResolved = false;
    let outBoolPtr: any = null;

    function resolveXRY(): boolean {
        if (xrYResolved) return xrYReady;
        try {
            const xrImage = Il2Cpp.domain.assembly("UnityEngine.XRModule").image;
            XRInputDevicesClass = xrImage.class("UnityEngine.XR.InputDevices");
            XRCommonUsagesClass = xrImage.class("UnityEngine.XR.CommonUsages");
            outBoolPtr = Il2Cpp.alloc(1);
            xrYReady = !!(XRInputDevicesClass && XRCommonUsagesClass && outBoolPtr);
            console.log(`[ourmenu] XR Y polling ready: ${xrYReady}`);
        } catch (e) {
            console.error("[ourmenu] XR Y setup failed:", e);
            xrYReady = false;
        }
        xrYResolved = true;
        return xrYReady;
    }

    function isLeftControllerYHeld(): boolean {
        if (!resolveXRY()) return false;
        try {
            const leftDevice = XRInputDevicesClass.method("GetDeviceAtXRNode", 1).invoke(4); // LeftHand
            const usage = XRCommonUsagesClass.field("secondaryButton").value;
            leftDevice.method("TryGetFeatureValue", 2).invoke(usage, outBoolPtr);
            return outBoolPtr.readU8() !== 0;
        } catch (_) {
            return false;
        }
    }

    function isYJustPressed(): boolean {
        const ic = resolveInputClass();
        if (!ic) return false;
        pollCount++;
        if (pollCount === 1 || pollCount % 120 === 0) {
            console.log(`[ourmenu] Y poll #${pollCount} (Input class OK, listening)`);
        }

        // Diagnostic: log any key/button press so we can confirm input reaches AC.
        try {
            const anyKey = !!ic.method("get_anyKey").invoke();
            if (anyKey && !(globalThis as any).__ourmenu_anykey_logged) {
                (globalThis as any).__ourmenu_anykey_logged = true;
                console.log("[ourmenu] anyKey is true — keyboard input IS reaching AC");
            }
        } catch (_) {}

        try {
            // Try the string-name overload first; fall back to KeyCode if that fails.
            let heldNow = false;
            try {
                heldNow = !!ic.method("GetKey").overload("System.String").invoke(Il2Cpp.string(KEY_NAME_Y));
            } catch (_) {
                heldNow = !!ic.method("GetKey").overload("UnityEngine.KeyCode").invoke(KEYCODE_Y);
            }
            if (heldNow && !prevYHeld) {
                prevYHeld = true;
                console.log("[ourmenu] Y key DETECTED (rising edge)");
                return true;
            }
            prevYHeld = heldNow;
            return false;
        } catch (e) {
            if (!(globalThis as any).__ourmenu_input_err_logged) {
                (globalThis as any).__ourmenu_input_err_logged = true;
                console.error("[ourmenu] GetKey failed:", e);
            }
            return false;
        }
    }

    // ============================================================
    // Main-thread Update hook
    //   GameObject creation MUST happen on Unity's main thread. Calls from
    //   Frida's setTimeout/setInterval threads corrupt Unity's scene graph
    //   and crash the game after ~20 GameObjects.
    //
    //   We hook GorillaLocomotion.Update (called every frame on main thread)
    //   and build the menu from inside the hook the first time the hand is
    //   available. The hook keeps calling the original so the player still
    //   updates normally.
    // ============================================================
    let menuHookInstalled = false;
    let menuBuildFailed = false;
    // Toggle state: build once, then SetActive(true/false) on each Y rising edge.
    let menuActive = false;
    let prevYForToggle = false;
    // Deferred measurement + auto-correct: TMP generates its mesh a frame or two
    // AFTER creation, so synchronous bounds read at build time returns 0. We
    // measure N frames later, compute correction = TARGET / measured, and rescale
    // every text we tracked. baseScale value at the call sites becomes irrelevant.
    let firstTextGo: any = null;
    let measureCountdown = -1;
    let pendingTexts: any[] = [];   // [{ go, baseScale }]
    // Pointer-ball click system (M4 pattern, simplified): a small sphere at the
    // right hand. Each frame, we check distance from the ball to every registered
    // button — when close enough and the debounce timer has elapsed, the button
    // fires its onClick handler. No need to hook AC's button class.
    let pointerBall: any = null;
    let menuButtons: any[] = [];    // [{ go, tr, halfExtents:[hx,hy,hz], label, onClick }]
    let lastClickTime = 0;
    const CLICK_DEBOUNCE_S = 0.30;
    // Slider drag system. A slider has an invisible/visible hit-zone panel and
    // two callbacks: onDrag (per-frame while trigger held + pointer in zone) and
    // onCommit (once on release). t ∈ [0..1] across the slider's local X.
    interface SliderRegistration {
        label: string;
        hitTr: any;
        hitHalfExtents: [number, number, number];
        onDrag: (t: number) => void;
        onCommit: (t: number) => void;
    }
    let menuSliders: SliderRegistration[] = [];
    let activeSlider: SliderRegistration | null = null;
    // Paging: each page shows BUTTONS_PER_PAGE entries from OP_MODS in the left
    // panel. Prev/Next buttons re-build the menu on the new page. Bumped 6→8
    // per user request (denser list, same footprint).
    let currentPage = 0;
    const BUTTONS_PER_PAGE = 8;
    // Active left-panel view. "op" is the legacy alias for "Exploits" (the
    // working OP mod list). Each tab label maps directly to a view name.
    //   "playerDetail" is opened from the Players list when you click a player —
    //   it shows the action dropdown (Bring/Goto/Orbit/etc.) for selectedPlayerKey.
    type LeftView =
        | "op"
        | "settings"
        | "Movement"
        | "Items"
        | "Prefabs"
        | "Sounds"
        | "Exploits"
        | "Player"
        | "Players"
        | "Misc"
        | "playerDetail"
        | "wlTools";
    let currentLeftView: LeftView = "op";
    // Player detail paging: 0 = base actions, 1 = WL one-shots A, 2 = WL one-shots B.
    let playerDetailPage = 0;
    // Launcher fire rate (seconds between shots). Cycles via settings page.
    const FIRE_RATE_PRESETS = [0.30, 0.20, 0.12, 0.08, 0.05, 0.03, 0.015];
    let fireRateIndex = 2;   // default 0.12 — matches the old hardcoded value
    function getFireRate(): number { return FIRE_RATE_PRESETS[fireRateIndex]; }

    // Destroy + rebuild the menu (used by page nav buttons). Resets all per-build
    // state so the next build is clean. Safe to call from any onClick.
    function rebuildMenu(): void {
        try {
            if (menuRoot && !menuRoot.isNull?.()) {
                try { Object_.method("Destroy", 1).invoke(menuRoot); } catch (_) {}
            }
        } catch (_) {}
        menuRoot = null;
        firstTextGo = null;
        pendingTexts = [];
        menuButtons = [];
        menuSliders = [];
        activeSlider = null;
        buildMenu(/*forceFloating=*/false);
        menuActive = true;
        // Only measure if the one-shot size lock hasn't landed yet (first
        // successful measure wins; page changes must not re-measure).
        measureCountdown = textCorrectionLocked ? 0 : 8;
    }

    function tryInstallUpdateHook(): boolean {
        if (menuHookInstalled) return true;

        const PlayerKlass = resolvePlayerClass();
        if (!PlayerKlass) return false;

        const updateMethodNames = ["Update", "LateUpdate", "FixedUpdate"];
        let UpdateMethod: any = null;
        let chosenName = "";
        for (const name of updateMethodNames) {
            try {
                const m = PlayerKlass.method(name);
                if (m) { UpdateMethod = m; chosenName = name; break; }
            } catch (_) {}
        }

        if (!UpdateMethod) {
            console.error("[ourmenu] could not find Update/LateUpdate/FixedUpdate on player class");
            return false;
        }

        console.log(`[ourmenu] attaching Interceptor to ${chosenName} on player class — menu will build when hand is ready`);

        // Use Interceptor.attach to OBSERVE the method, not replace it. The original
        // runs naturally each frame. We piggyback the first time the hand is ready to
        // build the menu on Unity's main thread.
        //
        // CRITICAL: must attach to .virtualAddress (the JIT-compiled native code
        // pointer), NOT .handle (which is the IL2CPP MethodInfo struct — attaching
        // there corrupts metadata and crashes the process immediately).
        const methodAddr = UpdateMethod.virtualAddress ?? UpdateMethod.handle;
        if (!methodAddr || methodAddr.isNull?.()) {
            console.error("[ourmenu] FixedUpdate has no virtualAddress (JIT not ready?)");
            return false;
        }
        console.log(`[ourmenu] FixedUpdate virtual address: ${methodAddr}`);
        const Interceptor: any = (globalThis as any).Interceptor;
        // PRESS-TO-TOGGLE (rising edge of left controller Y):
        //   1st press  → build menu once, show it
        //   next press → hide (SetActive false); next → show; etc.
        // This is far more reliable than hold-to-show (which kept failing to
        // dismiss, leaving the menu "stuck on hand") and avoids rebuilding 31
        // objects on every interaction.
        Interceptor.attach(methodAddr, {
            onEnter(this: any) {
                if (menuBuildFailed) return;
                Il2Cpp.perform(() => {
                    try {
                        // Deferred bounds measurement (mesh exists a few frames after build).
                        if (measureCountdown > 0) {
                            measureCountdown--;
                            if (measureCountdown === 0) deferredMeasure();
                        }

                        // M4 per-frame state updates (input + hand transforms).
                        // MUST run before tickPointer so slider drag sees the
                        // current trigger state, not last frame's stale value.
                        updateM4Input();
                        refreshHandTransforms();

                        // Pointer-ball click check (per frame while menu active).
                        tickPointer();

                        // Toggleable per-frame mods (Spaz Explode etc.)
                        try { runPerFrameMods(); } catch (_) {}

                        const yHeld = isLeftControllerYHeld();
                        const rising = yHeld && !prevYForToggle;
                        prevYForToggle = yHeld;
                        if (!rising) return;

                        const built = !!(menuRoot && !menuRoot.isNull?.());
                        if (!built) {
                            const handTr = getHandTransform(/*useRight=*/false);
                            if (!handTr) return;
                            console.log("[ourmenu] Y pressed — building menu");
                            firstTextGo = null;
                            pendingTexts = [];
                            menuButtons = [];
                            menuSliders = [];
                            activeSlider = null;
                            buildMenu(/*forceFloating=*/false);
                            menuActive = true;
                            // auto-correct text size ~8 frames later — but only
                            // until the one-shot size lock lands (stable size).
                            measureCountdown = textCorrectionLocked ? 0 : 8;
                        } else {
                            menuActive = !menuActive;
                            try { menuRoot.method("SetActive").invoke(menuActive); } catch (_) {}
                            try { if (pointerBall && !pointerBall.isNull?.()) pointerBall.method("SetActive").invoke(menuActive); } catch (_) {}
                            console.log(`[ourmenu] Y pressed — menu ${menuActive ? "shown" : "hidden"}`);
                        }
                    } catch (e) {
                        menuBuildFailed = true;
                        console.error("[ourmenu] menu logic failed inside hook:", e);
                    }
                });
            }
        });

        menuHookInstalled = true;
        return true;
    }

    // Retry hook install every 500ms until the player class is resolvable.
    // First attempt after 2s to let the runtime load assemblies.
    let hookRetryTimer: any = null;
    let hookRetryMs = 0;
    const HOOK_RETRY_INTERVAL_MS = 500;
    const HOOK_MAX_WAIT_MS = 60_000;

    function hookRetryLoop() {
        if (tryInstallUpdateHook()) {
            if (hookRetryTimer !== null) { clearInterval(hookRetryTimer); hookRetryTimer = null; }
            return;
        }
        hookRetryMs += HOOK_RETRY_INTERVAL_MS;
        if (hookRetryMs % 5000 === 0) {
            console.log(`[ourmenu] waiting for player class to load... (${hookRetryMs / 1000}s)`);
        }
        if (hookRetryMs >= HOOK_MAX_WAIT_MS) {
            if (hookRetryTimer !== null) { clearInterval(hookRetryTimer); hookRetryTimer = null; }
            console.error(`[ourmenu] could not find player class after ${HOOK_MAX_WAIT_MS / 1000}s.`);
        }
    }

    setTimeout(() => {
        hookRetryTimer = setInterval(hookRetryLoop, HOOK_RETRY_INTERVAL_MS);
        hookRetryLoop();
    }, 2000);

    console.log("[ourmenu] loaded — will install Update hook and build menu when player is in-game.");
});
