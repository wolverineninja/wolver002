@echo off
cd /d "%~dp0"

where frida >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Frida is not installed or not on PATH.
    echo Install it with: pip install frida-tools
    echo.
    pause
    exit /b 1
)

tasklist /fi "imagename eq AnimalCompany.exe" 2>nul | find /i "AnimalCompany.exe" >nul
if %errorlevel% neq 0 (
    echo [ERROR] AnimalCompany.exe is not running.
    echo Start the game first, then run this script.
    echo.
    pause
    exit /b 1
)

echo Injecting mod menu...
frida -l frida-il2cpp-bridge.js -l symbols.ts -l m4literallymadethisinaminute.ts -l questservers.ts -l WMM.ts "AnimalCompany.exe"
pause
