declare const Il2Cpp: any;
declare const console: any;

Il2Cpp.perform(() => {
	try {
		const AppUtils = Il2Cpp.domain.assembly("AnimalCompany").image.class("AnimalCompany.AppUtils");
		const method = AppUtils.method("CalculatePhotonAppVersion");

		method.implementation = function () {
			return Il2Cpp.string("x6pLQUPA9IPW-ZlQnPHQ");
		};

		console.log("quest servers injected, join discord.gg/t444 if you aren't already.");
	} catch (e) {
		console.error("[questservers] CalculatePhotonAppVersion hook failed:", e);
	}
});
